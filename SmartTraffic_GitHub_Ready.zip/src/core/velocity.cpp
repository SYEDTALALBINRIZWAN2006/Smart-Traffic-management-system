#include "smart_traffic/core/velocity.h"
#include "smart_traffic/core/types.h"
#include <cmath>
#include <sstream>
#include <iomanip>

namespace SmartTraffic {

double Velocity::speed() const noexcept {
    return std::sqrt(vx * vx + vy * vy);
}

double Velocity::headingRadians() const noexcept {
    return std::atan2(vy, vx);
}

double Velocity::headingDegrees() const noexcept {
    double deg = headingRadians() * (180.0 / Constants::PI);
    if (deg < 0.0) {
        deg += 360.0;
    }
    return deg;
}

Velocity Velocity::fromSpeedAndHeading(double speed_mps, double heading_rad) noexcept {
    return Velocity(speed_mps * std::cos(heading_rad), speed_mps * std::sin(heading_rad));
}

Velocity Velocity::operator+(const Velocity& other) const noexcept {
    return Velocity(vx + other.vx, vy + other.vy);
}

Velocity Velocity::operator-(const Velocity& other) const noexcept {
    return Velocity(vx - other.vx, vy - other.vy);
}

Velocity Velocity::operator*(double scalar) const noexcept {
    return Velocity(vx * scalar, vy * scalar);
}

Velocity& Velocity::operator+=(const Velocity& other) noexcept {
    vx += other.vx;
    vy += other.vy;
    return *this;
}

Velocity& Velocity::operator-=(const Velocity& other) noexcept {
    vx -= other.vx;
    vy -= other.vy;
    return *this;
}

bool Velocity::operator==(const Velocity& other) const noexcept {
    return std::abs(vx - other.vx) < Constants::EPSILON && 
           std::abs(vy - other.vy) < Constants::EPSILON;
}

bool Velocity::operator!=(const Velocity& other) const noexcept {
    return !(*this == other);
}

std::string Velocity::toString() const {
    std::ostringstream ss;
    ss << std::fixed << std::setprecision(4) 
       << "(vx=" << vx << " m/s, vy=" << vy << " m/s, speed=" << speed() << " m/s)";
    return ss.str();
}

std::ostream& operator<<(std::ostream& os, const Velocity& vel) {
    os << vel.toString();
    return os;
}

} // namespace SmartTraffic
