#include "smart_traffic/core/vehicle.h"
#include <algorithm>
#include <sstream>
#include <iomanip>

namespace SmartTraffic {

Vehicle::Vehicle(uint32_t id, 
                 uint32_t lane_id, 
                 double initial_speed_mps, 
                 double target_speed_mps,
                 double spawn_time_sec)
    : id_(id),
      current_speed_(std::max(0.0, initial_speed_mps)),
      target_speed_(std::max(0.0, target_speed_mps)),
      current_lane_id_(lane_id),
      state_(VehicleState::PENDING_SPAWN),
      spawn_time_(spawn_time_sec) {
}

void Vehicle::setVelocity(const Velocity& vel) noexcept {
    velocity_ = vel;
    current_speed_ = vel.speed();
}

void Vehicle::setCurrentSpeed(double speed) noexcept {
    current_speed_ = std::clamp(speed, 0.0, max_speed_);
}

void Vehicle::setTargetSpeed(double speed) noexcept {
    target_speed_ = std::max(0.0, speed);
}

void Vehicle::setMaxSpeed(double max_spd) noexcept {
    if (max_spd > 0.0) {
        max_speed_ = max_spd;
        if (current_speed_ > max_speed_) {
            current_speed_ = max_speed_;
        }
    }
}

void Vehicle::setMaxAcceleration(double max_acc) noexcept {
    if (max_acc > 0.0) {
        max_acceleration_ = max_acc;
    }
}

void Vehicle::setMaxDeceleration(double max_dec) noexcept {
    if (max_dec > 0.0) {
        max_deceleration_ = max_dec;
    }
}

double Vehicle::updateKinematics(double desired_acc, double dt, double speed_limit) {
    if (dt <= 0.0) {
        return 0.0;
    }

    // Strict acceleration bounds clamping: [-max_deceleration, +max_acceleration]
    const double clamped_acc = std::clamp(desired_acc, -max_deceleration_, max_acceleration_);

    // Compute trial velocity: v = v_0 + a * dt
    double next_speed = current_speed_ + clamped_acc * dt;

    // Strict speed limits: cannot be negative (no reversing), cannot exceed lane limit or vehicle max speed
    const double effective_max_speed = std::min(max_speed_, std::max(0.0, speed_limit));
    next_speed = std::clamp(next_speed, 0.0, effective_max_speed);

    // Compute displacement using trapezoidal integration: delta_s = ((v0 + v1) / 2) * dt
    const double delta_s = 0.5 * (current_speed_ + next_speed) * dt;

    // Update state
    current_speed_ = next_speed;
    advanceDistanceAlongLane(delta_s);

    return delta_s;
}

void Vehicle::advanceDistanceAlongLane(double delta_s) noexcept {
    if (delta_s > 0.0) {
        distance_along_lane_ += delta_s;
        total_distance_traveled_ += delta_s;
    }
}

void Vehicle::transitionToLane(uint32_t new_lane_id, double initial_distance) noexcept {
    current_lane_id_ = new_lane_id;
    distance_along_lane_ = std::max(0.0, initial_distance);
}

std::string Vehicle::toString() const {
    std::ostringstream ss;
    ss << "Vehicle[ID=" << id_ 
       << ", State=" << vehicleStateToString(state_)
       << ", Lane=" << current_lane_id_
       << ", Pos=" << position_.toString()
       << ", Speed=" << std::fixed << std::setprecision(2) << current_speed_ << " m/s"
       << ", DistAlongLane=" << distance_along_lane_ << " m]";
    return ss.str();
}

} // namespace SmartTraffic
