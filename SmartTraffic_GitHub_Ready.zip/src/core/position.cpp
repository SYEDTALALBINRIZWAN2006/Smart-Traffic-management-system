#include "smart_traffic/core/position.h"
#include "smart_traffic/core/types.h"
#include <cmath>
#include <sstream>
#include <iomanip>

namespace SmartTraffic {

double Position::distanceTo(const Position& other) const noexcept {
    const double dx = x - other.x;
    const double dy = y - other.y;
    return std::sqrt(dx * dx + dy * dy);
}

bool Position::isNear(const Position& other, double tolerance) const noexcept {
    return distanceTo(other) <= tolerance;
}

Position Position::lerp(const Position& target, double t) const noexcept {
    if (t <= 0.0) return *this;
    if (t >= 1.0) return target;
    return Position(x + (target.x - x) * t, y + (target.y - y) * t);
}

Position Position::operator+(const Position& other) const noexcept {
    return Position(x + other.x, y + other.y);
}

Position Position::operator-(const Position& other) const noexcept {
    return Position(x - other.x, y - other.y);
}

Position Position::operator*(double scalar) const noexcept {
    return Position(x * scalar, y * scalar);
}

Position& Position::operator+=(const Position& other) noexcept {
    x += other.x;
    y += other.y;
    return *this;
}

Position& Position::operator-=(const Position& other) noexcept {
    x -= other.x;
    y -= other.y;
    return *this;
}

bool Position::operator==(const Position& other) const noexcept {
    return std::abs(x - other.x) < Constants::EPSILON && 
           std::abs(y - other.y) < Constants::EPSILON;
}

bool Position::operator!=(const Position& other) const noexcept {
    return !(*this == other);
}

std::string Position::toString() const {
    std::ostringstream ss;
    ss << std::fixed << std::setprecision(4) << "(" << x << ", " << y << ")";
    return ss.str();
}

std::ostream& operator<<(std::ostream& os, const Position& pos) {
    os << pos.toString();
    return os;
}

} // namespace SmartTraffic
