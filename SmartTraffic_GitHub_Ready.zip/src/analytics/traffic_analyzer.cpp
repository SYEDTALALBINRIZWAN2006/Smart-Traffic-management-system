#include "smart_traffic/analytics/traffic_analyzer.h"
#include <filesystem>
#include <algorithm>
#include <iomanip>
#include <cmath>

namespace SmartTraffic {

TrafficAnalyzer::TrafficAnalyzer(const std::string& csv_output_path,
                                 const CongestionThresholds& thresholds)
    : csv_output_path_(csv_output_path),
      thresholds_(thresholds) {
    if (!csv_output_path_.empty()) {
        openExportFile(csv_output_path_);
    }
}

TrafficAnalyzer::~TrafficAnalyzer() {
    closeExportFile();
}

void TrafficAnalyzer::openExportFile(const std::string& csv_output_path) {
    closeExportFile();
    csv_output_path_ = csv_output_path;

    if (csv_output_path_.empty()) {
        is_csv_open_ = false;
        return;
    }

    std::filesystem::path path(csv_output_path_);
    if (path.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(path.parent_path(), ec);
    }

    csv_stream_.open(csv_output_path_, std::ios::out | std::ios::trunc);
    if (csv_stream_.is_open()) {
        is_csv_open_ = true;
        // Exactly 9 columns
        csv_stream_ << "timestamp,total_active_vehicles,completed_journeys,stopped_vehicles,"
                    << "avg_network_speed_mps,avg_network_speed_kmh,avg_occupancy,"
                    << "avg_density_veh_per_km,network_congestion\n";
        csv_stream_ << std::fixed << std::setprecision(4);
    }
}

void TrafficAnalyzer::closeExportFile() {
    if (is_csv_open_ && csv_stream_.is_open()) {
        csv_stream_.flush();
        csv_stream_.close();
        is_csv_open_ = false;
    }
}

void TrafficAnalyzer::reset() {
    latest_metrics_ = NetworkMetrics{};
    summary_ = TrafficAnalyticsSummary{};
    sum_speed_samples_ = 0.0;
    total_vehicle_samples_ = 0;

    if (!csv_output_path_.empty()) {
        openExportFile(csv_output_path_);
    }
}

const RoadMetrics* TrafficAnalyzer::getRoadMetrics(uint32_t road_id) const noexcept {
    const auto it = latest_metrics_.road_metrics.find(road_id);
    if (it != latest_metrics_.road_metrics.end()) {
        return &(it->second);
    }
    return nullptr;
}

size_t TrafficAnalyzer::getVehicleCountOnLane(uint32_t lane_id) const noexcept {
    const auto it = latest_metrics_.vehicle_count_per_lane.find(lane_id);
    if (it != latest_metrics_.vehicle_count_per_lane.end()) {
        return it->second;
    }
    return 0;
}

CongestionLevel TrafficAnalyzer::evaluateCongestion(double occupancy,
                                                    double avg_speed_mps,
                                                    double speed_limit_mps,
                                                    size_t vehicle_count,
                                                    size_t stopped_count) const noexcept {
    // Empty roads or zero vehicle counts are strictly free-flow (LOW)
    if (vehicle_count == 0) {
        return CongestionLevel::LOW;
    }

    const double speed_ratio = (speed_limit_mps > 1e-4) ? (avg_speed_mps / speed_limit_mps) : 1.0;
    const double stopped_ratio = (vehicle_count > 0) ? (static_cast<double>(stopped_count) / static_cast<double>(vehicle_count)) : 0.0;

    // HIGH Congestion criteria:
    // 1. Extreme occupancy (>= 50%)
    // 2. High occupancy (>= 30%) with crawling speed (<= 30% of speed limit)
    // 3. Significant stopped ratio (>= 60%) with at least 3 vehicles
    if (occupancy >= thresholds_.moderate_occupancy_max ||
        (occupancy >= 0.30 && speed_ratio <= thresholds_.speed_ratio_severe) ||
        (stopped_ratio >= thresholds_.stopped_ratio_severe && vehicle_count >= 3)) {
        return CongestionLevel::HIGH;
    }

    // MODERATE Congestion criteria:
    // 1. Moderate occupancy (in [25%, 50%))
    // 2. Low-to-moderate occupancy (>= 15%) with slow speed (<= 60% of speed limit)
    // 3. Noticeable stopped vehicles (>= 30% stopped with >= 2 vehicles)
    if (occupancy >= thresholds_.low_occupancy_max ||
        (occupancy >= 0.15 && speed_ratio <= thresholds_.speed_ratio_moderate) ||
        (stopped_ratio >= 0.30 && vehicle_count >= 2)) {
        return CongestionLevel::MODERATE;
    }

    return CongestionLevel::LOW;
}

void TrafficAnalyzer::update(double current_time,
                             double /*dt*/,
                             const std::vector<std::shared_ptr<Vehicle>>& active_vehicles,
                             const RoadNetwork& road_network,
                             size_t completed_journeys) {
    NetworkMetrics metrics;
    metrics.timestamp = current_time;
    metrics.total_active_vehicles = 0;
    metrics.completed_journeys = completed_journeys;
    metrics.total_stopped_vehicles = 0;

    // Group active vehicles by lane ID
    std::unordered_map<uint32_t, std::vector<std::shared_ptr<Vehicle>>> vehicles_by_lane;
    double network_speed_sum = 0.0;

    for (const auto& vehicle : active_vehicles) {
        if (!vehicle) continue;
        metrics.total_active_vehicles++;

        const double spd = vehicle->getCurrentSpeed();
        network_speed_sum += spd;
        sum_speed_samples_ += spd;
        total_vehicle_samples_++;

        const uint32_t lane_id = vehicle->getCurrentLaneId();
        vehicles_by_lane[lane_id].push_back(vehicle);
        metrics.vehicle_count_per_lane[lane_id]++;

        if (spd < thresholds_.stopped_speed_threshold_mps) {
            metrics.total_stopped_vehicles++;
        }
    }

    if (metrics.total_active_vehicles > 0) {
        metrics.average_network_speed_mps = network_speed_sum / static_cast<double>(metrics.total_active_vehicles);
        metrics.average_network_speed_kmh = metrics.average_network_speed_mps * 3.6;
    }

    // Compute metrics for every physical road/lane in the network
    const auto& all_lanes = road_network.getAllLanes();
    double sum_occupancy = 0.0;
    double sum_density = 0.0;
    size_t evaluated_lanes = 0;
    size_t high_congestion_roads = 0;
    size_t moderate_congestion_roads = 0;

    for (const auto& [lane_id, lane] : all_lanes) {
        if (!lane) continue;
        evaluated_lanes++;

        RoadMetrics rm;
        rm.road_id = lane_id;
        rm.road_name = lane->getName();
        rm.road_length_meters = lane->getLength();
        rm.speed_limit_mps = lane->getSpeedLimit();

        auto it = vehicles_by_lane.find(lane_id);
        if (it != vehicles_by_lane.end()) {
            const auto& lane_veh_list = it->second;
            rm.vehicle_count = lane_veh_list.size();

            double lane_speed_sum = 0.0;
            for (const auto& v : lane_veh_list) {
                rm.total_vehicle_length_meters += v->getLength();
                lane_speed_sum += v->getCurrentSpeed();
                if (v->getCurrentSpeed() < thresholds_.stopped_speed_threshold_mps) {
                    rm.stopped_vehicle_count++;
                }
            }

            if (rm.vehicle_count > 0) {
                rm.average_speed_mps = lane_speed_sum / static_cast<double>(rm.vehicle_count);
                rm.average_speed_kmh = rm.average_speed_mps * 3.6;
            }
        }

        // Safe occupancy and density calculation (protect against zero/negative length)
        if (rm.road_length_meters > 1e-4) {
            rm.occupancy = std::clamp(rm.total_vehicle_length_meters / rm.road_length_meters, 0.0, 1.0);
            rm.density_vehicles_per_km = (static_cast<double>(rm.vehicle_count) / rm.road_length_meters) * 1000.0;
        } else {
            rm.occupancy = 0.0;
            rm.density_vehicles_per_km = 0.0;
        }

        // Evaluate heuristic congestion level
        rm.congestion_level = evaluateCongestion(rm.occupancy,
                                                 rm.average_speed_mps,
                                                 rm.speed_limit_mps,
                                                 rm.vehicle_count,
                                                 rm.stopped_vehicle_count);

        if (rm.congestion_level == CongestionLevel::HIGH) {
            high_congestion_roads++;
        } else if (rm.congestion_level == CongestionLevel::MODERATE) {
            moderate_congestion_roads++;
        }

        sum_occupancy += rm.occupancy;
        sum_density += rm.density_vehicles_per_km;

        summary_.peak_occupancy = std::max(summary_.peak_occupancy, rm.occupancy);
        summary_.peak_density_vehicles_per_km = std::max(summary_.peak_density_vehicles_per_km, rm.density_vehicles_per_km);

        metrics.road_metrics[lane_id] = rm;
    }

    if (evaluated_lanes > 0) {
        metrics.average_occupancy = sum_occupancy / static_cast<double>(evaluated_lanes);
        metrics.average_density_vehicles_per_km = sum_density / static_cast<double>(evaluated_lanes);
    }

    // Determine system-wide network congestion
    if (high_congestion_roads >= 2 || metrics.average_occupancy >= thresholds_.moderate_occupancy_max) {
        metrics.network_congestion_level = CongestionLevel::HIGH;
    } else if (high_congestion_roads >= 1 || moderate_congestion_roads >= 2 || metrics.average_occupancy >= thresholds_.low_occupancy_max) {
        metrics.network_congestion_level = CongestionLevel::MODERATE;
    } else {
        metrics.network_congestion_level = CongestionLevel::LOW;
    }

    // Update cumulative summary
    summary_.total_analyzed_time_sec = current_time;
    summary_.total_snapshots++;
    summary_.peak_active_vehicles = std::max(summary_.peak_active_vehicles, metrics.total_active_vehicles);
    summary_.total_completed_journeys = completed_journeys;

    if (metrics.network_congestion_level == CongestionLevel::HIGH) {
        summary_.total_high_congestion_snapshots++;
    } else if (metrics.network_congestion_level == CongestionLevel::MODERATE) {
        summary_.total_moderate_congestion_snapshots++;
    } else {
        summary_.total_low_congestion_snapshots++;
    }

    if (total_vehicle_samples_ > 0) {
        summary_.overall_mean_speed_mps = sum_speed_samples_ / static_cast<double>(total_vehicle_samples_);
        summary_.overall_mean_speed_kmh = summary_.overall_mean_speed_mps * 3.6;
    }

    latest_metrics_ = metrics;

    // Export row to CSV if enabled
    if (is_csv_open_) {
        csv_stream_ << current_time << ","
                    << metrics.total_active_vehicles << ","
                    << metrics.completed_journeys << ","
                    << metrics.total_stopped_vehicles << ","
                    << metrics.average_network_speed_mps << ","
                    << metrics.average_network_speed_kmh << ","
                    << metrics.average_occupancy << ","
                    << metrics.average_density_vehicles_per_km << ","
                    << congestionLevelToString(metrics.network_congestion_level) << "\n";
    }
}

} // namespace SmartTraffic
