#include "smart_traffic/analytics/alert_manager.h"
#include <filesystem>
#include <iomanip>
#include <algorithm>

namespace SmartTraffic {

AlertManager::AlertManager(const std::string& csv_output_path,
                           const AlertThresholds& thresholds)
    : csv_output_path_(csv_output_path),
      thresholds_(thresholds) {
    if (!csv_output_path_.empty()) {
        openExportFile(csv_output_path_);
    }
}

AlertManager::~AlertManager() {
    closeExportFile();
}

void AlertManager::openExportFile(const std::string& csv_output_path) {
    closeExportFile();
    csv_output_path_ = csv_output_path;

    if (csv_output_path_.empty()) {
        is_csv_open_ = false;
        return;
    }

    std::filesystem::path path(csv_output_path_);
    if (path.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(path.parent_path(), ec);
    }

    csv_stream_.open(csv_output_path_, std::ios::out | std::ios::trunc);
    if (csv_stream_.is_open()) {
        is_csv_open_ = true;
        // Exactly 11 columns
        csv_stream_ << "event_id,timestamp,resolved_timestamp,alert_type,status,vehicle_id,road_id,actual_speed,speed_limit,severity,message\n";
        csv_stream_ << std::fixed << std::setprecision(4);
    }
}

void AlertManager::closeExportFile() {
    if (is_csv_open_ && csv_stream_.is_open()) {
        csv_stream_.flush();
        csv_stream_.close();
        is_csv_open_ = false;
    }
}

void AlertManager::reset() {
    active_alerts_.clear();
    historical_alerts_.clear();
    vehicle_stopped_start_time_.clear();
    next_event_id_ = 1;
    summary_ = AlertSummary{};

    if (!csv_output_path_.empty()) {
        openExportFile(csv_output_path_);
    }
}

void AlertManager::writeAlertRow(const TrafficEvent& event) {
    if (is_csv_open_ && csv_stream_.is_open()) {
        csv_stream_ << event.toCsvRow() << "\n";
    }
}

void AlertManager::resolveAlert(const std::string& alert_key, double resolved_time) {
    auto it = active_alerts_.find(alert_key);
    if (it != active_alerts_.end()) {
        TrafficEvent resolved_event = it->second;
        resolved_event.status = AlertStatus::RESOLVED;
        resolved_event.resolved_timestamp = resolved_time;

        historical_alerts_.push_back(resolved_event);
        summary_.total_alerts_resolved++;

        // Write resolution state update to CSV
        writeAlertRow(resolved_event);

        active_alerts_.erase(it);
    }
}

void AlertManager::handleVehicleDeparted(uint32_t vehicle_id, double current_time) {
    const std::string speed_key = "SPEED_" + std::to_string(vehicle_id);
    const std::string stopped_key = "STOPPED_" + std::to_string(vehicle_id);

    resolveAlert(speed_key, current_time);
    resolveAlert(stopped_key, current_time);
    vehicle_stopped_start_time_.erase(vehicle_id);

    summary_.active_alerts_at_end = active_alerts_.size();
}

void AlertManager::checkSpeedViolations(double current_time,
                                       const std::vector<std::shared_ptr<Vehicle>>& active_vehicles,
                                       const RoadNetwork& road_network) {
    for (const auto& vehicle : active_vehicles) {
        if (!vehicle) continue;
        const uint32_t vid = vehicle->getId();
        const uint32_t lane_id = vehicle->getCurrentLaneId();
        const auto lane = road_network.getLane(lane_id);
        if (!lane) continue;

        const double speed_limit = lane->getSpeedLimit();
        const double current_speed = vehicle->getCurrentSpeed();
        const std::string key = "SPEED_" + std::to_string(vid);

        if (current_speed > speed_limit + thresholds_.speed_violation_tolerance_mps) {
            const double excess_speed = current_speed - speed_limit;
            const double excess_ratio = (speed_limit > 1e-4) ? (excess_speed / speed_limit) : 0.0;

            ViolationSeverity severity = ViolationSeverity::LOW;
            if (excess_ratio >= 0.30) {
                severity = ViolationSeverity::HIGH;
            } else if (excess_ratio >= 0.15) {
                severity = ViolationSeverity::MEDIUM;
            }

            auto it = active_alerts_.find(key);
            if (it == active_alerts_.end()) {
                // New speed violation alert
                TrafficEvent event;
                event.event_id = next_event_id_++;
                event.timestamp = current_time;
                event.resolved_timestamp = 0.0;
                event.type = AlertType::SPEED_VIOLATION;
                event.status = AlertStatus::ACTIVE;
                event.vehicle_id = vid;
                event.road_id = lane_id;
                event.actual_speed_mps = current_speed;
                event.speed_limit_mps = speed_limit;
                event.severity = severity;
                event.message = "Vehicle " + std::to_string(vid) + " exceeded speed limit on " + lane->getName();

                active_alerts_[key] = event;
                summary_.total_alerts_created++;
                summary_.speed_violations_count++;

                writeAlertRow(event);
            } else {
                // Deduplication: ongoing continuous violation -> update peak telemetry
                if (current_speed > it->second.actual_speed_mps) {
                    it->second.actual_speed_mps = current_speed;
                    it->second.severity = std::max(it->second.severity, severity);
                }
            }
        } else {
            // Speed dropped back to or below speed limit
            resolveAlert(key, current_time);
        }
    }
}

void AlertManager::checkStoppedVehicles(double current_time,
                                       const std::vector<std::shared_ptr<Vehicle>>& active_vehicles) {
    for (const auto& vehicle : active_vehicles) {
        if (!vehicle) continue;
        const uint32_t vid = vehicle->getId();
        const double current_speed = vehicle->getCurrentSpeed();
        const std::string key = "STOPPED_" + std::to_string(vid);

        if (current_speed < thresholds_.stopped_speed_threshold_mps) {
            auto it = vehicle_stopped_start_time_.find(vid);
            if (it == vehicle_stopped_start_time_.end()) {
                vehicle_stopped_start_time_[vid] = current_time;
            } else {
                const double stopped_duration = current_time - it->second;
                if (stopped_duration >= thresholds_.stopped_duration_threshold_sec) {
                    if (active_alerts_.find(key) == active_alerts_.end()) {
                        // New stopped vehicle alert
                        TrafficEvent event;
                        event.event_id = next_event_id_++;
                        event.timestamp = current_time;
                        event.resolved_timestamp = 0.0;
                        event.type = AlertType::STOPPED_VEHICLE;
                        event.status = AlertStatus::ACTIVE;
                        event.vehicle_id = vid;
                        event.road_id = vehicle->getCurrentLaneId();
                        event.actual_speed_mps = current_speed;
                        event.speed_limit_mps = 0.0;
                        event.severity = (stopped_duration >= thresholds_.stopped_duration_threshold_sec * 2.0)
                                             ? ViolationSeverity::HIGH
                                             : ViolationSeverity::MEDIUM;
                        event.message = "Vehicle " + std::to_string(vid) + " abnormally stationary on lane " + std::to_string(vehicle->getCurrentLaneId());

                        active_alerts_[key] = event;
                        summary_.total_alerts_created++;
                        summary_.stopped_vehicle_count++;

                        writeAlertRow(event);
                    }
                }
            }
        } else {
            // Vehicle has resumed moving
            vehicle_stopped_start_time_.erase(vid);
            resolveAlert(key, current_time);
        }
    }
}

void AlertManager::checkHeavyCongestion(double current_time,
                                       const TrafficAnalyzer& analyzer) {
    const auto& metrics = analyzer.getLatestMetrics();
    for (const auto& [road_id, rm] : metrics.road_metrics) {
        const std::string key = "CONGESTION_" + std::to_string(road_id);

        if (rm.congestion_level == CongestionLevel::HIGH) {
            if (active_alerts_.find(key) == active_alerts_.end()) {
                TrafficEvent event;
                event.event_id = next_event_id_++;
                event.timestamp = current_time;
                event.resolved_timestamp = 0.0;
                event.type = AlertType::HEAVY_CONGESTION;
                event.status = AlertStatus::ACTIVE;
                event.vehicle_id = 0; // Road-level event
                event.road_id = road_id;
                event.actual_speed_mps = rm.average_speed_mps;
                event.speed_limit_mps = rm.speed_limit_mps;
                event.severity = ViolationSeverity::HIGH;
                event.message = "Heavy congestion on corridor " + rm.road_name + " (occupancy: " + std::to_string(static_cast<int>(rm.occupancy * 100.0)) + "%)";

                active_alerts_[key] = event;
                summary_.total_alerts_created++;
                summary_.heavy_congestion_count++;

                writeAlertRow(event);
            }
        } else {
            // Congestion has reduced to MODERATE or LOW
            resolveAlert(key, current_time);
        }
    }
}

void AlertManager::processAlerts(double current_time,
                                 const std::vector<std::shared_ptr<Vehicle>>& active_vehicles,
                                 const TrafficAnalyzer& analyzer,
                                 const RoadNetwork& road_network) {
    checkSpeedViolations(current_time, active_vehicles, road_network);
    checkStoppedVehicles(current_time, active_vehicles);
    checkHeavyCongestion(current_time, analyzer);

    summary_.active_alerts_at_end = active_alerts_.size();
}

std::vector<TrafficEvent> AlertManager::getActiveAlerts() const {
    std::vector<TrafficEvent> result;
    result.reserve(active_alerts_.size());
    for (const auto& [key, alert] : active_alerts_) {
        result.push_back(alert);
    }
    return result;
}

std::vector<TrafficEvent> AlertManager::getAllAlerts() const {
    std::vector<TrafficEvent> result;
    result.reserve(active_alerts_.size() + historical_alerts_.size());
    for (const auto& alert : historical_alerts_) {
        result.push_back(alert);
    }
    for (const auto& [key, alert] : active_alerts_) {
        result.push_back(alert);
    }
    std::sort(result.begin(), result.end(), [](const TrafficEvent& a, const TrafficEvent& b) {
        return a.event_id < b.event_id;
    });
    return result;
}

} // namespace SmartTraffic
