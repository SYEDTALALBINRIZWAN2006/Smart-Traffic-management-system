#include "smart_traffic/tracking/kalman_filter_2d.h"
#include <cmath>
#include <sstream>
#include <iomanip>
#include <algorithm>

namespace SmartTraffic {

KalmanFilter2D::KalmanFilter2D(double process_accel_stddev,
                               double measurement_stddev,
                               double initial_velocity_stddev)
    : q_accel_stddev_(std::max(0.01, process_accel_stddev)),
      r_gps_stddev_(std::max(0.01, measurement_stddev)),
      p_init_vel_stddev_(std::max(0.1, initial_velocity_stddev)) {
    // Initialize Measurement Matrix H (2x4)
    H_.setZero();
    H_(0, 0) = 1.0;
    H_(1, 1) = 1.0;

    // Initialize Measurement Covariance Matrix R (2x2)
    const double r_var = r_gps_stddev_ * r_gps_stddev_;
    R_.setZero();
    R_(0, 0) = r_var;
    R_(1, 1) = r_var;

    // Initialize state covariance P (4x4)
    P_.setZero();
    P_(0, 0) = r_var;
    P_(1, 1) = r_var;
    P_(2, 2) = p_init_vel_stddev_ * p_init_vel_stddev_;
    P_(3, 3) = p_init_vel_stddev_ * p_init_vel_stddev_;
}

void KalmanFilter2D::initialize(double z_x, double z_y, double timestamp) {
    x_.setZero();
    x_(0) = z_x;
    x_(1) = z_y;
    x_(2) = 0.0;
    x_(3) = 0.0;

    const double r_var = r_gps_stddev_ * r_gps_stddev_;
    const double v_var = p_init_vel_stddev_ * p_init_vel_stddev_;

    P_.setZero();
    P_(0, 0) = r_var;
    P_(1, 1) = r_var;
    P_(2, 2) = v_var;
    P_(3, 3) = v_var;

    last_update_time_ = timestamp;
    update_count_ = 1;
    is_initialized_ = true;
}

void KalmanFilter2D::computeProcessNoiseMatrix(double dt, Eigen::Matrix4d& Q_out) const noexcept {
    Q_out.setZero();
    const double dt2 = dt * dt;
    const double dt3 = dt2 * dt;
    const double q = q_accel_stddev_ * q_accel_stddev_;

    const double q11 = (dt3 / 3.0) * q;
    const double q12 = (dt2 / 2.0) * q;
    const double q22 = dt * q;

    Q_out(0, 0) = q11;
    Q_out(0, 2) = q12;
    Q_out(2, 0) = q12;
    Q_out(2, 2) = q22;

    Q_out(1, 1) = q11;
    Q_out(1, 3) = q12;
    Q_out(3, 1) = q12;
    Q_out(3, 3) = q22;
}

void KalmanFilter2D::predict(double dt) {
    if (!is_initialized_ || dt <= 0.0) {
        return;
    }

    // State Transition Matrix F (4x4)
    Eigen::Matrix4d F = Eigen::Matrix4d::Identity();
    F(0, 2) = dt;
    F(1, 3) = dt;

    // Process Noise Covariance Q (4x4)
    Eigen::Matrix4d Q;
    computeProcessNoiseMatrix(dt, Q);

    // Predict State: x_pred = F * x
    x_ = F * x_;

    // Predict Covariance: P_pred = F * P * F^T + Q
    P_ = F * P_ * F.transpose() + Q;

    // Maintain strict numerical symmetry
    P_ = 0.5 * (P_ + P_.transpose());

    sanitizeState();
}

void KalmanFilter2D::correct(double z_x, double z_y, double timestamp) {
    if (!is_initialized_) {
        initialize(z_x, z_y, timestamp);
        return;
    }

    const Eigen::Vector2d z(z_x, z_y);

    // Innovation (Measurement Residual): y = z - H * x
    const Eigen::Vector2d y = z - H_ * x_;

    // Innovation Covariance: S = H * P * H^T + R
    S_ = H_ * P_ * H_.transpose() + R_;

    // Invert S (2x2 matrix)
    const Eigen::Matrix2d S_inv = S_.inverse();

    // Kalman Gain: K = P * H^T * S^-1 (4x2)
    K_ = P_ * H_.transpose() * S_inv;

    // Updated State Estimate: x = x + K * y
    x_ = x_ + K_ * y;

    // Joseph Form Covariance Update: P = (I - K*H) * P * (I - K*H)^T + K * R * K^T
    const Eigen::Matrix4d I4 = Eigen::Matrix4d::Identity();
    const Eigen::Matrix4d I_minus_KH = I4 - K_ * H_;

    P_ = I_minus_KH * P_ * I_minus_KH.transpose() + K_ * R_ * K_.transpose();

    // Enforce symmetry
    P_ = 0.5 * (P_ + P_.transpose());

    last_update_time_ = timestamp;
    update_count_++;

    sanitizeState();
}

double KalmanFilter2D::getEstimatedSpeed() const noexcept {
    const double vx = x_(2);
    const double vy = x_(3);
    return std::sqrt(vx * vx + vy * vy);
}

void KalmanFilter2D::setProcessNoiseStdDev(double stddev) noexcept {
    q_accel_stddev_ = std::max(0.001, stddev);
}

void KalmanFilter2D::setMeasurementNoiseStdDev(double stddev) noexcept {
    r_gps_stddev_ = std::max(0.001, stddev);
    const double r_var = r_gps_stddev_ * r_gps_stddev_;
    R_(0, 0) = r_var;
    R_(1, 1) = r_var;
}

bool KalmanFilter2D::hasValidState() const noexcept {
    for (int i = 0; i < 4; ++i) {
        if (std::isnan(x_(i)) || std::isinf(x_(i))) return false;
        for (int j = 0; j < 4; ++j) {
            if (std::isnan(P_(i, j)) || std::isinf(P_(i, j))) return false;
        }
    }
    return true;
}

void KalmanFilter2D::sanitizeState() noexcept {
    for (int i = 0; i < 4; ++i) {
        if (std::isnan(x_(i)) || std::isinf(x_(i))) {
            x_(i) = 0.0;
        }
        // Ensure variances on diagonal remain positive
        if (std::isnan(P_(i, i)) || std::isinf(P_(i, i)) || P_(i, i) < 1e-6) {
            P_(i, i) = (i < 2) ? (r_gps_stddev_ * r_gps_stddev_) : (p_init_vel_stddev_ * p_init_vel_stddev_);
        }
    }
}

std::string KalmanFilter2D::toString() const {
    std::ostringstream ss;
    ss << "KalmanFilter2D[x=" << std::fixed << std::setprecision(2) << x_(0)
       << "m, y=" << x_(1) << "m, vx=" << x_(2)
       << "m/s, vy=" << x_(3) << "m/s, updates=" << update_count_ << "]";
    return ss.str();
}

} // namespace SmartTraffic
