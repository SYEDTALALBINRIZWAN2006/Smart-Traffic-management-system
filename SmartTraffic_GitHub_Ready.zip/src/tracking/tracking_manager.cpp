#include "smart_traffic/tracking/tracking_manager.h"
#include <filesystem>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <unordered_set>

namespace SmartTraffic {

TrackingManager::TrackingManager(double process_noise_stddev,
                                 double measurement_noise_stddev,
                                 const std::string& csv_output_path)
    : process_noise_stddev_(process_noise_stddev),
      measurement_noise_stddev_(measurement_noise_stddev),
      csv_output_path_(csv_output_path) {
    if (!csv_output_path_.empty()) {
        openExportFile(csv_output_path_);
    }
}

TrackingManager::~TrackingManager() {
    closeExportFile();
}

void TrackingManager::openExportFile(const std::string& output_path) {
    closeExportFile();
    csv_output_path_ = output_path;

    if (csv_output_path_.empty()) {
        is_csv_open_ = false;
        return;
    }

    std::filesystem::path path(csv_output_path_);
    if (path.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(path.parent_path(), ec);
    }

    csv_stream_.open(csv_output_path_, std::ios::out | std::ios::trunc);
    if (csv_stream_.is_open()) {
        is_csv_open_ = true;
        // Header per requirements: timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y,estimated_x,estimated_y,gps_error,kalman_error,gps_fresh
        csv_stream_ << "timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y,estimated_x,estimated_y,gps_error,kalman_error,gps_fresh\n";
        csv_stream_ << std::fixed << std::setprecision(4);
    }
}

void TrackingManager::closeExportFile() {
    if (is_csv_open_ && csv_stream_.is_open()) {
        csv_stream_.flush();
        csv_stream_.close();
        is_csv_open_ = false;
    }
}

void TrackingManager::handleVehicleDeparted(uint32_t vehicle_id) {
    filters_.erase(vehicle_id);
}

const KalmanFilter2D* TrackingManager::getFilter(uint32_t vehicle_id) const {
    const auto it = filters_.find(vehicle_id);
    if (it != filters_.end()) {
        return &(it->second);
    }
    return nullptr;
}

void TrackingManager::update(double current_time,
                             double dt,
                             const std::vector<std::shared_ptr<Vehicle>>& active_vehicles,
                             const std::vector<GpsMeasurement>& fresh_gps_measurements,
                             bool is_gps_tick) {
    // Map fresh GPS measurements by vehicle_id for fast O(1) lookup
    std::unordered_map<uint32_t, const GpsMeasurement*> gps_by_id;
    if (is_gps_tick) {
        for (const auto& m : fresh_gps_measurements) {
            gps_by_id[m.vehicle_id] = &m;
        }
    }

    std::unordered_set<uint32_t> current_active_ids;
    current_active_ids.reserve(active_vehicles.size());

    for (const auto& vehicle : active_vehicles) {
        if (!vehicle) continue;
        const uint32_t vid = vehicle->getId();
        current_active_ids.insert(vid);

        auto filter_it = filters_.find(vid);
        const auto gps_it = gps_by_id.find(vid);
        const bool has_fresh_gps = (gps_it != gps_by_id.end());

        if (filter_it == filters_.end()) {
            // Requirement 7: Initialize each filter from the first available GPS measurement.
            // Do not initialize using hidden ground-truth position or velocity.
            if (has_fresh_gps) {
                const auto* m = gps_it->second;
                auto& new_kf = filters_[vid];
                new_kf.setProcessNoiseStdDev(process_noise_stddev_);
                new_kf.setMeasurementNoiseStdDev(measurement_noise_stddev_);
                new_kf.initialize(m->gps_x, m->gps_y, current_time);
                total_vehicles_tracked_++;
                filter_it = filters_.find(vid);
            } else {
                // Vehicle entered simulation between GPS sampling intervals; wait for next fresh GPS
                continue;
            }
        } else {
            // Requirement 8: Predict at every simulation tick using the correct delta time.
            filter_it->second.predict(dt);

            // Requirement 9: Correct only when a new GPS measurement is available, normally every 1 second.
            if (has_fresh_gps) {
                const auto* m = gps_it->second;
                filter_it->second.correct(m->gps_x, m->gps_y, current_time);
            }
        }

        // Extract tracking telemetry and calculate metrics
        const auto& kf = filter_it->second;
        const double act_x = vehicle->getPosition().x;
        const double act_y = vehicle->getPosition().y;
        const double est_x = kf.getEstimatedX();
        const double est_y = kf.getEstimatedY();

        const double dx_k = est_x - act_x;
        const double dy_k = est_y - act_y;
        const double k_err = std::sqrt(dx_k * dx_k + dy_k * dy_k);

        // Metric updates (always calculated regardless of CSV export status)
        sum_squared_kalman_error_all_ += k_err * k_err;
        total_ticks_count_++;
        if (k_err > max_kalman_error_) {
            max_kalman_error_ = k_err;
        }

        if (has_fresh_gps) {
            const auto* m = gps_it->second;
            const double g_err = m->error_distance;

            sum_squared_gps_error_ += g_err * g_err;
            sum_squared_kalman_error_comparable_ += k_err * k_err;
            comparable_sample_count_++;
            if (g_err > max_gps_error_) {
                max_gps_error_ = g_err;
            }
        }

        // Export record to CSV if open
        if (is_csv_open_) {
            if (has_fresh_gps) {
                const auto* m = gps_it->second;
                const double g_err = m->error_distance;

                csv_stream_ << current_time << ","
                            << vid << ","
                            << act_x << ","
                            << act_y << ","
                            << m->gps_x << ","
                            << m->gps_y << ","
                            << est_x << ","
                            << est_y << ","
                            << g_err << ","
                            << k_err << ",1\n";
            } else {
                // Exactly 11 fields: timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y,estimated_x,estimated_y,gps_error,kalman_error,gps_fresh
                // Fields 5 (gps_x), 6 (gps_y) and 9 (gps_error) are empty on prediction ticks
                csv_stream_ << current_time << ","
                            << vid << ","
                            << act_x << ","
                            << act_y << ",,,"
                            << est_x << ","
                            << est_y << ",,"
                            << k_err << ",0\n";
            }
        }
    }

    // Clean up filters for departed vehicles to prevent cross-contamination and leaks
    for (auto it = filters_.begin(); it != filters_.end(); ) {
        if (current_active_ids.find(it->first) == current_active_ids.end()) {
            it = filters_.erase(it);
        } else {
            ++it;
        }
    }
}

TrackingMetrics TrackingManager::computeMetrics() const noexcept {
    TrackingMetrics m;
    m.comparable_sample_count = comparable_sample_count_;
    m.total_prediction_ticks = total_ticks_count_;
    m.total_vehicles_tracked = total_vehicles_tracked_;
    m.max_gps_error_meters = max_gps_error_;
    m.max_kalman_error_meters = max_kalman_error_;

    if (comparable_sample_count_ > 0) {
        m.gps_rmse_meters = std::sqrt(sum_squared_gps_error_ / comparable_sample_count_);
        m.kalman_rmse_meters = std::sqrt(sum_squared_kalman_error_comparable_ / comparable_sample_count_);
        if (m.gps_rmse_meters > 1e-6) {
            m.error_reduction_percentage = ((m.gps_rmse_meters - m.kalman_rmse_meters) / m.gps_rmse_meters) * 100.0;
        }
    }

    if (total_ticks_count_ > 0) {
        m.kalman_all_ticks_rmse_meters = std::sqrt(sum_squared_kalman_error_all_ / total_ticks_count_);
    }

    return m;
}

void TrackingManager::reset() {
    filters_.clear();
    comparable_sample_count_ = 0;
    sum_squared_gps_error_ = 0.0;
    sum_squared_kalman_error_comparable_ = 0.0;
    max_gps_error_ = 0.0;
    total_ticks_count_ = 0;
    sum_squared_kalman_error_all_ = 0.0;
    max_kalman_error_ = 0.0;
    total_vehicles_tracked_ = 0;

    if (!csv_output_path_.empty()) {
        openExportFile(csv_output_path_);
    }
}

} // namespace SmartTraffic
