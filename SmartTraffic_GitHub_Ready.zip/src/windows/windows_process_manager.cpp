#include "smart_traffic/windows/windows_process_manager.h"
#include "smart_traffic/windows/windows_file_io.h"
#include <vector>
#include <algorithm>

namespace SmartTraffic {
namespace Windows {

bool WindowsProcess::isRunning() const noexcept {
    if (!process_handle_.isValid()) return false;
    DWORD exit_code = 0;
    if (GetExitCodeProcess(process_handle_.get(), &exit_code)) {
        return (exit_code == STILL_ACTIVE);
    }
    return false;
}

bool WindowsProcess::waitForExit(DWORD timeout_ms, DWORD* out_exit_code) const noexcept {
    if (!process_handle_.isValid()) return false;
    const DWORD wait_res = WaitForSingleObject(process_handle_.get(), timeout_ms);
    if (wait_res == WAIT_OBJECT_0) {
        if (out_exit_code) {
            GetExitCodeProcess(process_handle_.get(), out_exit_code);
        }
        return true;
    }
    return false;
}

bool WindowsProcess::getExitCode(DWORD& out_exit_code) const noexcept {
    if (!process_handle_.isValid()) return false;
    return GetExitCodeProcess(process_handle_.get(), &out_exit_code) != 0;
}

bool WindowsProcess::terminate(DWORD exit_code) noexcept {
    if (!process_handle_.isValid()) return false;
    return TerminateProcess(process_handle_.get(), exit_code) != 0;
}

bool WindowsProcessManager::launchProcess(const std::string& executable_path,
                                          const std::string& command_line_args,
                                          WindowsProcess& out_process,
                                          bool create_no_window) {
    return launchProcess(WindowsFileIO::utf8ToWide(executable_path),
                         WindowsFileIO::utf8ToWide(command_line_args),
                         out_process,
                         create_no_window);
}

bool WindowsProcessManager::launchProcess(const std::wstring& executable_path,
                                          const std::wstring& command_line_args,
                                          WindowsProcess& out_process,
                                          bool create_no_window) {
    out_process.close();

    STARTUPINFOW si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);

    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));

    // CreateProcessW requires a mutable buffer for the command line parameter
    std::wstring full_cmd;
    if (!executable_path.empty()) {
        full_cmd = L"\"" + executable_path + L"\" " + command_line_args;
    } else {
        full_cmd = command_line_args;
    }

    std::vector<wchar_t> cmd_buffer(full_cmd.begin(), full_cmd.end());
    cmd_buffer.push_back(L'\0');

    DWORD creation_flags = 0;
    if (create_no_window) {
        creation_flags |= CREATE_NO_WINDOW;
    }

    const BOOL success = CreateProcessW(
        executable_path.empty() ? NULL : executable_path.c_str(),
        cmd_buffer.data(),
        NULL, // Process security attributes
        NULL, // Thread security attributes
        FALSE, // Inherit handles
        creation_flags,
        NULL, // Environment
        NULL, // Current directory
        &si,
        &pi
    );

    if (!success) {
        return false;
    }

    out_process = WindowsProcess(pi.hProcess, pi.hThread, pi.dwProcessId, pi.dwThreadId);
    return true;
}

bool WindowsProcessManager::waitForAll(const std::vector<WindowsProcess>& processes, DWORD timeout_ms) {
    if (processes.empty()) return true;

    std::vector<HANDLE> handles;
    handles.reserve(processes.size());
    for (const auto& proc : processes) {
        if (proc.isValid()) {
            handles.push_back(proc.getProcessHandle());
        }
    }

    if (handles.empty()) return true;
    if (handles.size() > MAXIMUM_WAIT_OBJECTS) return false;

    const DWORD wait_res = WaitForMultipleObjects(
        static_cast<DWORD>(handles.size()),
        handles.data(),
        TRUE, // Wait for all
        timeout_ms
    );

    return (wait_res >= WAIT_OBJECT_0 && wait_res < WAIT_OBJECT_0 + handles.size());
}

void WindowsProcessManager::terminateAll(std::vector<WindowsProcess>& processes) {
    for (auto& proc : processes) {
        if (proc.isValid() && proc.isRunning()) {
            proc.terminate(1);
        }
        proc.close();
    }
}

std::string WindowsProcessManager::getCurrentExecutableDirectory() {
    wchar_t buffer[MAX_PATH];
    const DWORD len = GetModuleFileNameW(NULL, buffer, MAX_PATH);
    if (len == 0 || len >= MAX_PATH) return "";
    std::wstring path(buffer, len);
    const size_t last_slash = path.find_last_of(L"\\/");
    if (last_slash != std::wstring::npos) {
        return WindowsFileIO::wideToUtf8(path.substr(0, last_slash));
    }
    return "";
}

} // namespace Windows
} // namespace SmartTraffic
