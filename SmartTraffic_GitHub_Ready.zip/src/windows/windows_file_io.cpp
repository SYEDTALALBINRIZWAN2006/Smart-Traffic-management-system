#include "smart_traffic/windows/windows_file_io.h"
#include <sstream>
#include <algorithm>
#include <filesystem>

namespace SmartTraffic {
namespace Windows {

std::wstring WindowsFileIO::utf8ToWide(const std::string& utf8_str) {
    if (utf8_str.empty()) return L"";
    const int required_chars = MultiByteToWideChar(CP_UTF8, 0, utf8_str.c_str(), -1, NULL, 0);
    if (required_chars <= 0) return L"";
    std::wstring result(static_cast<size_t>(required_chars - 1), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, utf8_str.c_str(), -1, &result[0], required_chars);
    return result;
}

std::string WindowsFileIO::wideToUtf8(const std::wstring& wide_str) {
    if (wide_str.empty()) return "";
    const int required_bytes = WideCharToMultiByte(CP_UTF8, 0, wide_str.c_str(), -1, NULL, 0, NULL, NULL);
    if (required_bytes <= 0) return "";
    std::string result(static_cast<size_t>(required_bytes - 1), '\0');
    WideCharToMultiByte(CP_UTF8, 0, wide_str.c_str(), -1, &result[0], required_bytes, NULL, NULL);
    return result;
}

bool WindowsFileIO::writeAllText(const std::string& filepath, const std::string& content) {
    return writeAllText(utf8ToWide(filepath), content);
}

bool WindowsFileIO::writeAllText(const std::wstring& filepath, const std::string& content) {
    // Ensure parent directory exists
    std::filesystem::path p(filepath);
    if (p.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(p.parent_path(), ec);
    }

    ScopedHandle handle(CreateFileW(filepath.c_str(),
                                    GENERIC_WRITE,
                                    0, // Exclusive access
                                    NULL,
                                    CREATE_ALWAYS,
                                    FILE_ATTRIBUTE_NORMAL,
                                    NULL));

    if (!handle.isValid()) {
        return false;
    }

    if (content.empty()) {
        return true;
    }

    DWORD total_written = 0;
    const DWORD to_write = static_cast<DWORD>(content.size());
    const char* ptr = content.data();

    while (total_written < to_write) {
        DWORD bytes_written = 0;
        const DWORD chunk = to_write - total_written;
        if (!WriteFile(handle.get(), ptr + total_written, chunk, &bytes_written, NULL)) {
            return false;
        }
        if (bytes_written == 0) {
            return false;
        }
        total_written += bytes_written;
    }

    return true;
}

bool WindowsFileIO::appendAllText(const std::string& filepath, const std::string& content) {
    return appendAllText(utf8ToWide(filepath), content);
}

bool WindowsFileIO::appendAllText(const std::wstring& filepath, const std::string& content) {
    std::filesystem::path p(filepath);
    if (p.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(p.parent_path(), ec);
    }

    ScopedHandle handle(CreateFileW(filepath.c_str(),
                                    FILE_APPEND_DATA,
                                    FILE_SHARE_READ,
                                    NULL,
                                    OPEN_ALWAYS,
                                    FILE_ATTRIBUTE_NORMAL,
                                    NULL));

    if (!handle.isValid()) {
        return false;
    }

    if (content.empty()) {
        return true;
    }

    DWORD total_written = 0;
    const DWORD to_write = static_cast<DWORD>(content.size());
    const char* ptr = content.data();

    while (total_written < to_write) {
        DWORD bytes_written = 0;
        const DWORD chunk = to_write - total_written;
        if (!WriteFile(handle.get(), ptr + total_written, chunk, &bytes_written, NULL)) {
            return false;
        }
        if (bytes_written == 0) {
            return false;
        }
        total_written += bytes_written;
    }

    return true;
}

bool WindowsFileIO::readAllText(const std::string& filepath, std::string& out_content) {
    return readAllText(utf8ToWide(filepath), out_content);
}

bool WindowsFileIO::readAllText(const std::wstring& filepath, std::string& out_content) {
    out_content.clear();

    ScopedHandle handle(CreateFileW(filepath.c_str(),
                                    GENERIC_READ,
                                    FILE_SHARE_READ,
                                    NULL,
                                    OPEN_EXISTING,
                                    FILE_ATTRIBUTE_NORMAL,
                                    NULL));

    if (!handle.isValid()) {
        return false;
    }

    LARGE_INTEGER file_size;
    if (!GetFileSizeEx(handle.get(), &file_size)) {
        return false;
    }

    if (file_size.QuadPart == 0) {
        return true;
    }

    // Protect against huge files exceeding 256MB in benchmark context
    if (file_size.QuadPart > 256 * 1024 * 1024) {
        return false;
    }

    const size_t total_size = static_cast<size_t>(file_size.QuadPart);
    out_content.resize(total_size);

    DWORD total_read = 0;
    char* ptr = &out_content[0];

    while (total_read < total_size) {
        DWORD bytes_read = 0;
        const DWORD chunk = static_cast<DWORD>(std::min<size_t>(total_size - total_read, 64 * 1024 * 1024));
        if (!ReadFile(handle.get(), ptr + total_read, chunk, &bytes_read, NULL)) {
            return false;
        }
        if (bytes_read == 0) {
            break;
        }
        total_read += bytes_read;
    }

    out_content.resize(total_read);
    return true;
}

bool WindowsFileIO::fileExists(const std::string& filepath) {
    const std::wstring wide_path = utf8ToWide(filepath);
    const DWORD attrs = GetFileAttributesW(wide_path.c_str());
    return (attrs != INVALID_FILE_ATTRIBUTES && !(attrs & FILE_ATTRIBUTE_DIRECTORY));
}

uint64_t WindowsFileIO::getFileSize(const std::string& filepath) {
    const std::wstring wide_path = utf8ToWide(filepath);
    ScopedHandle handle(CreateFileW(wide_path.c_str(),
                                    GENERIC_READ,
                                    FILE_SHARE_READ,
                                    NULL,
                                    OPEN_EXISTING,
                                    FILE_ATTRIBUTE_NORMAL,
                                    NULL));
    if (!handle.isValid()) {
        return 0;
    }
    LARGE_INTEGER sz;
    if (GetFileSizeEx(handle.get(), &sz)) {
        return static_cast<uint64_t>(sz.QuadPart);
    }
    return 0;
}

bool WindowsFileIO::readGpsDataset(const std::string& csv_path, std::vector<GpsMeasurement>& out_measurements) {
    out_measurements.clear();
    std::string content;
    if (!readAllText(csv_path, content)) {
        return false;
    }

    std::istringstream stream(content);
    std::string line;

    // Read header line: timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y
    if (!std::getline(stream, line)) {
        return false;
    }

    while (std::getline(stream, line)) {
        if (line.empty()) continue;
        std::istringstream line_stream(line);
        std::string token;
        std::vector<std::string> tokens;
        while (std::getline(line_stream, token, ',')) {
            tokens.push_back(token);
        }
        if (tokens.size() >= 6) {
            try {
                GpsMeasurement m;
                m.timestamp = std::stod(tokens[0]);
                m.vehicle_id = static_cast<uint32_t>(std::stoul(tokens[1]));
                m.actual_x = std::stod(tokens[2]);
                m.actual_y = std::stod(tokens[3]);
                m.gps_x = std::stod(tokens[4]);
                m.gps_y = std::stod(tokens[5]);
                const double dx = m.gps_x - m.actual_x;
                const double dy = m.gps_y - m.actual_y;
                m.error_distance = std::sqrt(dx * dx + dy * dy);
                out_measurements.push_back(m);
            } catch (...) {
                // Skip malformed rows
            }
        }
    }

    return !out_measurements.empty();
}

} // namespace Windows
} // namespace SmartTraffic
