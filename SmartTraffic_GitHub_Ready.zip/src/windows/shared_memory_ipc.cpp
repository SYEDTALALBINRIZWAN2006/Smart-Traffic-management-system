#include "smart_traffic/windows/shared_memory_ipc.h"
#include "smart_traffic/windows/windows_file_io.h"
#include <cstring>
#include <algorithm>

namespace SmartTraffic {
namespace Windows {

SharedMemoryIPC::~SharedMemoryIPC() noexcept {
    close();
}

SharedMemoryIPC::SharedMemoryIPC(SharedMemoryIPC&& other) noexcept
    : session_id_(std::move(other.session_id_)),
      channel_id_(other.channel_id_),
      mapping_handle_(std::move(other.mapping_handle_)),
      task_event_(std::move(other.task_event_)),
      result_event_(std::move(other.result_event_)),
      channel_view_(other.channel_view_) {
    other.channel_view_ = nullptr;
}

SharedMemoryIPC& SharedMemoryIPC::operator=(SharedMemoryIPC&& other) noexcept {
    if (this != &other) {
        close();
        session_id_ = std::move(other.session_id_);
        channel_id_ = other.channel_id_;
        mapping_handle_ = std::move(other.mapping_handle_);
        task_event_ = std::move(other.task_event_);
        result_event_ = std::move(other.result_event_);
        channel_view_ = other.channel_view_;
        other.channel_view_ = nullptr;
    }
    return *this;
}

void SharedMemoryIPC::close() noexcept {
    if (channel_view_) {
        UnmapViewOfFile(channel_view_);
        channel_view_ = nullptr;
    }
    mapping_handle_.close();
    task_event_.close();
    result_event_.close();
    channel_id_ = 0;
    session_id_.clear();
}

bool SharedMemoryIPC::createChannel(const std::string& session_id, uint32_t channel_id) {
    close();
    session_id_ = session_id;
    channel_id_ = channel_id;

    const std::string map_name = "Local\\SmartTraffic_SHM_" + session_id + "_" + std::to_string(channel_id);
    const std::string task_name = "Local\\SmartTraffic_TSK_" + session_id + "_" + std::to_string(channel_id);
    const std::string res_name = "Local\\SmartTraffic_RES_" + session_id + "_" + std::to_string(channel_id);

    // Create File Mapping in paging file
    mapping_handle_.reset(CreateFileMappingW(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        sizeof(SharedMemoryChannel),
        WindowsFileIO::utf8ToWide(map_name).c_str()
    ));

    if (!mapping_handle_.isValid()) {
        return false;
    }

    // Create synchronization events (auto-reset)
    task_event_.reset(CreateEventW(
        NULL,
        FALSE, // Auto-reset
        FALSE, // Initial state: non-signaled
        WindowsFileIO::utf8ToWide(task_name).c_str()
    ));

    result_event_.reset(CreateEventW(
        NULL,
        FALSE, // Auto-reset
        FALSE, // Initial state: non-signaled
        WindowsFileIO::utf8ToWide(res_name).c_str()
    ));

    if (!task_event_.isValid() || !result_event_.isValid()) {
        close();
        return false;
    }

    // Map view of file into address space
    void* view = MapViewOfFile(
        mapping_handle_.get(),
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        sizeof(SharedMemoryChannel)
    );

    if (!view) {
        close();
        return false;
    }

    channel_view_ = static_cast<SharedMemoryChannel*>(view);
    ZeroMemory(channel_view_, sizeof(SharedMemoryChannel));

    channel_view_->magic_signature = IPC_MAGIC_SIGNATURE;
    channel_view_->protocol_version = IPC_PROTOCOL_VERSION;
    channel_view_->channel_id = channel_id;
    channel_view_->command = IPC_CMD_IDLE;
    channel_view_->task_sequence_number = 0;
    channel_view_->result_sequence_number = 0;

    return true;
}

bool SharedMemoryIPC::openChannel(const std::string& session_id, uint32_t channel_id) {
    close();
    session_id_ = session_id;
    channel_id_ = channel_id;

    const std::string map_name = "Local\\SmartTraffic_SHM_" + session_id + "_" + std::to_string(channel_id);
    const std::string task_name = "Local\\SmartTraffic_TSK_" + session_id + "_" + std::to_string(channel_id);
    const std::string res_name = "Local\\SmartTraffic_RES_" + session_id + "_" + std::to_string(channel_id);

    mapping_handle_.reset(OpenFileMappingW(
        FILE_MAP_ALL_ACCESS,
        FALSE,
        WindowsFileIO::utf8ToWide(map_name).c_str()
    ));

    if (!mapping_handle_.isValid()) {
        return false;
    }

    task_event_.reset(OpenEventW(
        SYNCHRONIZE | EVENT_MODIFY_STATE,
        FALSE,
        WindowsFileIO::utf8ToWide(task_name).c_str()
    ));

    result_event_.reset(OpenEventW(
        SYNCHRONIZE | EVENT_MODIFY_STATE,
        FALSE,
        WindowsFileIO::utf8ToWide(res_name).c_str()
    ));

    if (!task_event_.isValid() || !result_event_.isValid()) {
        close();
        return false;
    }

    void* view = MapViewOfFile(
        mapping_handle_.get(),
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        sizeof(SharedMemoryChannel)
    );

    if (!view) {
        close();
        return false;
    }

    channel_view_ = static_cast<SharedMemoryChannel*>(view);
    if (channel_view_->magic_signature != IPC_MAGIC_SIGNATURE ||
        channel_view_->protocol_version != IPC_PROTOCOL_VERSION) {
        close();
        return false;
    }

    return true;
}

bool SharedMemoryIPC::dispatchTasksAsync(const std::vector<IpcVehicleTask>& tasks) {
    if (!channel_view_ || !task_event_.isValid() || !result_event_.isValid()) {
        return false;
    }

    if (tasks.size() > MAX_IPC_VEHICLES) {
        return false;
    }

    const uint32_t count = static_cast<uint32_t>(tasks.size());

    // Write tasks into shared task buffer
    if (count > 0) {
        std::memcpy(const_cast<IpcVehicleTask*>(channel_view_->tasks), tasks.data(), count * sizeof(IpcVehicleTask));
    }

    channel_view_->task_count = count;
    channel_view_->task_sequence_number++;
    channel_view_->command = IPC_CMD_PROCESS_BATCH;

    MemoryBarrier();

    // Signal worker that tasks are ready
    if (!SetEvent(task_event_.get())) {
        return false;
    }

    return true;
}

bool SharedMemoryIPC::waitForResult(DWORD timeout_ms) const noexcept {
    if (!result_event_.isValid()) {
        return false;
    }
    const DWORD wait_res = WaitForSingleObject(result_event_.get(), timeout_ms);
    return (wait_res == WAIT_OBJECT_0);
}

bool SharedMemoryIPC::collectResults(std::vector<IpcVehicleResult>& out_results) {
    if (!channel_view_) {
        return false;
    }

    MemoryBarrier();

    const uint32_t res_count = channel_view_->result_count;
    if (res_count > MAX_IPC_VEHICLES) {
        return false;
    }

    out_results.resize(res_count);
    if (res_count > 0) {
        std::memcpy(out_results.data(), const_cast<const IpcVehicleResult*>(channel_view_->results), res_count * sizeof(IpcVehicleResult));
    }

    return true;
}

bool SharedMemoryIPC::dispatchTasksAndWait(const std::vector<IpcVehicleTask>& tasks,
                                           std::vector<IpcVehicleResult>& out_results,
                                           DWORD timeout_ms) {
    if (!dispatchTasksAsync(tasks)) {
        return false;
    }

    if (!waitForResult(timeout_ms)) {
        return false;
    }

    return collectResults(out_results);
}

bool SharedMemoryIPC::sendShutdownSignal(DWORD /*timeout_ms*/) {
    if (!channel_view_ || !task_event_.isValid()) {
        return false;
    }

    channel_view_->command = IPC_CMD_SHUTDOWN;
    MemoryBarrier();

    return SetEvent(task_event_.get()) != 0;
}

IpcCommand SharedMemoryIPC::workerWaitForTask(DWORD timeout_ms) {
    if (!channel_view_ || !task_event_.isValid()) {
        return IPC_CMD_SHUTDOWN;
    }

    const DWORD wait_res = WaitForSingleObject(task_event_.get(), timeout_ms);
    if (wait_res == WAIT_OBJECT_0) {
        MemoryBarrier();
        return static_cast<IpcCommand>(channel_view_->command);
    }

    return IPC_CMD_IDLE;
}

bool SharedMemoryIPC::workerSignalResultReady() {
    if (!channel_view_ || !result_event_.isValid()) {
        return false;
    }

    channel_view_->result_sequence_number++;
    MemoryBarrier();

    return SetEvent(result_event_.get()) != 0;
}

} // namespace Windows
} // namespace SmartTraffic
