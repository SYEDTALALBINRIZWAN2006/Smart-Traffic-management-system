#include "smart_traffic/windows/kalman_benchmark_runner.h"
#include "smart_traffic/windows/windows_file_io.h"
#include <sstream>
#include <iomanip>
#include <cmath>
#include <random>
#include <algorithm>
#include <chrono>

namespace SmartTraffic {
namespace Windows {

namespace {

static std::string resolveWorkerExecutable(const std::string& preferred_path) {
    if (WindowsFileIO::fileExists(preferred_path)) {
        return preferred_path;
    }
    const std::string cur_dir = WindowsProcessManager::getCurrentExecutableDirectory();
    if (!cur_dir.empty()) {
        std::string cand1 = cur_dir + "\\kalman_worker.exe";
        if (WindowsFileIO::fileExists(cand1)) return cand1;
        std::string cand2 = cur_dir + "\\build\\kalman_worker.exe";
        if (WindowsFileIO::fileExists(cand2)) return cand2;
    }
    std::string cand3 = "build\\kalman_worker.exe";
    if (WindowsFileIO::fileExists(cand3)) return cand3;
    std::string cand4 = "kalman_worker.exe";
    if (WindowsFileIO::fileExists(cand4)) return cand4;
    return preferred_path;
}

static inline uint64_t getProcessCpuTime100ns(HANDLE hProcess) {
    if (!hProcess || hProcess == INVALID_HANDLE_VALUE) return 0;
    FILETIME creation_time{}, exit_time{}, kernel_time{}, user_time{};
    if (GetProcessTimes(hProcess, &creation_time, &exit_time, &kernel_time, &user_time)) {
        ULARGE_INTEGER k, u;
        k.LowPart = kernel_time.dwLowDateTime;
        k.HighPart = kernel_time.dwHighDateTime;
        u.LowPart = user_time.dwLowDateTime;
        u.HighPart = user_time.dwHighDateTime;
        return k.QuadPart + u.QuadPart;
    }
    return 0;
}

} // anonymous namespace

KalmanBenchmarkRunner::KalmanBenchmarkRunner(const BenchmarkConfig& config)
    : config_(config) {
    QueryPerformanceFrequency(&timer_frequency_);
}

KalmanBenchmarkRunner::~KalmanBenchmarkRunner() = default;

std::vector<std::vector<IpcVehicleTask>> KalmanBenchmarkRunner::generateSyntheticWorkload(uint32_t vehicle_count,
                                                                                         uint32_t tick_count,
                                                                                         uint64_t seed) {
    std::mt19937_64 rng(seed);
    std::normal_distribution<double> noise_dist(0.0, 2.5); // 2.5m GPS noise
    std::uniform_real_distribution<double> speed_dist(10.0, 15.0);
    std::uniform_real_distribution<double> heading_dist(0.0, 6.2831853);

    struct SyntheticVehicle {
        uint32_t id;
        double x;
        double y;
        double vx;
        double vy;
    };

    std::vector<SyntheticVehicle> vehicles;
    vehicles.reserve(vehicle_count);
    for (uint32_t i = 1; i <= vehicle_count; ++i) {
        SyntheticVehicle sv;
        sv.id = i;
        sv.x = (i % 20) * 15.0 - 150.0;
        sv.y = (i / 20) * 15.0 - 150.0;
        const double spd = speed_dist(rng);
        const double hdg = heading_dist(rng);
        sv.vx = spd * std::cos(hdg);
        sv.vy = spd * std::sin(hdg);
        vehicles.push_back(sv);
    }

    std::vector<std::vector<IpcVehicleTask>> workload(tick_count);
    for (uint32_t t = 0; t < tick_count; ++t) {
        const double current_time = t * 0.1;
        const double dt = 0.1;
        const bool has_gps = (t % 10 == 0);

        workload[t].reserve(vehicle_count);
        for (auto& v : vehicles) {
            v.x += v.vx * dt;
            v.y += v.vy * dt;

            IpcVehicleTask task;
            task.vehicle_id = v.id;
            task.has_fresh_gps = has_gps ? 1 : 0;
            task.is_departed = 0;
            task.timestamp = current_time;
            task.dt = dt;
            task.gps_x = v.x + noise_dist(rng);
            task.gps_y = v.y + noise_dist(rng);

            workload[t].push_back(task);
        }
    }

    return workload;
}

KalmanBenchmarkRunner::BenchmarkRunMeasurement KalmanBenchmarkRunner::executeSequential(
    uint32_t vehicle_count,
    const std::vector<std::vector<IpcVehicleTask>>& workload) {
    (void)vehicle_count;
    BenchmarkRunMeasurement m;

    const uint64_t cpu_start_100ns = getProcessCpuTime100ns(GetCurrentProcess());

    LARGE_INTEGER start_time, end_time;
    QueryPerformanceCounter(&start_time);

    std::unordered_map<uint32_t, KalmanFilter2D> filters;
    const size_t tick_count = workload.size();

    for (size_t t = 0; t < tick_count; ++t) {
        const auto& tasks = workload[t];
        for (const auto& task : tasks) {
            if (task.is_departed) {
                filters.erase(task.vehicle_id);
                continue;
            }

            auto it = filters.find(task.vehicle_id);
            if (it == filters.end()) {
                if (task.has_fresh_gps) {
                    auto& kf = filters[task.vehicle_id];
                    kf.setProcessNoiseStdDev(config_.process_noise_stddev);
                    kf.setMeasurementNoiseStdDev(config_.measurement_noise_stddev);
                    kf.initialize(task.gps_x, task.gps_y, task.timestamp);
                }
            } else {
                it->second.predict(task.dt);
                if (task.has_fresh_gps) {
                    it->second.correct(task.gps_x, task.gps_y, task.timestamp);
                }
            }

            if (t + 1 == tick_count) {
                auto fit = filters.find(task.vehicle_id);
                if (fit != filters.end()) {
                    IpcVehicleResult res;
                    res.vehicle_id = task.vehicle_id;
                    res.status = 0;
                    res.estimated_x = fit->second.getEstimatedX();
                    res.estimated_y = fit->second.getEstimatedY();
                    res.estimated_vx = fit->second.getEstimatedVx();
                    res.estimated_vy = fit->second.getEstimatedVy();
                    m.final_step_results.push_back(res);
                }
            }
        }
    }

    QueryPerformanceCounter(&end_time);
    const uint64_t cpu_end_100ns = getProcessCpuTime100ns(GetCurrentProcess());

    m.startup_ms = 0.0;
    m.compute_ms = ((end_time.QuadPart - start_time.QuadPart) * 1000.0) / timer_frequency_.QuadPart;
    m.total_ms = m.compute_ms;

    ProcessMemoryMetrics mem;
    if (WindowsMemoryManager::queryMemoryMetrics(mem)) {
        m.working_set = mem.working_set_bytes;
        m.private_bytes = mem.private_bytes;
    }

    // Real measured CPU time calculation
    SYSTEM_INFO sys_info;
    GetSystemInfo(&sys_info);
    const DWORD num_cores = sys_info.dwNumberOfProcessors > 0 ? sys_info.dwNumberOfProcessors : 1;
    const double wall_time_100ns = (m.compute_ms / 1000.0) * 10000000.0;
    const uint64_t delta_cpu_100ns = (cpu_end_100ns >= cpu_start_100ns) ? (cpu_end_100ns - cpu_start_100ns) : 0;

    if (wall_time_100ns > 0.0) {
        const double pct = (static_cast<double>(delta_cpu_100ns) / (wall_time_100ns * num_cores)) * 100.0;
        m.cpu_percent = std::clamp(pct, 0.0, 100.0);
    } else {
        m.cpu_percent = 0.0;
    }

    m.success = true;
    return m;
}

KalmanBenchmarkRunner::BenchmarkRunMeasurement KalmanBenchmarkRunner::executeParallel(
    uint32_t vehicle_count,
    uint32_t worker_count,
    const std::vector<std::vector<IpcVehicleTask>>& workload) {
    (void)vehicle_count;
    BenchmarkRunMeasurement m;
    m.success = false;

    if (worker_count == 0 || worker_count > MAXIMUM_WAIT_OBJECTS) {
        return m;
    }

    LARGE_INTEGER t_start, t_startup_end, t_compute_end;
    QueryPerformanceCounter(&t_start);

    // 1. Setup shared memory IPC channels
    const std::string session_id = "bench_" + std::to_string(GetCurrentProcessId()) + "_" +
                                  std::to_string(worker_count) + "_" +
                                  std::to_string(std::chrono::system_clock::now().time_since_epoch().count());

    std::vector<SharedMemoryIPC> channels(worker_count);
    for (uint32_t w = 0; w < worker_count; ++w) {
        if (!channels[w].createChannel(session_id, w)) {
            for (uint32_t cw = 0; cw <= w; ++cw) {
                channels[cw].close();
            }
            return m;
        }
    }

    // 2. Launch worker processes
    const std::string exe_path = resolveWorkerExecutable(config_.worker_executable_path);
    if (!WindowsFileIO::fileExists(exe_path)) {
        for (uint32_t w = 0; w < worker_count; ++w) {
            channels[w].close();
        }
        return m;
    }

    std::vector<WindowsProcess> workers(worker_count);
    for (uint32_t w = 0; w < worker_count; ++w) {
        std::ostringstream args;
        args << "--session " << session_id << " --channel " << w
             << " --process-noise " << config_.process_noise_stddev
             << " --meas-noise " << config_.measurement_noise_stddev;

        if (!WindowsProcessManager::launchProcess(exe_path, args.str(), workers[w])) {
            WindowsProcessManager::terminateAll(workers);
            for (uint32_t cw = 0; cw < worker_count; ++cw) {
                channels[cw].close();
            }
            return m;
        }
    }

    QueryPerformanceCounter(&t_startup_end);
    m.startup_ms = ((t_startup_end.QuadPart - t_start.QuadPart) * 1000.0) / timer_frequency_.QuadPart;

    // Record initial CPU times for parent and all child workers
    const uint64_t parent_cpu_start = getProcessCpuTime100ns(GetCurrentProcess());
    std::vector<uint64_t> workers_cpu_start(worker_count, 0);
    for (uint32_t w = 0; w < worker_count; ++w) {
        workers_cpu_start[w] = getProcessCpuTime100ns(workers[w].getProcessHandle());
    }

    // 3. Process batches across partitioned workers concurrently
    const size_t tick_count = workload.size();
    std::vector<std::vector<IpcVehicleTask>> partitioned_tasks(worker_count);
    std::vector<std::vector<IpcVehicleResult>> partitioned_results(worker_count);
    std::vector<HANDLE> result_events(worker_count);
    for (uint32_t w = 0; w < worker_count; ++w) {
        result_events[w] = channels[w].getResultEvent();
    }

    bool compute_failed = false;

    for (size_t t = 0; t < tick_count; ++t) {
        for (uint32_t w = 0; w < worker_count; ++w) {
            partitioned_tasks[w].clear();
        }

        const auto& tasks = workload[t];
        for (const auto& task : tasks) {
            const uint32_t wid = task.vehicle_id % worker_count;
            partitioned_tasks[wid].push_back(task);
        }

        // Asynchronous non-blocking dispatch to ALL workers concurrently
        for (uint32_t w = 0; w < worker_count; ++w) {
            if (!channels[w].dispatchTasksAsync(partitioned_tasks[w])) {
                compute_failed = true;
                break;
            }
        }
        if (compute_failed) break;

        // Concurrent wait for ALL workers to signal completion
        const DWORD wait_res = WaitForMultipleObjects(
            worker_count,
            result_events.data(),
            TRUE,  // Wait for all workers
            5000   // 5 second per-batch timeout
        );

        if (wait_res != WAIT_OBJECT_0) {
            // Wait failed or timed out
            compute_failed = true;
            break;
        }

        // Collect results from all worker channels
        for (uint32_t w = 0; w < worker_count; ++w) {
            if (!channels[w].collectResults(partitioned_results[w])) {
                compute_failed = true;
                break;
            }
        }
        if (compute_failed) break;

        // On final tick, gather final step results
        if (t + 1 == tick_count) {
            for (uint32_t w = 0; w < worker_count; ++w) {
                for (const auto& res : partitioned_results[w]) {
                    m.final_step_results.push_back(res);
                }
            }
        }
    }

    QueryPerformanceCounter(&t_compute_end);

    // Record final CPU times before terminating workers
    const uint64_t parent_cpu_end = getProcessCpuTime100ns(GetCurrentProcess());
    uint64_t total_delta_cpu_100ns = (parent_cpu_end >= parent_cpu_start) ? (parent_cpu_end - parent_cpu_start) : 0;
    for (uint32_t w = 0; w < worker_count; ++w) {
        const uint64_t worker_cpu_end = getProcessCpuTime100ns(workers[w].getProcessHandle());
        if (worker_cpu_end >= workers_cpu_start[w]) {
            total_delta_cpu_100ns += (worker_cpu_end - workers_cpu_start[w]);
        }
    }

    // Query aggregated process memory (parent + child workers)
    ProcessMemoryMetrics parent_mem;
    WindowsMemoryManager::queryMemoryMetrics(parent_mem);
    size_t total_working_set = parent_mem.working_set_bytes;
    size_t total_private_bytes = parent_mem.private_bytes;

    for (uint32_t w = 0; w < worker_count; ++w) {
        ProcessMemoryMetrics worker_mem;
        if (WindowsMemoryManager::queryMemoryMetrics(worker_mem, workers[w].getProcessHandle())) {
            total_working_set += worker_mem.working_set_bytes;
            total_private_bytes += worker_mem.private_bytes;
        }
    }
    m.working_set = total_working_set;
    m.private_bytes = total_private_bytes;

    // 4. Shutdown workers and clean up IPC
    for (uint32_t w = 0; w < worker_count; ++w) {
        channels[w].sendShutdownSignal(1000);
    }

    WindowsProcessManager::waitForAll(workers, 2000);
    WindowsProcessManager::terminateAll(workers);

    for (uint32_t w = 0; w < worker_count; ++w) {
        channels[w].close();
    }

    if (compute_failed) {
        m.success = false;
        return m;
    }

    m.compute_ms = ((t_compute_end.QuadPart - t_startup_end.QuadPart) * 1000.0) / timer_frequency_.QuadPart;
    m.total_ms = ((t_compute_end.QuadPart - t_start.QuadPart) * 1000.0) / timer_frequency_.QuadPart;

    // Calculate real CPU utilization percentage across all logical processors
    SYSTEM_INFO sys_info;
    GetSystemInfo(&sys_info);
    const DWORD num_cores = sys_info.dwNumberOfProcessors > 0 ? sys_info.dwNumberOfProcessors : 1;
    const double wall_time_100ns = (m.compute_ms / 1000.0) * 10000000.0;

    if (wall_time_100ns > 0.0) {
        const double pct = (static_cast<double>(total_delta_cpu_100ns) / (wall_time_100ns * num_cores)) * 100.0;
        m.cpu_percent = std::clamp(pct, 0.0, 100.0);
    } else {
        m.cpu_percent = 0.0;
    }

    m.success = true;
    return m;
}

BenchmarkResult KalmanBenchmarkRunner::runSingleBenchmark(
    uint32_t vehicle_count,
    uint32_t worker_count,
    const std::vector<std::vector<IpcVehicleTask>>& workload) {

    BenchmarkResult result;
    result.worker_count = worker_count;
    result.vehicle_count = vehicle_count;
    result.total_ticks = static_cast<uint32_t>(workload.size());
    result.total_samples_processed = static_cast<uint64_t>(vehicle_count) * result.total_ticks;

    if (worker_count <= 1) {
        result.execution_mode = "Sequential";
    } else {
        result.execution_mode = "Parallel_" + std::to_string(worker_count) + "W";
    }

    std::vector<double> compute_times;
    std::vector<double> total_times;
    std::vector<double> startup_times;
    std::vector<BenchmarkRunMeasurement> successful_measurements;

    const uint32_t trials = std::max(1U, config_.repeat_trials);
    for (uint32_t trial = 0; trial < trials; ++trial) {
        BenchmarkRunMeasurement measurement = worker_count <= 1
            ? executeSequential(vehicle_count, workload)
            : executeParallel(vehicle_count, worker_count, workload);
        if (!measurement.success) {
            // An incomplete trial invalidates the entire benchmark; do not
            // publish successful medians as if all trials had completed.
            result.success = false;
            result.numerical_equivalence_passed = false;
            result.max_numerical_diff_meters = -1.0;
            return result;
        }
        compute_times.push_back(measurement.compute_ms);
        total_times.push_back(measurement.total_ms);
        startup_times.push_back(measurement.startup_ms);
        successful_measurements.push_back(std::move(measurement));
    }

    auto median = [](std::vector<double>& values) {
        std::sort(values.begin(), values.end());
        const size_t n = values.size();
        return (n % 2) ? values[n / 2] : (values[n / 2 - 1] + values[n / 2]) / 2.0;
    };
    result.compute_time_ms = median(compute_times);
    result.total_execution_time_ms = median(total_times);
    result.startup_overhead_ms = median(startup_times);
    // Each reported resource metric is an observed measurement, never a
    // fabricated value from a failed or unrelated trial.
    const auto& representative = successful_measurements.back();
    result.peak_working_set_bytes = representative.working_set;
    result.peak_private_bytes = representative.private_bytes;
    result.cpu_utilization_percent = representative.cpu_percent;
    result.final_step_results = representative.final_step_results;
    result.success = true;

    if (result.compute_time_ms > 1e-4) {
        result.throughput_samples_per_sec = (result.total_samples_processed * 1000.0) / result.compute_time_ms;
    }

    return result;
}

std::vector<BenchmarkResult> KalmanBenchmarkRunner::runAllBenchmarks() {
    std::vector<BenchmarkResult> all_results;

    for (uint32_t fleet_size : config_.fleet_sizes) {
        const auto workload = generateSyntheticWorkload(fleet_size, config_.simulation_ticks, 42);

        // 1. Run Sequential Baseline
        BenchmarkResult seq_result = runSingleBenchmark(fleet_size, 1, workload);
        seq_result.speedup = 1.0;
        seq_result.max_numerical_diff_meters = seq_result.success ? 0.0 : -1.0;
        seq_result.numerical_equivalence_passed = seq_result.success;
        all_results.push_back(seq_result);

        const double baseline_compute_ms = seq_result.compute_time_ms;

        // Map sequential results by vehicle ID
        std::unordered_map<uint32_t, IpcVehicleResult> seq_map;
        for (const auto& r : seq_result.final_step_results) {
            seq_map.emplace(r.vehicle_id, r);
        }

        // 2. Run Parallel Benchmarks (e.g. 2 workers, 4 workers)
        for (uint32_t w : config_.worker_counts) {
            if (w <= 1) continue;

            BenchmarkResult par_result = runSingleBenchmark(fleet_size, w, workload);
            if (!par_result.success || !seq_result.success) {
                par_result.speedup = 0.0;
                par_result.max_numerical_diff_meters = -1.0;
                par_result.numerical_equivalence_passed = false;
                all_results.push_back(par_result);
                continue;
            }

            if (par_result.compute_time_ms > 1e-4 && baseline_compute_ms > 1e-4) {
                par_result.speedup = baseline_compute_ms / par_result.compute_time_ms;
            } else {
                par_result.speedup = 1.0;
            }
            std::unordered_map<uint32_t, IpcVehicleResult> par_map;

                for (const auto& r : par_result.final_step_results) {
                    par_map.emplace(r.vehicle_id, r);
                }
            // Validate the complete vehicle-ID set and all state dimensions.
            bool eq_passed = seq_result.final_step_results.size() == fleet_size &&
                             par_result.final_step_results.size() == fleet_size &&
                             seq_map.size() == fleet_size && par_map.size() == fleet_size;
            double max_diff = 0.0;
            for (const auto& kv : seq_map) {
                const auto it = par_map.find(kv.first);
                if (it == par_map.end()) {
                    eq_passed = false;
                    continue;
                }
                const auto& a = kv.second;
                const auto& b = it->second;
                if (!std::isfinite(a.estimated_x) || !std::isfinite(a.estimated_y) ||
                    !std::isfinite(a.estimated_vx) || !std::isfinite(a.estimated_vy) ||
                    !std::isfinite(b.estimated_x) || !std::isfinite(b.estimated_y) ||
                    !std::isfinite(b.estimated_vx) || !std::isfinite(b.estimated_vy)) {
                    eq_passed = false;
                    continue;
                }
                const double position_diff = std::hypot(a.estimated_x - b.estimated_x,
                                                        a.estimated_y - b.estimated_y);
                const double velocity_diff = std::hypot(a.estimated_vx - b.estimated_vx,
                                                        a.estimated_vy - b.estimated_vy);
                max_diff = std::max(max_diff, position_diff);
                if (position_diff > 1e-5 || velocity_diff > 1e-5) {
                    eq_passed = false;
                }
            }
            // -1 is an explicit invalid-comparison sentinel in the existing CSV
            // schema. Never turn missing data into a reported 0.0 m difference.
            par_result.max_numerical_diff_meters = eq_passed ? max_diff : -1.0;
            par_result.numerical_equivalence_passed = eq_passed;
            all_results.push_back(par_result);
        }
    }

    exportResultsToCsv(all_results);
    return all_results;
}

bool KalmanBenchmarkRunner::exportResultsToCsv(const std::vector<BenchmarkResult>& results) {
    if (results.empty()) return false;

    // 1. Export kalman_benchmarks.csv (12 columns)
    std::ostringstream bss;
    bss << "execution_mode,worker_count,vehicle_count,total_ticks,total_samples,"
        << "startup_overhead_ms,compute_time_ms,total_execution_time_ms,speedup,"
        << "throughput_samples_per_sec,numerical_diff_meters,numerical_equivalent\n";

    for (const auto& r : results) {
        bss << r.execution_mode << ","
            << r.worker_count << ","
            << r.vehicle_count << ","
            << r.total_ticks << ","
            << r.total_samples_processed << ","
            << std::fixed << std::setprecision(3) << r.startup_overhead_ms << ","
            << std::fixed << std::setprecision(3) << r.compute_time_ms << ","
            << std::fixed << std::setprecision(3) << r.total_execution_time_ms << ","
            << std::fixed << std::setprecision(2) << r.speedup << ","
            << std::fixed << std::setprecision(1) << r.throughput_samples_per_sec << ","
            << std::fixed << std::setprecision(6) << r.max_numerical_diff_meters << ","
            << (r.numerical_equivalence_passed ? "true" : "false") << "\n";
    }

    const bool benchmark_written = WindowsFileIO::writeAllText(config_.benchmark_csv_path, bss.str());

    // 2. Export windows_os_metrics.csv (10 columns)
    std::ostringstream oss;
    oss << "run_id,execution_mode,worker_count,vehicle_count,total_ticks,"
        << "working_set_kb,peak_working_set_kb,private_bytes_kb,peak_private_bytes_kb,cpu_percent\n";

    uint32_t run_id = 1;
    for (const auto& r : results) {
        oss << run_id++ << ","
            << r.execution_mode << ","
            << r.worker_count << ","
            << r.vehicle_count << ","
            << r.total_ticks << ","
            << (r.peak_working_set_bytes / 1024) << ","
            << (r.peak_working_set_bytes / 1024) << ","
            << (r.peak_private_bytes / 1024) << ","
            << (r.peak_private_bytes / 1024) << ","
            << std::fixed << std::setprecision(1) << r.cpu_utilization_percent << "\n";
    }

    const bool metrics_written = WindowsFileIO::writeAllText(config_.os_metrics_csv_path, oss.str());

    return benchmark_written && metrics_written;
}

} // namespace Windows
} // namespace SmartTraffic
