#include "smart_traffic/windows/windows_memory_manager.h"

namespace SmartTraffic {
namespace Windows {

VirtualBuffer::VirtualBuffer(size_t size_bytes, DWORD protect)
    : data_(nullptr), size_(0) {
    if (size_bytes > 0) {
        data_ = WindowsMemoryManager::allocateVirtualMemory(size_bytes, protect);
        if (data_) {
            size_ = size_bytes;
        }
    }
}

VirtualBuffer::~VirtualBuffer() noexcept {
    release();
}

VirtualBuffer::VirtualBuffer(VirtualBuffer&& other) noexcept
    : data_(other.data_), size_(other.size_) {
    other.data_ = nullptr;
    other.size_ = 0;
}

VirtualBuffer& VirtualBuffer::operator=(VirtualBuffer&& other) noexcept {
    if (this != &other) {
        release();
        data_ = other.data_;
        size_ = other.size_;
        other.data_ = nullptr;
        other.size_ = 0;
    }
    return *this;
}

void VirtualBuffer::release() noexcept {
    if (data_) {
        WindowsMemoryManager::freeVirtualMemory(data_);
        data_ = nullptr;
        size_ = 0;
    }
}

void* WindowsMemoryManager::allocateVirtualMemory(size_t size_bytes, DWORD protect) noexcept {
    if (size_bytes == 0) return nullptr;
    return VirtualAlloc(NULL, size_bytes, MEM_COMMIT | MEM_RESERVE, protect);
}

bool WindowsMemoryManager::freeVirtualMemory(void* address) noexcept {
    if (!address) return true;
    return VirtualFree(address, 0, MEM_RELEASE) != 0;
}

bool WindowsMemoryManager::queryMemoryMetrics(ProcessMemoryMetrics& out_metrics, HANDLE process_handle) noexcept {
    PROCESS_MEMORY_COUNTERS_EX pmc;
    ZeroMemory(&pmc, sizeof(pmc));
    pmc.cb = sizeof(pmc);

    if (GetProcessMemoryInfo(process_handle, reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc), sizeof(pmc))) {
        out_metrics.working_set_bytes = pmc.WorkingSetSize;
        out_metrics.peak_working_set_bytes = pmc.PeakWorkingSetSize;
        out_metrics.private_bytes = pmc.PrivateUsage;
        out_metrics.peak_private_bytes = pmc.PeakPagefileUsage;
        return true;
    }
    return false;
}

size_t WindowsMemoryManager::getCurrentWorkingSetBytes() noexcept {
    ProcessMemoryMetrics m;
    if (queryMemoryMetrics(m)) {
        return m.working_set_bytes;
    }
    return 0;
}

size_t WindowsMemoryManager::getPeakWorkingSetBytes() noexcept {
    ProcessMemoryMetrics m;
    if (queryMemoryMetrics(m)) {
        return m.peak_working_set_bytes;
    }
    return 0;
}

size_t WindowsMemoryManager::getPrivateBytes() noexcept {
    ProcessMemoryMetrics m;
    if (queryMemoryMetrics(m)) {
        return m.private_bytes;
    }
    return 0;
}

} // namespace Windows
} // namespace SmartTraffic
