#include "smart_traffic/config/simulation_config.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <iostream>
#include <algorithm>

namespace SmartTraffic {

SimulationConfig SimulationConfig::createDefault() {
    return SimulationConfig{};
}

void SimulationConfig::validate() const {
    if (tick_duration_seconds <= 0.0 || tick_duration_seconds > 1.0) {
        throw std::invalid_argument("tick_duration_seconds must be > 0 and <= 1.0");
    }
    if (total_simulation_time <= 0.0) {
        throw std::invalid_argument("total_simulation_time must be positive");
    }
    if (vehicle_count == 0) {
        throw std::invalid_argument("vehicle_count must be at least 1");
    }
    if (spawn_interval_seconds <= 0.0) {
        throw std::invalid_argument("spawn_interval_seconds must be positive");
    }
    if (default_speed_limit <= 0.0) {
        throw std::invalid_argument("default_speed_limit must be positive");
    }
    if (min_headway_distance < 0.0) {
        throw std::invalid_argument("min_headway_distance cannot be negative");
    }
    if (gps_noise_stddev < 0.0) {
        throw std::invalid_argument("gps_noise_stddev cannot be negative");
    }
    if (gps_sampling_interval_seconds <= 0.0) {
        throw std::invalid_argument("gps_sampling_interval_seconds must be positive");
    }
    if (kalman_process_noise_stddev <= 0.0) {
        throw std::invalid_argument("kalman_process_noise_stddev must be positive");
    }
    if (kalman_measurement_noise_stddev <= 0.0) {
        throw std::invalid_argument("kalman_measurement_noise_stddev must be positive");
    }
    if (stopped_speed_threshold_mps < 0.0) {
        throw std::invalid_argument("stopped_speed_threshold_mps cannot be negative");
    }
    if (stopped_duration_threshold_sec <= 0.0) {
        throw std::invalid_argument("stopped_duration_threshold_sec must be positive");
    }
    if (speed_violation_tolerance_mps < 0.0) {
        throw std::invalid_argument("speed_violation_tolerance_mps cannot be negative");
    }
    // Note: Empty output_csv_path, tracking_csv_path, analytics_csv_path, or alerts_csv_path
    // cleanly disables CSV export in accordance with the documented empty-path / enable_* toggle convention.
}

namespace {
    std::string trim(const std::string& str) {
        const auto start = str.find_first_not_of(" \t\r\n\"'");
        if (start == std::string::npos) return "";
        const auto end = str.find_last_not_of(" \t\r\n\"',;");
        return str.substr(start, end - start + 1);
    }
}

bool SimulationConfig::loadFromFile(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        std::cerr << "[SimulationConfig] Warning: Unable to open config file: " << filepath 
                  << ". Using default configuration." << std::endl;
        return false;
    }

    std::string line;
    while (std::getline(file, line)) {
        // Remove comments
        const auto comment_pos = line.find("//");
        if (comment_pos != std::string::npos) {
            line = line.substr(0, comment_pos);
        }

        const auto colon_pos = line.find(':');
        const auto eq_pos = line.find('=');
        size_t sep_pos = (colon_pos != std::string::npos) ? colon_pos : eq_pos;

        if (sep_pos != std::string::npos) {
            std::string key = trim(line.substr(0, sep_pos));
            std::string val = trim(line.substr(sep_pos + 1));

            try {
                if (key == "tick_duration_seconds") tick_duration_seconds = std::stod(val);
                else if (key == "total_simulation_time") total_simulation_time = std::stod(val);
                else if (key == "vehicle_count") vehicle_count = static_cast<uint32_t>(std::stoul(val));
                else if (key == "spawn_interval_seconds") spawn_interval_seconds = std::stod(val);
                else if (key == "default_speed_limit") default_speed_limit = std::stod(val);
                else if (key == "min_headway_distance") min_headway_distance = std::stod(val);
                else if (key == "random_seed") random_seed = std::stoull(val);
                else if (key == "gps_noise_stddev") gps_noise_stddev = std::stod(val);
                else if (key == "gps_bias_x") gps_bias_x = std::stod(val);
                else if (key == "gps_bias_y") gps_bias_y = std::stod(val);
                else if (key == "gps_sampling_interval_seconds") gps_sampling_interval_seconds = std::stod(val);
                else if (key == "kalman_process_noise_stddev") kalman_process_noise_stddev = std::stod(val);
                else if (key == "kalman_measurement_noise_stddev") kalman_measurement_noise_stddev = std::stod(val);
                else if (key == "tracking_csv_path") tracking_csv_path = val;
                else if (key == "output_csv_path") output_csv_path = val;
                else if (key == "log_file_path") log_file_path = val;
                else if (key == "enable_console_progress") enable_console_progress = (val == "true" || val == "1");
                else if (key == "enable_raw_csv") enable_raw_csv = (val == "true" || val == "1");
                else if (key == "enable_tracking_csv") enable_tracking_csv = (val == "true" || val == "1");
                else if (key == "analytics_csv_path") analytics_csv_path = val;
                else if (key == "alerts_csv_path") alerts_csv_path = val;
                else if (key == "enable_analytics_csv") enable_analytics_csv = (val == "true" || val == "1");
                else if (key == "enable_alerts_csv") enable_alerts_csv = (val == "true" || val == "1");
                else if (key == "stopped_speed_threshold_mps") stopped_speed_threshold_mps = std::stod(val);
                else if (key == "stopped_duration_threshold_sec") stopped_duration_threshold_sec = std::stod(val);
                else if (key == "speed_violation_tolerance_mps") speed_violation_tolerance_mps = std::stod(val);
            } catch (const std::exception& e) {
                std::cerr << "[SimulationConfig] Failed to parse key '" << key << "': " << e.what() << std::endl;
            }
        }
    }

    validate();
    return true;
}

bool SimulationConfig::saveToFile(const std::string& filepath) const {
    std::ofstream file(filepath);
    if (!file.is_open()) {
        return false;
    }

    file << "{\n";
    file << "  \"tick_duration_seconds\": " << tick_duration_seconds << ",\n";
    file << "  \"total_simulation_time\": " << total_simulation_time << ",\n";
    file << "  \"vehicle_count\": " << vehicle_count << ",\n";
    file << "  \"spawn_interval_seconds\": " << spawn_interval_seconds << ",\n";
    file << "  \"default_speed_limit\": " << default_speed_limit << ",\n";
    file << "  \"min_headway_distance\": " << min_headway_distance << ",\n";
    file << "  \"random_seed\": " << random_seed << ",\n";
    file << "  \"gps_noise_stddev\": " << gps_noise_stddev << ",\n";
    file << "  \"gps_bias_x\": " << gps_bias_x << ",\n";
    file << "  \"gps_bias_y\": " << gps_bias_y << ",\n";
    file << "  \"gps_sampling_interval_seconds\": " << gps_sampling_interval_seconds << ",\n";
    file << "  \"kalman_process_noise_stddev\": " << kalman_process_noise_stddev << ",\n";
    file << "  \"kalman_measurement_noise_stddev\": " << kalman_measurement_noise_stddev << ",\n";
    file << "  \"tracking_csv_path\": \"" << tracking_csv_path << "\",\n";
    file << "  \"output_csv_path\": \"" << output_csv_path << "\",\n";
    file << "  \"log_file_path\": \"" << log_file_path << "\",\n";
    file << "  \"enable_console_progress\": " << (enable_console_progress ? "true" : "false") << ",\n";
    file << "  \"enable_raw_csv\": " << (enable_raw_csv ? "true" : "false") << ",\n";
    file << "  \"enable_tracking_csv\": " << (enable_tracking_csv ? "true" : "false") << ",\n";
    file << "  \"analytics_csv_path\": \"" << analytics_csv_path << "\",\n";
    file << "  \"alerts_csv_path\": \"" << alerts_csv_path << "\",\n";
    file << "  \"enable_analytics_csv\": " << (enable_analytics_csv ? "true" : "false") << ",\n";
    file << "  \"enable_alerts_csv\": " << (enable_alerts_csv ? "true" : "false") << ",\n";
    file << "  \"stopped_speed_threshold_mps\": " << stopped_speed_threshold_mps << ",\n";
    file << "  \"stopped_duration_threshold_sec\": " << stopped_duration_threshold_sec << ",\n";
    file << "  \"speed_violation_tolerance_mps\": " << speed_violation_tolerance_mps << "\n";
    file << "}\n";

    return true;
}

} // namespace SmartTraffic
