#include "smart_traffic/simulation/vehicle_manager.h"
#include <algorithm>
#include <stdexcept>

namespace SmartTraffic {

VehicleManager::VehicleManager() noexcept : next_vehicle_id_(1), total_created_count_(0) {}

std::shared_ptr<Vehicle> VehicleManager::createVehicle(uint32_t lane_id,
                                                      double initial_speed_mps,
                                                      double target_speed_mps,
                                                      double spawn_time_sec) {
    const uint32_t id = next_vehicle_id_++;
    total_created_count_++;

    auto vehicle = std::make_shared<Vehicle>(id, lane_id, initial_speed_mps, target_speed_mps, spawn_time_sec);
    return vehicle;
}

bool VehicleManager::canSpawnOnLane(uint32_t lane_id, double min_safe_headway_meters) const noexcept {
    for (const auto& [id, vehicle] : active_vehicles_) {
        if (vehicle && vehicle->getCurrentLaneId() == lane_id) {
            if (vehicle->getDistanceAlongLane() < min_safe_headway_meters) {
                return false; // Lane entrance is obstructed by preceding vehicle
            }
        }
    }
    return true;
}

void VehicleManager::activateVehicle(std::shared_ptr<Vehicle> vehicle) {
    if (!vehicle) {
        throw std::invalid_argument("Cannot activate null vehicle pointer");
    }
    vehicle->setState(VehicleState::ACTIVE);
    active_vehicles_[vehicle->getId()] = vehicle;
}

void VehicleManager::markVehicleCompleted(uint32_t vehicle_id) {
    auto it = active_vehicles_.find(vehicle_id);
    if (it != active_vehicles_.end()) {
        it->second->setState(VehicleState::COMPLETED);
        completed_vehicles_.push_back(it->second);
        active_vehicles_.erase(it);
    }
}

void VehicleManager::removeVehicle(uint32_t vehicle_id) {
    auto it = active_vehicles_.find(vehicle_id);
    if (it != active_vehicles_.end()) {
        it->second->setState(VehicleState::DESPAWNED);
        active_vehicles_.erase(it);
    }
}

std::shared_ptr<Vehicle> VehicleManager::getActiveVehicle(uint32_t vehicle_id) const {
    const auto it = active_vehicles_.find(vehicle_id);
    if (it != active_vehicles_.end()) {
        return it->second;
    }
    return nullptr;
}

std::vector<std::shared_ptr<Vehicle>> VehicleManager::getActiveVehicles() const {
    std::vector<std::shared_ptr<Vehicle>> list;
    list.reserve(active_vehicles_.size());
    for (const auto& [id, vehicle] : active_vehicles_) {
        if (vehicle) {
            list.push_back(vehicle);
        }
    }
    return list;
}

std::vector<std::shared_ptr<Vehicle>> VehicleManager::getVehiclesOnLane(uint32_t lane_id) const {
    std::vector<std::shared_ptr<Vehicle>> vehicles;
    for (const auto& [id, vehicle] : active_vehicles_) {
        if (vehicle && vehicle->getCurrentLaneId() == lane_id) {
            vehicles.push_back(vehicle);
        }
    }

    // Sort descending by distance along lane: front-most / lead vehicle first
    std::sort(vehicles.begin(), vehicles.end(), [](const std::shared_ptr<Vehicle>& a, const std::shared_ptr<Vehicle>& b) {
        return a->getDistanceAlongLane() > b->getDistanceAlongLane();
    });

    return vehicles;
}

void VehicleManager::reset() noexcept {
    active_vehicles_.clear();
    completed_vehicles_.clear();
    next_vehicle_id_ = 1;
    total_created_count_ = 0;
}

} // namespace SmartTraffic
