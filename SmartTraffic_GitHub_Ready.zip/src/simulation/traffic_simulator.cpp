#include "smart_traffic/simulation/traffic_simulator.h"
#include "smart_traffic/utils/logger.h"
#include <chrono>
#include <algorithm>
#include <sstream>
#include <iomanip>

namespace SmartTraffic {

TrafficSimulator::TrafficSimulator(const SimulationConfig& config)
    : config_(config),
      road_network_(),
      vehicle_manager_(),
      gps_simulator_(config.random_seed, config.gps_noise_stddev, config.gps_bias_x, config.gps_bias_y),
      csv_exporter_(),
      tracking_manager_(config.kalman_process_noise_stddev, config.kalman_measurement_noise_stddev,
                        config.isTrackingCsvEnabled() ? config.tracking_csv_path : ""),
      traffic_analyzer_(config.isAnalyticsCsvEnabled() ? config.analytics_csv_path : ""),
      alert_manager_(config.isAlertsCsvEnabled() ? config.alerts_csv_path : "",
                     AlertThresholds{config.speed_violation_tolerance_mps,
                                     config.stopped_duration_threshold_sec,
                                     config.stopped_speed_threshold_mps}) {
}

void TrafficSimulator::initialize() {
    config_.validate();

    // 1. Construct 2D Road Network with central 4-way intersection
    road_network_.buildStandardFourWayIntersection(150.0, 3.5, config_.default_speed_limit);

    // 2. Initialize Seeded GPS Sensor Model
    gps_simulator_.reseed(config_.random_seed);
    gps_simulator_.setNoiseStdDev(config_.gps_noise_stddev);
    gps_simulator_.setBias(config_.gps_bias_x, config_.gps_bias_y);

    // 3. Reset vehicle fleet manager
    vehicle_manager_.reset();

    // 4. Open CSV export stream if enabled
    if (config_.isRawCsvEnabled()) {
        csv_exporter_.open(config_.output_csv_path);
    } else {
        csv_exporter_.close();
    }

    // 5. Open tracking telemetry stream if enabled and reset Kalman tracking manager
    tracking_manager_.reset();
    if (config_.isTrackingCsvEnabled()) {
        tracking_manager_.openExportFile(config_.tracking_csv_path);
    } else {
        tracking_manager_.closeExportFile();
    }

    // 6. Reset Traffic Analyzer and Alert Manager
    traffic_analyzer_.reset();
    if (config_.isAnalyticsCsvEnabled()) {
        traffic_analyzer_.openExportFile(config_.analytics_csv_path);
    } else {
        traffic_analyzer_.closeExportFile();
    }

    alert_manager_.reset();
    alert_manager_.setAlertThresholds(AlertThresholds{
        config_.speed_violation_tolerance_mps,
        config_.stopped_duration_threshold_sec,
        config_.stopped_speed_threshold_mps
    });
    if (config_.isAlertsCsvEnabled()) {
        alert_manager_.openExportFile(config_.alerts_csv_path);
    } else {
        alert_manager_.closeExportFile();
    }

    // 7. Reset timing state
    current_time_ = 0.0;
    tick_count_ = 0;
    vehicles_spawned_ = 0;
    next_spawn_time_ = 0.0;
    spawn_lane_index_ = 0;
    next_gps_sample_time_ = 0.0;
    was_latest_tick_gps_sampled_ = false;

    latest_measurements_.clear();
    accumulated_gps_error_ = 0.0;
    max_gps_error_ = 0.0;
    total_measurements_recorded_ = 0;

    Logger::getInstance().info("TrafficSimulator initialized: Target 60s @ 100ms ticks, GPS @ " 
                               + std::to_string(config_.gps_sampling_interval_seconds) 
                               + "s interval, 30 vehicles, Seed=" 
                               + std::to_string(config_.random_seed));
}

void TrafficSimulator::reset() {
    initialize();
}

void TrafficSimulator::attemptSpawning() {
    if (vehicles_spawned_ >= config_.vehicle_count) {
        return;
    }

    if (current_time_ < next_spawn_time_ - 1e-6) {
        return;
    }

    const auto& spawn_lanes = road_network_.getSpawnLaneIds();
    if (spawn_lanes.empty()) {
        return;
    }

    const uint32_t candidate_lane_id = spawn_lanes[spawn_lane_index_ % spawn_lanes.size()];
    const double required_clearance = config_.min_headway_distance + 5.0; // bumper-to-bumper + vehicle length

    if (vehicle_manager_.canSpawnOnLane(candidate_lane_id, required_clearance)) {
        auto lane = road_network_.getLane(candidate_lane_id);
        if (!lane) return;

        // Deterministic target speed based on vehicle sequence: between 11.5 and 13.8 m/s (~41 to 50 km/h)
        const double target_speed = 11.5 + (vehicles_spawned_ % 4) * 0.75;
        const double initial_speed = 8.0; // Enter lane at reasonable speed

        auto vehicle = vehicle_manager_.createVehicle(candidate_lane_id, initial_speed, target_speed, current_time_);
        vehicle->setPosition(lane->getPositionAtDistance(0.0));
        vehicle->setVelocity(lane->getVelocityVector(initial_speed));

        vehicle_manager_.activateVehicle(vehicle);

        vehicles_spawned_++;
        spawn_lane_index_++;
        next_spawn_time_ = current_time_ + config_.spawn_interval_seconds;
    }
}

void TrafficSimulator::updateVehicleMovements(double dt) {
    // Phase A: Car-following model and kinematic updates per lane
    for (const auto& [lane_id, lane] : road_network_.getAllLanes()) {
        auto lane_vehicles = vehicle_manager_.getVehiclesOnLane(lane_id);
        if (lane_vehicles.empty()) continue;

        for (size_t i = 0; i < lane_vehicles.size(); ++i) {
            auto& vehicle = lane_vehicles[i];
            double desired_acc = 0.0;

            if (i == 0) {
                // Lead vehicle on this lane: free flow towards target speed
                const double speed_diff = vehicle->getTargetSpeed() - vehicle->getCurrentSpeed();
                desired_acc = std::clamp(speed_diff / 1.5, -vehicle->getMaxDeceleration(), vehicle->getMaxAcceleration());
            } else {
                // Trailing vehicle: follow vehicle immediately ahead
                const auto& lead_vehicle = lane_vehicles[i - 1];
                const double gap = lead_vehicle->getDistanceAlongLane() - vehicle->getDistanceAlongLane() - lead_vehicle->getLength();
                const double safe_headway = config_.min_headway_distance + vehicle->getCurrentSpeed() * 1.0; // 1 second time headway

                if (gap < safe_headway) {
                    // Decelerate to avoid tailgating
                    const double factor = std::clamp((safe_headway - gap) / safe_headway, 0.0, 1.0);
                    desired_acc = -vehicle->getMaxDeceleration() * factor;
                } else {
                    // Safe gap exists; accelerate towards target speed
                    const double speed_diff = vehicle->getTargetSpeed() - vehicle->getCurrentSpeed();
                    desired_acc = std::clamp(speed_diff / 1.5, -vehicle->getMaxDeceleration(), vehicle->getMaxAcceleration());
                }
            }

            vehicle->updateKinematics(desired_acc, dt, lane->getSpeedLimit());
        }
    }

    // Phase B: Spatial position resolution and lane transitions
    auto active_vehicles = vehicle_manager_.getActiveVehicles();
    for (auto& vehicle : active_vehicles) {
        auto lane = road_network_.getLane(vehicle->getCurrentLaneId());
        if (!lane) {
            vehicle_manager_.removeVehicle(vehicle->getId());
            continue;
        }

        if (lane->isAtEndOfLane(vehicle->getDistanceAlongLane())) {
            // Vehicle has completed traversal of current lane
            auto next_lane_id = road_network_.getNextLaneId(lane->getId(), vehicle->getId());
            if (next_lane_id.has_value()) {
                const double excess_dist = vehicle->getDistanceAlongLane() - lane->getLength();
                vehicle->transitionToLane(next_lane_id.value(), excess_dist);

                auto next_lane = road_network_.getLane(next_lane_id.value());
                if (next_lane) {
                    vehicle->setPosition(next_lane->getPositionAtDistance(vehicle->getDistanceAlongLane()));
                    vehicle->setVelocity(next_lane->getVelocityVector(vehicle->getCurrentSpeed()));
                }
            } else {
                // Vehicle has exited the road network corridor
                tracking_manager_.handleVehicleDeparted(vehicle->getId());
                alert_manager_.handleVehicleDeparted(vehicle->getId(), current_time_);
                vehicle_manager_.markVehicleCompleted(vehicle->getId());
            }
        } else {
            // Standard update along current lane
            vehicle->setPosition(lane->getPositionAtDistance(vehicle->getDistanceAlongLane()));
            vehicle->setVelocity(lane->getVelocityVector(vehicle->getCurrentSpeed()));
        }
    }
}

void TrafficSimulator::collectGpsMeasurements() {
    latest_measurements_.clear();
    const auto active_vehicles = vehicle_manager_.getActiveVehicles();
    latest_measurements_.reserve(active_vehicles.size());

    for (const auto& vehicle : active_vehicles) {
        if (!vehicle) continue;

        GpsMeasurement measurement = gps_simulator_.sample(*vehicle, current_time_);
        csv_exporter_.writeRow(measurement);

        accumulated_gps_error_ += measurement.error_distance;
        if (measurement.error_distance > max_gps_error_) {
            max_gps_error_ = measurement.error_distance;
        }
        total_measurements_recorded_++;
        latest_measurements_.push_back(measurement);
    }
}

void TrafficSimulator::step() {
    const double dt = config_.tick_duration_seconds;

    // 1. Check for scheduled vehicle arrivals
    attemptSpawning();

    // 2. Kinematic physical motion and safe car-following
    updateVehicleMovements(dt);

    // 3. Sensor acquisition and CSV telemetry logging only at configured GPS sampling interval
    if (current_time_ >= next_gps_sample_time_ - 1e-6) {
        collectGpsMeasurements();
        was_latest_tick_gps_sampled_ = true;
        next_gps_sample_time_ = current_time_ + config_.gps_sampling_interval_seconds;
    } else {
        latest_measurements_.clear();
        was_latest_tick_gps_sampled_ = false;
    }

    // 4. Update Kalman Tracking Engine
    const auto active_vehicles = vehicle_manager_.getActiveVehicles();
    tracking_manager_.update(current_time_, dt, active_vehicles, latest_measurements_, was_latest_tick_gps_sampled_);

    // 5. Update Phase 3 Traffic Analytics & Alert Engine
    traffic_analyzer_.update(current_time_, dt, active_vehicles, road_network_, vehicle_manager_.getCompletedCount());
    alert_manager_.processAlerts(current_time_, active_vehicles, traffic_analyzer_, road_network_);

    // 6. Notify optional tick listener
    if (tick_callback_) {
        tick_callback_(current_time_, tick_count_, latest_measurements_);
    }

    // 7. Advance timeline
    current_time_ += dt;
    tick_count_++;
}

SimulationSummary TrafficSimulator::run() {
    initialize();

    const auto wall_start = std::chrono::high_resolution_clock::now();
    double next_log_time = 0.0;

    while (current_time_ < config_.total_simulation_time - 1e-6) {
        step();

        if (config_.enable_console_progress && current_time_ >= next_log_time) {
            std::ostringstream ss;
            ss << "Sim progress: " << std::fixed << std::setprecision(1) << current_time_ << "s / "
               << config_.total_simulation_time << "s (" << tick_count_ << " ticks) | Active: " 
               << vehicle_manager_.getActiveCount() << " | Completed: " 
               << vehicle_manager_.getCompletedCount() << " | Spawned: " 
               << vehicles_spawned_ << "/" << config_.vehicle_count;
            Logger::getInstance().info(ss.str());
            next_log_time = current_time_ + 5.0; // Log every 5 seconds
        }
    }

    csv_exporter_.flush();
    tracking_manager_.closeExportFile();
    traffic_analyzer_.closeExportFile();
    alert_manager_.closeExportFile();

    const auto wall_end = std::chrono::high_resolution_clock::now();
    const double elapsed_ms = std::chrono::duration<double, std::milli>(wall_end - wall_start).count();

    SimulationSummary summary;
    summary.total_ticks = tick_count_;
    summary.total_simulated_time_sec = current_time_;
    summary.vehicles_spawned = vehicles_spawned_;
    summary.vehicles_completed = static_cast<uint32_t>(vehicle_manager_.getCompletedCount());
    summary.active_vehicles_at_end = vehicle_manager_.getActiveCount();
    summary.total_gps_records = total_measurements_recorded_;
    summary.mean_gps_error_meters = (total_measurements_recorded_ > 0) 
        ? (accumulated_gps_error_ / total_measurements_recorded_) : 0.0;
    summary.max_gps_error_meters = max_gps_error_;
    summary.csv_export_filepath = config_.output_csv_path;
    summary.execution_wall_time_ms = elapsed_ms;

    // Populate Phase 2 tracking metrics
    summary.tracking_metrics = tracking_manager_.computeMetrics();
    summary.tracking_csv_filepath = config_.tracking_csv_path;

    // Populate Phase 3 analytics and alerts summary
    summary.analytics_summary = traffic_analyzer_.getSummary();
    summary.alert_summary = alert_manager_.getSummary();
    summary.analytics_csv_filepath = config_.isAnalyticsCsvEnabled() ? config_.analytics_csv_path : "";
    summary.alerts_csv_filepath = config_.isAlertsCsvEnabled() ? config_.alerts_csv_path : "";

    return summary;
}

} // namespace SmartTraffic
