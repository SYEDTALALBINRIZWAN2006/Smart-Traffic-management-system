#include "smart_traffic/simulation/gps_simulator.h"
#include <cmath>
#include <stdexcept>

namespace SmartTraffic {

GPSSimulator::GPSSimulator(uint64_t seed,
                           double noise_stddev,
                           double bias_x,
                           double bias_y)
    : initial_seed_(seed),
      noise_stddev_(noise_stddev),
      bias_x_(bias_x),
      bias_y_(bias_y),
      rng_(seed),
      normal_dist_(0.0, 1.0) {
    if (noise_stddev < 0.0) {
        throw std::invalid_argument("noise_stddev must be non-negative");
    }
}

void GPSSimulator::reseed(uint64_t new_seed) noexcept {
    initial_seed_ = new_seed;
    rng_.seed(new_seed);
    normal_dist_.reset();
}

void GPSSimulator::setNoiseStdDev(double stddev) {
    if (stddev < 0.0) {
        throw std::invalid_argument("noise_stddev must be non-negative");
    }
    noise_stddev_ = stddev;
}

GpsMeasurement GPSSimulator::sample(const Vehicle& vehicle, double timestamp_sec) {
    return samplePosition(vehicle.getId(), vehicle.getPosition(), timestamp_sec);
}

GpsMeasurement GPSSimulator::samplePosition(uint32_t vehicle_id, const Position& true_pos, double timestamp_sec) {
    // Generate standard normal samples N(0, 1) and scale by noise_stddev_
    const double noise_x = normal_dist_(rng_) * noise_stddev_;
    const double noise_y = normal_dist_(rng_) * noise_stddev_;

    GpsMeasurement measurement;
    measurement.timestamp = timestamp_sec;
    measurement.vehicle_id = vehicle_id;
    measurement.actual_x = true_pos.x;
    measurement.actual_y = true_pos.y;
    measurement.gps_x = true_pos.x + noise_x + bias_x_;
    measurement.gps_y = true_pos.y + noise_y + bias_y_;

    const double dx = measurement.gps_x - measurement.actual_x;
    const double dy = measurement.gps_y - measurement.actual_y;
    measurement.error_distance = std::sqrt(dx * dx + dy * dy);

    return measurement;
}

} // namespace SmartTraffic
