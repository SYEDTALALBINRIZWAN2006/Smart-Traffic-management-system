#include "smart_traffic/simulation/traffic_simulator.h"
#ifdef _WIN32
#include "smart_traffic/windows/kalman_benchmark_runner.h"
#endif
#include "smart_traffic/utils/logger.h"
#include <iostream>
#include <iomanip>

int main(int argc, char* argv[]) {
    try {
        // Check for --benchmark flag
#ifdef _WIN32
        for (int i = 1; i < argc; ++i) {
            if (std::string(argv[i]) == "--benchmark") {
                std::cout << "===================================================================\n";
                std::cout << "  SmartTraffic Phase 4: Win32 Multiprocessing Benchmark Suite      \n";
                std::cout << "  (Sequential Baseline vs 2-Worker and 4-Worker Shared Memory IPC) \n";
                std::cout << "===================================================================\n";

                SmartTraffic::Windows::BenchmarkConfig bconfig;
                bconfig.fleet_sizes = { 30, 100, 500, 1000 };
                bconfig.worker_counts = { 1, 2, 4 };
                bconfig.simulation_ticks = 100;
                bconfig.repeat_trials = 3;

                SmartTraffic::Windows::KalmanBenchmarkRunner runner(bconfig);
                std::cout << "[Benchmark] Executing benchmark across 30, 100, 500, 1000 vehicles...\n";
                const auto results = runner.runAllBenchmarks();

                std::cout << "\n=========================================================================================================\n";
                std::cout << "                                  MULTIPROCESSING BENCHMARK RESULTS                                       \n";
                std::cout << "=========================================================================================================\n";
                std::cout << std::left
                          << std::setw(15) << "Mode"
                          << std::setw(10) << "Workers"
                          << std::setw(10) << "Vehicles"
                          << std::setw(15) << "Compute (ms)"
                          << std::setw(10) << "Speedup"
                          << std::setw(16) << "Throughput (s/s)"
                          << std::setw(12) << "CPU (%)"
                          << std::setw(14) << "Max Diff (m)"
                          << std::setw(12) << "Equivalence"
                          << "\n";
                std::cout << std::string(105, '-') << "\n";

                for (const auto& r : results) {
                    std::cout << std::left
                              << std::setw(15) << r.execution_mode
                              << std::setw(10) << r.worker_count
                              << std::setw(10) << r.vehicle_count
                              << std::fixed << std::setprecision(2) << std::setw(15) << r.compute_time_ms
                              << std::fixed << std::setprecision(2) << std::setw(10) << r.speedup
                              << std::fixed << std::setprecision(0) << std::setw(16) << r.throughput_samples_per_sec
                              << std::fixed << std::setprecision(1) << std::setw(12) << r.cpu_utilization_percent
                              << std::scientific << std::setprecision(2) << std::setw(14) << r.max_numerical_diff_meters
                              << std::setw(12) << (r.numerical_equivalence_passed ? "PASSED" : "FAILED")
                              << "\n";
                }
                std::cout << "=========================================================================================================\n";
                bool all_passed = !results.empty();
                for (const auto& r : results) {
                    if (!r.success || !r.numerical_equivalence_passed) all_passed = false;
                }
                if (!all_passed) {
                    std::cerr << "[Benchmark] One or more runs failed or were not equivalent.\n";
                    return 2;
                }
                std::cout << "[CSV] Benchmark tables exported (check paths):\n";
                std::cout << "      - " << bconfig.benchmark_csv_path << "\n";
                std::cout << "      - " << bconfig.os_metrics_csv_path << "\n";
                return 0;
            }
        }
#endif
        std::cout << "===================================================================\n";
        std::cout << "  Smart Traffic Intelligence & Vehicle Tracking System - Phase 2   \n";
        std::cout << "  (Constant-Velocity 2D Kalman Filter & Multi-Vehicle Tracking)    \n";
        std::cout << "===================================================================\n";

        // Initialize logging
        SmartTraffic::Logger::getInstance().setLogLevel(SmartTraffic::LogLevel::INFO);
        SmartTraffic::Logger::getInstance().setLogFile("logs/simulation.log");

        // Load configuration or use production defaults
        SmartTraffic::SimulationConfig config = SmartTraffic::SimulationConfig::createDefault();
        if (argc > 1) {
            std::cout << "[Config] Loading configuration overrides from: " << argv[1] << "\n";
            config.loadFromFile(argv[1]);
        }

        std::cout << "[Config] Vehicle Target Count : " << config.vehicle_count << "\n";
        std::cout << "[Config] Simulation Duration   : " << config.total_simulation_time << " s\n";
        std::cout << "[Config] Fixed Tick Duration   : " << (config.tick_duration_seconds * 1000.0) << " ms\n";
        std::cout << "[Config] Expected Ticks        : " 
                  << static_cast<uint64_t>(config.total_simulation_time / config.tick_duration_seconds) << "\n";
        std::cout << "[Config] Deterministic Seed    : " << config.random_seed << "\n";
        std::cout << "[Config] GPS Sampling Interval : " << config.gps_sampling_interval_seconds << " s\n";
        std::cout << "[Config] GPS Noise StdDev      : " << config.gps_noise_stddev << " m\n";
        std::cout << "[Config] Kalman Process Noise  : " << config.kalman_process_noise_stddev << " m/s^2\n";
        std::cout << "[Config] Kalman Meas. Noise    : " << config.kalman_measurement_noise_stddev << " m\n";
        std::cout << "[Config] Raw CSV Destination   : " << config.output_csv_path << "\n";
        std::cout << "[Config] Tracking CSV Dest.    : " << config.tracking_csv_path << "\n";
        std::cout << "-------------------------------------------------------------------\n";

        // Create simulator and execute
        SmartTraffic::TrafficSimulator simulator(config);
        std::cout << "[Simulation] Starting simulation run...\n";
        const auto summary = simulator.run();

        // Print final summary report
        std::cout << "\n===================================================================\n";
        std::cout << "                    SIMULATION EXECUTION SUMMARY                    \n";
        std::cout << "===================================================================\n";
        std::cout << std::left << std::setw(34) << "Total Simulation Ticks"       << ": " << summary.total_ticks << "\n";
        std::cout << std::left << std::setw(34) << "Total Simulated Time"         << ": " << std::fixed << std::setprecision(2) << summary.total_simulated_time_sec << " seconds\n";
        std::cout << std::left << std::setw(34) << "Vehicles Spawned"             << ": " << summary.vehicles_spawned << " / " << config.vehicle_count << "\n";
        std::cout << std::left << std::setw(34) << "Vehicles Completed Journey"   << ": " << summary.vehicles_completed << "\n";
        std::cout << std::left << std::setw(34) << "Vehicles Active at Finish"    << ": " << summary.active_vehicles_at_end << "\n";
        std::cout << std::left << std::setw(34) << "Total GPS Records Exported"   << ": " << summary.total_gps_records << "\n";
        std::cout << std::left << std::setw(34) << "Raw GPS Measurement File"    << ": " << summary.csv_export_filepath << "\n";
        std::cout << std::left << std::setw(34) << "Simulation Wall Clock Time"   << ": " << std::fixed << std::setprecision(2) << summary.execution_wall_time_ms << " ms\n";
        if (summary.execution_wall_time_ms > 0.0) {
            const double speedup = (summary.total_simulated_time_sec * 1000.0) / summary.execution_wall_time_ms;
            std::cout << std::left << std::setw(34) << "Performance Speedup"      << ": " << std::fixed << std::setprecision(1) << speedup << "x real-time\n";
        }

        std::cout << "-------------------------------------------------------------------\n";
        std::cout << "              PHASE 2: KALMAN VEHICLE TRACKING METRICS             \n";
        std::cout << "-------------------------------------------------------------------\n";
        const auto& tm = summary.tracking_metrics;
        std::cout << std::left << std::setw(34) << "Total Vehicles Tracked"       << ": " << tm.total_vehicles_tracked << "\n";
        std::cout << std::left << std::setw(34) << "Comparable GPS Updates"       << ": " << tm.comparable_sample_count << "\n";
        std::cout << std::left << std::setw(34) << "Total 100ms Prediction Ticks"  << ": " << tm.total_prediction_ticks << "\n";
        std::cout << std::left << std::setw(34) << "Raw GPS RMSE (Comparable)"   << ": " << std::fixed << std::setprecision(3) << tm.gps_rmse_meters << " meters\n";
        std::cout << std::left << std::setw(34) << "Kalman Filter RMSE (Comparable)" << ": " << std::fixed << std::setprecision(3) << tm.kalman_rmse_meters << " meters\n";
        std::cout << std::left << std::setw(34) << "Kalman Filter RMSE (All Ticks)" << ": " << std::fixed << std::setprecision(3) << tm.kalman_all_ticks_rmse_meters << " meters\n";
        std::cout << std::left << std::setw(34) << "Tracking Noise Reduction"     << ": " << std::fixed << std::setprecision(2) << tm.error_reduction_percentage << " %\n";
        std::cout << std::left << std::setw(34) << "Max Raw GPS Error"            << ": " << std::fixed << std::setprecision(3) << tm.max_gps_error_meters << " meters\n";
        std::cout << std::left << std::setw(34) << "Max Kalman Tracking Error"    << ": " << std::fixed << std::setprecision(3) << tm.max_kalman_error_meters << " meters\n";
        std::cout << std::left << std::setw(34) << "Tracking Telemetry CSV File"  << ": " << summary.tracking_csv_filepath << "\n";

        std::cout << "-------------------------------------------------------------------\n";
        std::cout << "       PHASE 3: TRAFFIC INTELLIGENCE & ANALYTICS METRICS           \n";
        std::cout << "-------------------------------------------------------------------\n";
        const auto& am = summary.analytics_summary;
        std::cout << std::left << std::setw(34) << "Total Analyzed Snapshots"      << ": " << am.total_snapshots << "\n";
        std::cout << std::left << std::setw(34) << "Peak Active Vehicles"         << ": " << am.peak_active_vehicles << "\n";
        std::cout << std::left << std::setw(34) << "Overall Mean Speed"           << ": " << std::fixed << std::setprecision(2) << am.overall_mean_speed_mps << " m/s (" << am.overall_mean_speed_kmh << " km/h)\n";
        std::cout << std::left << std::setw(34) << "Peak Corridor Density"        << ": " << std::fixed << std::setprecision(1) << am.peak_density_vehicles_per_km << " veh/km\n";
        std::cout << std::left << std::setw(34) << "Peak Corridor Occupancy"      << ": " << std::fixed << std::setprecision(1) << (am.peak_occupancy * 100.0) << " %\n";
        std::cout << std::left << std::setw(34) << "Congestion Breakdown (L/M/H)" << ": " << am.total_low_congestion_snapshots << " / " << am.total_moderate_congestion_snapshots << " / " << am.total_high_congestion_snapshots << " ticks\n";
        std::cout << std::left << std::setw(34) << "Traffic Analytics CSV File"   << ": " << summary.analytics_csv_filepath << "\n";

        std::cout << "-------------------------------------------------------------------\n";
        std::cout << "               PHASE 3: TRAFFIC ALERTS & INCIDENTS                 \n";
        std::cout << "-------------------------------------------------------------------\n";
        const auto& alm = summary.alert_summary;
        std::cout << std::left << std::setw(34) << "Total Alerts Created"         << ": " << alm.total_alerts_created << "\n";
        std::cout << std::left << std::setw(34) << "Speed Violations Detected"    << ": " << alm.speed_violations_count << "\n";
        std::cout << std::left << std::setw(34) << "Heavy Congestion Alerts"      << ": " << alm.heavy_congestion_count << "\n";
        std::cout << std::left << std::setw(34) << "Abnormally Stopped Alerts"    << ": " << alm.stopped_vehicle_count << "\n";
        std::cout << std::left << std::setw(34) << "Total Alerts Resolved"        << ": " << alm.total_alerts_resolved << "\n";
        std::cout << std::left << std::setw(34) << "Active Alerts at Finish"      << ": " << alm.active_alerts_at_end << "\n";
        std::cout << std::left << std::setw(34) << "Traffic Alerts CSV File"      << ": " << summary.alerts_csv_filepath << "\n";
        std::cout << "===================================================================\n";
        std::cout << "[Status] Simulation, tracking, and traffic analytics finished successfully.\n";

        return 0;
    } catch (const std::exception& ex) {
        std::cerr << "\n[FATAL ERROR] Simulation terminated with exception: " << ex.what() << "\n";
        return 1;
    }
}
