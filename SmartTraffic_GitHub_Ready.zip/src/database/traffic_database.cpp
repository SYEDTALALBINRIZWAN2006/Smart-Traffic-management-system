#include "smart_traffic/database/traffic_database.h"
#include <filesystem>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cerrno>
#include <cstdlib>

namespace SmartTraffic {
namespace {
std::vector<std::string> parseCsv(const std::string& line) {
    std::vector<std::string> out;
    std::string field;
    bool quoted = false;
    for (size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];
        if (c == '"') {
            if (quoted && i + 1 < line.size() && line[i + 1] == '"') { field += '"'; ++i; }
            else quoted = !quoted;
        } else if (c == ',' && !quoted) { out.push_back(field); field.clear(); }
        else if (c != '\r') field += c;
    }
    if (quoted) throw std::runtime_error("Unterminated CSV quoted field");
    out.push_back(field);
    return out;
}
void check(int rc, sqlite3* db) {
    if (rc != SQLITE_OK && rc != SQLITE_DONE && rc != SQLITE_ROW)
        throw std::runtime_error(sqlite3_errmsg(db));
}
const std::vector<std::string> allowed = {"gps_measurements", "tracking_estimates", "traffic_analytics", "traffic_alerts", "kalman_benchmarks", "windows_os_metrics"};
void validateTable(const std::string& table) {
    if (std::find(allowed.begin(), allowed.end(), table) == allowed.end()) throw std::invalid_argument("Unknown table");
}
}
TrafficDatabase::TrafficDatabase(const std::string& filename) {
    const auto parent = std::filesystem::path(filename).parent_path();
    if (!parent.empty()) std::filesystem::create_directories(parent);
    if (sqlite3_open(filename.c_str(), &db_) != SQLITE_OK) {
        std::string error = db_ ? sqlite3_errmsg(db_) : "Cannot open database";
        if (db_) sqlite3_close(db_);
        db_ = nullptr;
        throw std::runtime_error(error);
    }
    try {
        execute("PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL;");
        for (const auto& table : allowed) {
            execute("CREATE TABLE IF NOT EXISTS " + table + " (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL)");
        }
        // Add typed columns to pre-existing Phase 5 databases without losing data.
        auto addColumn = [this](const std::string& table, const std::string& column, const std::string& type) {
            sqlite3_stmt* stmt = nullptr;
            check(sqlite3_prepare_v2(db_, ("PRAGMA table_info(" + table + ")").c_str(), -1, &stmt, nullptr), db_);
            bool found = false;
            while (sqlite3_step(stmt) == SQLITE_ROW) {
                const char* name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
                if (name && column == name) found = true;
            }
            sqlite3_finalize(stmt);
            if (!found) execute("ALTER TABLE " + table + " ADD COLUMN " + column + " " + type);
        };
        for (const auto& table : {"gps_measurements", "tracking_estimates"}) {
            addColumn(table, "timestamp_value", "REAL");
            addColumn(table, "vehicle_id_value", "INTEGER");
            execute("UPDATE " + std::string(table) + " SET timestamp_value = CAST(json_extract(payload,'$.timestamp') AS REAL), vehicle_id_value = CAST(json_extract(payload,'$.vehicle_id') AS INTEGER) WHERE timestamp_value IS NULL OR vehicle_id_value IS NULL");
            execute("CREATE INDEX IF NOT EXISTS idx_" + std::string(table) + "_vehicle_time ON " + table + "(vehicle_id_value, timestamp_value DESC, id DESC)");
        }
    } catch (...) { sqlite3_close(db_); db_ = nullptr; throw; }
}
TrafficDatabase::~TrafficDatabase() { if (db_) sqlite3_close(db_); }
void TrafficDatabase::execute(const std::string& sql) {
    char* error = nullptr;
    if (sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &error) != SQLITE_OK) {
        std::string msg = error ? error : "SQLite failure";
        sqlite3_free(error);
        throw std::runtime_error(msg);
    }
}
std::string TrafficDatabase::jsonEscape(const std::string& s) {
    std::string result = "\"";
    const char* hex = "0123456789abcdef";
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { result += '\\'; result += static_cast<char>(c); }
        else if (c == '\n') result += "\\n";
        else if (c == '\r') result += "\\r";
        else if (c == '\t') result += "\\t";
        else if (c < 32) { result += "\\u00"; result += hex[c >> 4]; result += hex[c & 15]; }
        else result += static_cast<char>(c);
    }
    return result + "\"";
}
void TrafficDatabase::importCsv(const std::string& filename, const std::string& table, const std::vector<std::string>& columns) {
    validateTable(table);
    std::ifstream file(filename);
    if (!file) throw std::runtime_error("Cannot open CSV: " + filename);
    std::string line;
    if (!std::getline(file, line)) throw std::runtime_error("Empty CSV: " + filename);
    auto header = parseCsv(line);
    if (header != columns) throw std::runtime_error("Unexpected CSV schema in " + filename);
    sqlite3_stmt* stmt = nullptr;
    const bool typed = table == "gps_measurements" || table == "tracking_estimates";
    check(sqlite3_prepare_v2(db_, ("INSERT INTO " + table + (typed ? "(payload,timestamp_value,vehicle_id_value) VALUES(?,?,?)" : "(payload) VALUES(?)")).c_str(), -1, &stmt, nullptr), db_);
    try {
        size_t row = 1;
        while (std::getline(file, line)) {
            ++row;
            if (line.empty()) continue;
            auto fields = parseCsv(line);
            if (fields.size() != columns.size()) throw std::runtime_error("CSV column mismatch: " + filename + ":" + std::to_string(row));
            std::string payload = "{";
            for (size_t i = 0; i < fields.size(); ++i) {
                if (i) payload += ',';
                payload += jsonEscape(columns[i]) + ":" + jsonEscape(fields[i]);
            }
            payload += "}";
            check(sqlite3_bind_text(stmt, 1, payload.c_str(), -1, SQLITE_TRANSIENT), db_);
            if (typed) {
                auto indexOf = [&columns](const std::string& key) {
                    auto it = std::find(columns.begin(), columns.end(), key);
                    if (it == columns.end()) throw std::runtime_error("Missing typed column: " + key);
                    return static_cast<size_t>(it - columns.begin());
                };
                const auto& ts = fields[indexOf("timestamp")];
                const auto& vid = fields[indexOf("vehicle_id")];
                char* end = nullptr;
                errno = 0;
                const double timestamp = std::strtod(ts.c_str(), &end);
                if (errno || end == ts.c_str() || *end || !std::isfinite(timestamp)) throw std::runtime_error("Invalid timestamp in " + filename + ":" + std::to_string(row));
                errno = 0;
                end = nullptr;
                const long long vehicle = std::strtoll(vid.c_str(), &end, 10);
                if (errno || end == vid.c_str() || *end || vehicle < 0) throw std::runtime_error("Invalid vehicle ID in " + filename + ":" + std::to_string(row));
                check(sqlite3_bind_double(stmt, 2, timestamp), db_);
                check(sqlite3_bind_int64(stmt, 3, vehicle), db_);
            }
            check(sqlite3_step(stmt), db_);
            check(sqlite3_reset(stmt), db_);
            check(sqlite3_clear_bindings(stmt), db_);
        }
        if (file.bad()) throw std::runtime_error("CSV read error: " + filename);
    } catch (...) { sqlite3_finalize(stmt); throw; }
    sqlite3_finalize(stmt);
}
void TrafficDatabase::importCsvDirectory(const std::string& directory) {
    const std::filesystem::path dir(directory);
    if (!std::filesystem::is_directory(dir)) throw std::runtime_error("CSV directory not found: " + directory);
    for (const auto& required : {"traffic_simulation.csv", "kalman_tracking.csv"}) {
        const auto path = dir / required;
        if (!std::filesystem::is_regular_file(path)) throw std::runtime_error("Required CSV missing: " + path.string());
    }
    execute("BEGIN IMMEDIATE TRANSACTION");
    try {
        for (const auto& table : allowed) execute("DELETE FROM " + table);
        importCsv((dir / "traffic_simulation.csv").string(), "gps_measurements", {"timestamp","vehicle_id","actual_x","actual_y","gps_x","gps_y"});
        importCsv((dir / "kalman_tracking.csv").string(), "tracking_estimates", {"timestamp","vehicle_id","actual_x","actual_y","gps_x","gps_y","estimated_x","estimated_y","gps_error","kalman_error","gps_fresh"});
        // Optional files are imported using their exact headers; their column names are read from the source.
        for (const auto& item : std::vector<std::pair<std::string,std::string>>{
            {"traffic_analytics.csv","traffic_analytics"}, {"traffic_alerts.csv","traffic_alerts"},
            {"kalman_benchmarks.csv","kalman_benchmarks"}, {"windows_os_metrics.csv","windows_os_metrics"}}) {
            std::ifstream file(dir / item.first);
            std::string header;
            if (file) {
                if (!std::getline(file, header)) throw std::runtime_error("Empty optional CSV: " + (dir / item.first).string());
                importCsv((dir / item.first).string(), item.second, parseCsv(header));
            }
        }
        execute("COMMIT");
    } catch (...) { try { execute("ROLLBACK"); } catch (...) {} throw; }
}
long long TrafficDatabase::count(const std::string& table) const {
    validateTable(table);
    sqlite3_stmt* stmt = nullptr;
    check(sqlite3_prepare_v2(db_, ("SELECT COUNT(*) FROM " + table).c_str(), -1, &stmt, nullptr), db_);
    const int rc = sqlite3_step(stmt);
    if (rc != SQLITE_ROW) { sqlite3_finalize(stmt); check(rc, db_); }
    const auto value = sqlite3_column_int64(stmt, 0);
    sqlite3_finalize(stmt);
    return value;
}
std::string TrafficDatabase::queryJson(const std::string& table, int limit, int offset) const {
    validateTable(table);
    limit = std::max(1, std::min(1000, limit));
    offset = std::max(0, offset);
    sqlite3_stmt* stmt = nullptr;
    check(sqlite3_prepare_v2(db_, ("SELECT payload FROM " + table + " ORDER BY id LIMIT ? OFFSET ?").c_str(), -1, &stmt, nullptr), db_);
    sqlite3_bind_int(stmt, 1, limit);
    sqlite3_bind_int(stmt, 2, offset);
    std::string result = "{\"total\":" + std::to_string(count(table)) + ",\"limit\":" + std::to_string(limit) + ",\"offset\":" + std::to_string(offset) + ",\"data\":[";
    bool first = true;
    int rc = SQLITE_OK;
    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        if (!first) result += ',';
        first = false;
        result += reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
    }
    sqlite3_finalize(stmt);
    if (rc != SQLITE_DONE) check(rc, db_);
    return result + "]}";
}
std::string TrafficDatabase::summaryJson() const {
    std::string result = "{\"status\":\"ok\",\"storage\":\"sqlite\",\"counts\":{";
    bool first = true;
    for (const auto& table : allowed) {
        if (!first) result += ',';
        first = false;
        result += jsonEscape(table) + ":" + std::to_string(count(table));
    }
    return result + "}}";
}
}

namespace SmartTraffic {
std::string TrafficDatabase::latestVehiclesJson(int limit, int offset) const {
    limit = std::max(1, std::min(1000, limit));
    offset = std::max(0, offset);
    sqlite3_stmt* stmt = nullptr;
    const std::string sql =
        "SELECT payload FROM tracking_estimates t WHERE id = ("
        "SELECT id FROM tracking_estimates s WHERE s.vehicle_id_value=t.vehicle_id_value "
        "ORDER BY s.timestamp_value DESC,s.id DESC LIMIT 1) "
        "ORDER BY t.vehicle_id_value LIMIT ? OFFSET ?";
    check(sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr), db_);
    sqlite3_bind_int(stmt, 1, limit);
    sqlite3_bind_int(stmt, 2, offset);
    sqlite3_stmt* totalStmt = nullptr;
    check(sqlite3_prepare_v2(db_, "SELECT COUNT(DISTINCT vehicle_id_value) FROM tracking_estimates", -1, &totalStmt, nullptr), db_);
    const int totalRc = sqlite3_step(totalStmt);
    if (totalRc != SQLITE_ROW) { sqlite3_finalize(totalStmt); sqlite3_finalize(stmt); check(totalRc, db_); }
    const long long total = sqlite3_column_int64(totalStmt, 0);
    sqlite3_finalize(totalStmt);
    std::string result = "{\"total\":" + std::to_string(total) + ",\"limit\":" + std::to_string(limit) + ",\"offset\":" + std::to_string(offset) + ",\"data\":[";
    bool first = true;
    int rc;
    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        if (!first) result += ',';
        first = false;
        result += reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
    }
    sqlite3_finalize(stmt);
    if (rc != SQLITE_DONE) check(rc, db_);
    return result + "]}";
}
}
