#include "smart_traffic/database/traffic_database.h"
#include <algorithm>
#include <limits>
#include <cctype>
#include <atomic>
#include <csignal>
#include <cstdlib>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <sstream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <vector>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iterator>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
using Socket = SOCKET;
constexpr Socket invalidSocket = INVALID_SOCKET;
void closeSocket(Socket s) { closesocket(s); }
void socketTimeout(Socket s) { DWORD ms = 2000; setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&ms), sizeof(ms)); setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, reinterpret_cast<const char*>(&ms), sizeof(ms)); }
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
using Socket = int;
constexpr Socket invalidSocket = -1;
void closeSocket(Socket s) { close(s); }
void socketTimeout(Socket s) { timeval tv{2,0}; setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)); setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)); }
#endif
namespace {
std::atomic<bool> running{true};
void stopHandler(int) { running = false; }
int queryNumber(const std::string& path, const std::string& key, int fallback) {
    auto pos = path.find('?');
    if (pos == std::string::npos) return fallback;
    std::istringstream stream(path.substr(pos + 1));
    std::string pair;
    while (std::getline(stream, pair, '&')) {
        auto sep = pair.find('=');
        if (sep == std::string::npos || pair.substr(0, sep) != key) continue;
        const std::string value = pair.substr(sep + 1);
        if (value.empty() || value.size() > 10 ||
            !std::all_of(value.begin(), value.end(), [](unsigned char c){ return std::isdigit(c) != 0; }))
            throw std::invalid_argument("invalid " + key + " parameter");
        unsigned long long number = 0;
        try { number = std::stoull(value); }
        catch (...) { throw std::invalid_argument("invalid " + key + " parameter"); }
        if (number > static_cast<unsigned long long>(std::numeric_limits<int>::max()) ||
            (key == "limit" && (number < 1 || number > 1000)))
            throw std::invalid_argument("invalid " + key + " parameter");
        return static_cast<int>(number);
    }
    return fallback;
}
void reply(Socket client, int status, const std::string& body, const std::string& mime = "application/json; charset=utf-8") {
    const std::string response = "HTTP/1.1 " + std::to_string(status) + (status == 200 ? " OK" : " Error") +
        "\r\nContent-Type: " + mime + "\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\nContent-Length: " + std::to_string(body.size()) + "\r\n\r\n" + body;
    size_t sent = 0;
    while (sent < response.size()) {
        int n = send(client, response.data() + sent, static_cast<int>(std::min<size_t>(response.size() - sent, 16384)), 0);
        if (n <= 0) break;
        sent += static_cast<size_t>(n);
    }
}
}
int main(int argc, char** argv) {
    std::string database = "data/smarttraffic.db", csvDirectory = "data", webDirectory = "web";
    int port = 8080;
    bool import = false;
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--db" && i + 1 < argc) database = argv[++i];
        else if (arg == "--data" && i + 1 < argc) csvDirectory = argv[++i];
        else if (arg == "--web" && i + 1 < argc) webDirectory = argv[++i];
        else if (arg == "--port" && i + 1 < argc) port = std::stoi(argv[++i]);
        else if (arg == "--import") import = true;
        else { std::cerr << "Usage: SmartTrafficApi [--db PATH] [--data CSV_DIR] [--port 1..65535] [--web DIR] [--import]\n"; return 2; }
    }
    if (port < 1 || port > 65535) { std::cerr << "Invalid port\n"; return 2; }
    try {
        SmartTraffic::TrafficDatabase db(database);
        if (import) db.importCsvDirectory(csvDirectory);
#ifdef _WIN32
        WSADATA wsa{};
        if (WSAStartup(MAKEWORD(2,2), &wsa) != 0) throw std::runtime_error("WSAStartup failed");
#endif
        Socket server = socket(AF_INET, SOCK_STREAM, 0);
        if (server == invalidSocket) throw std::runtime_error("socket failed");
        int reuse = 1;
        setsockopt(server, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&reuse), sizeof(reuse));
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(static_cast<unsigned short>(port));
        addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK); // Localhost only: no authentication.
        if (bind(server, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0 || listen(server, 16) != 0) {
            closeSocket(server);
            throw std::runtime_error("bind/listen failed");
        }
        std::signal(SIGINT, stopHandler);
        std::cout << "SmartTraffic Phase 5 API: http://127.0.0.1:" << port << "/api/health\n" << std::flush;
        // A bounded pool prevents one slow client from blocking other API requests.
        std::mutex queueMutex, databaseMutex;
        std::condition_variable queueCv;
        std::queue<Socket> pending;
        bool stopping = false;
        auto serve = [&](Socket client) {
            socketTimeout(client);
            char buffer[8192];
            int n = recv(client, buffer, sizeof(buffer), 0);
            if (n <= 0) { closeSocket(client); return; }
            if (n > 0) {
                std::string request(buffer, static_cast<size_t>(n));
                std::istringstream input(request);
                std::string method, path, version;
                input >> method >> path >> version;
                try {
                    if (method.empty() || path.empty() || version.rfind("HTTP/",0) != 0) {
                        reply(client, 400, "{\"error\":\"malformed request\"}");
                        closeSocket(client);
                        return;
                    }
                    const auto q = path.find('?');
                    const auto route = path.substr(0, q);
                    std::lock_guard<std::mutex> dbLock(databaseMutex);
                    if (method == "OPTIONS") reply(client, 200, "{}");
                    else if (method != "GET") reply(client, 405, "{\"error\":\"method not allowed\"}");
                    else if (route == "/api/health" || route == "/api/health/") reply(client, 200, "{\"status\":\"ok\",\"service\":\"SmartTrafficApi\"}");
                    else if (route == "/api/summary") reply(client, 200, db.summaryJson());
                    else if (route == "/" || route == "/index.html" || route == "/styles.css" || route == "/app.js") {
                        const std::string filename = route == "/" ? "index.html" : route.substr(1);
                        std::ifstream asset(std::filesystem::path(webDirectory) / filename, std::ios::binary);
                        if (!asset) reply(client, 404, "{\"error\":\"web asset missing\"}");
                        else {
                            const std::string body((std::istreambuf_iterator<char>(asset)), std::istreambuf_iterator<char>());
                            const std::string mime = filename == "styles.css" ? "text/css; charset=utf-8" : filename == "app.js" ? "application/javascript; charset=utf-8" : "text/html; charset=utf-8";
                            reply(client, 200, body, mime);
                        }
                    }
                    else {
                        const std::map<std::string, std::string> routes = {
                            {"/api/gps","gps_measurements"},
                            {"/api/tracking","tracking_estimates"}, {"/api/analytics","traffic_analytics"},
                            {"/api/alerts","traffic_alerts"}, {"/api/benchmarks","kalman_benchmarks"},
                            {"/api/os-metrics","windows_os_metrics"}
                        };
                        const auto it = routes.find(route);
                        if (route == "/api/vehicles") reply(client, 200, db.latestVehiclesJson(queryNumber(path,"limit",100), queryNumber(path,"offset",0)));
                        else if (it == routes.end()) reply(client, 404, "{\"error\":\"not found\"}");
                        else reply(client, 200, db.queryJson(it->second, queryNumber(path,"limit",100), queryNumber(path,"offset",0)));
                    }
                } catch (const std::invalid_argument& e) { reply(client, 400, "{\"error\":" + SmartTraffic::TrafficDatabase::jsonEscape(e.what()) + "}"); } catch (const std::exception& e) { reply(client, 500, "{\"error\":" + SmartTraffic::TrafficDatabase::jsonEscape(e.what()) + "}"); }
            }
            closeSocket(client);
        };
        std::vector<std::thread> workers;
        for (int i = 0; i < 4; ++i) workers.emplace_back([&] {
            while (true) {
                Socket client;
                {
                    std::unique_lock<std::mutex> lock(queueMutex);
                    queueCv.wait(lock, [&]{ return stopping || !pending.empty(); });
                    if (stopping && pending.empty()) return;
                    client = pending.front(); pending.pop();
                }
                serve(client);
            }
        });
        while (running) {
            Socket client = accept(server, nullptr, nullptr);
            if (client == invalidSocket) continue;
            bool full;
            {
                std::lock_guard<std::mutex> lock(queueMutex);
                full = pending.size() >= 64;
                if (!full) pending.push(client);
            }
            if (full) { socketTimeout(client); reply(client, 503, "{\"error\":\"server busy\"}"); closeSocket(client); }
            else queueCv.notify_one();
        }
        closeSocket(server);
        { std::lock_guard<std::mutex> lock(queueMutex); stopping = true; }
        queueCv.notify_all();
        for (auto& worker : workers) worker.join();
#ifdef _WIN32
        WSACleanup();
#endif
    } catch (const std::exception& e) { std::cerr << "API error: " << e.what() << '\n'; return 1; }
}
