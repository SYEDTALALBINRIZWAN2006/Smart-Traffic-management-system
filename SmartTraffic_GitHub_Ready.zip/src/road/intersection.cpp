#include "smart_traffic/road/intersection.h"
#include <algorithm>
#include <sstream>

namespace SmartTraffic {

Intersection::Intersection(uint32_t id,
                           const std::string& name,
                           const Position& center,
                           double radius_meters)
    : id_(id),
      name_(name),
      center_(center),
      radius_(std::max(1.0, radius_meters)) {
}

void Intersection::addIncomingLane(uint32_t lane_id) {
    if (std::find(incoming_lane_ids_.begin(), incoming_lane_ids_.end(), lane_id) == incoming_lane_ids_.end()) {
        incoming_lane_ids_.push_back(lane_id);
    }
}

void Intersection::addOutgoingLane(uint32_t lane_id) {
    if (std::find(outgoing_lane_ids_.begin(), outgoing_lane_ids_.end(), lane_id) == outgoing_lane_ids_.end()) {
        outgoing_lane_ids_.push_back(lane_id);
    }
}

void Intersection::addLaneRoute(uint32_t incoming_lane_id, uint32_t outgoing_lane_id) {
    addIncomingLane(incoming_lane_id);
    addOutgoingLane(outgoing_lane_id);

    auto& routes = incoming_to_outgoing_routes_[incoming_lane_id];
    if (std::find(routes.begin(), routes.end(), outgoing_lane_id) == routes.end()) {
        routes.push_back(outgoing_lane_id);
    }
}

std::vector<uint32_t> Intersection::getConnectedOutgoingLanes(uint32_t incoming_lane_id) const {
    const auto it = incoming_to_outgoing_routes_.find(incoming_lane_id);
    if (it != incoming_to_outgoing_routes_.end()) {
        return it->second;
    }
    return {};
}

bool Intersection::isInside(const Position& pos) const noexcept {
    return center_.distanceTo(pos) <= radius_;
}

std::string Intersection::toString() const {
    std::ostringstream ss;
    ss << "Intersection[ID=" << id_ << ", Name=" << name_
       << ", Center=" << center_.toString()
       << ", Radius=" << radius_ << "m, Incoming=" << incoming_lane_ids_.size()
       << ", Outgoing=" << outgoing_lane_ids_.size() << "]";
    return ss.str();
}

} // namespace SmartTraffic
