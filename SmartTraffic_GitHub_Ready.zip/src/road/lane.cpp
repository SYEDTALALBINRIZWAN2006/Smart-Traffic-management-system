#include "smart_traffic/road/lane.h"
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <stdexcept>

namespace SmartTraffic {

Lane::Lane(uint32_t id,
           const std::string& name,
           const Position& start_point,
           const Position& end_point,
           double speed_limit_mps,
           Direction direction)
    : id_(id),
      name_(name),
      start_point_(start_point),
      end_point_(end_point),
      length_(start_point.distanceTo(end_point)),
      speed_limit_(std::max(1.0, speed_limit_mps)),
      direction_(direction) {
    if (length_ <= 0.0) {
        throw std::invalid_argument("Lane length must be strictly positive: start and end points cannot coincide");
    }
}

void Lane::setSpeedLimit(double limit) noexcept {
    if (limit > 0.0) {
        speed_limit_ = limit;
    }
}

void Lane::addSuccessorLane(uint32_t next_lane_id) {
    if (std::find(successor_lane_ids_.begin(), successor_lane_ids_.end(), next_lane_id) == successor_lane_ids_.end()) {
        successor_lane_ids_.push_back(next_lane_id);
    }
}

Position Lane::getPositionAtDistance(double distance) const noexcept {
    if (length_ <= 0.0) {
        return start_point_;
    }
    const double t = std::clamp(distance / length_, 0.0, 1.0);
    return start_point_.lerp(end_point_, t);
}

double Lane::getHeadingRadians() const noexcept {
    return std::atan2(end_point_.y - start_point_.y, end_point_.x - start_point_.x);
}

Velocity Lane::getVelocityVector(double speed_mps) const noexcept {
    const double heading = getHeadingRadians();
    return Velocity::fromSpeedAndHeading(speed_mps, heading);
}

bool Lane::isAtEndOfLane(double distance) const noexcept {
    return distance >= length_;
}

std::string Lane::toString() const {
    std::ostringstream ss;
    ss << "Lane[ID=" << id_ << ", Name=" << name_
       << ", Start=" << start_point_.toString()
       << ", End=" << end_point_.toString()
       << ", Length=" << std::fixed << std::setprecision(2) << length_ << "m"
       << ", Limit=" << speed_limit_ << "m/s]";
    return ss.str();
}

} // namespace SmartTraffic
