#include "smart_traffic/road/road_network.h"
#include <stdexcept>

namespace SmartTraffic {

RoadNetwork::RoadNetwork() = default;

void RoadNetwork::addLane(std::shared_ptr<Lane> lane) {
    if (!lane) {
        throw std::invalid_argument("Cannot add null lane to RoadNetwork");
    }
    lanes_[lane->getId()] = lane;
}

void RoadNetwork::addIntersection(std::shared_ptr<Intersection> intersection) {
    if (!intersection) {
        throw std::invalid_argument("Cannot add null intersection to RoadNetwork");
    }
    intersections_[intersection->getId()] = intersection;
}

std::shared_ptr<Lane> RoadNetwork::getLane(uint32_t lane_id) const {
    const auto it = lanes_.find(lane_id);
    if (it != lanes_.end()) {
        return it->second;
    }
    return nullptr;
}

std::shared_ptr<Intersection> RoadNetwork::getIntersection(uint32_t intersection_id) const {
    const auto it = intersections_.find(intersection_id);
    if (it != intersections_.end()) {
        return it->second;
    }
    return nullptr;
}

std::optional<uint32_t> RoadNetwork::getNextLaneId(uint32_t current_lane_id, uint64_t route_seed) const {
    auto current_lane = getLane(current_lane_id);
    if (!current_lane) {
        return std::nullopt;
    }

    const auto& successors = current_lane->getSuccessorLanes();
    if (successors.empty()) {
        return std::nullopt;
    }

    // Deterministic selection among possible successor lanes
    const size_t choice = route_seed % successors.size();
    return successors[choice];
}

void RoadNetwork::buildStandardFourWayIntersection(double corridor_length_meters,
                                                   double lane_width_meters,
                                                   double speed_limit_mps) {
    lanes_.clear();
    intersections_.clear();
    spawn_lane_ids_.clear();

    const double half_w = lane_width_meters * 0.5;
    const double int_box = 12.0; // Half-size of intersection center in meters
    const double intersection_speed_limit = speed_limit_mps * 0.7; // Slower inside intersection

    // 1. Approach Lanes (Vehicle entry / spawn corridors)
    // Lane 1: South Approach (moving North: y from -corridor to -int_box)
    auto lane_south_app = std::make_shared<Lane>(
        1, "South_Approach",
        Position(half_w, -corridor_length_meters),
        Position(half_w, -int_box),
        speed_limit_mps, Direction::NORTH);

    // Lane 2: North Approach (moving South: y from +corridor to +int_box)
    auto lane_north_app = std::make_shared<Lane>(
        2, "North_Approach",
        Position(-half_w, corridor_length_meters),
        Position(-half_w, int_box),
        speed_limit_mps, Direction::SOUTH);

    // Lane 3: West Approach (moving East: x from -corridor to -int_box)
    auto lane_west_app = std::make_shared<Lane>(
        3, "West_Approach",
        Position(-corridor_length_meters, -half_w),
        Position(-int_box, -half_w),
        speed_limit_mps, Direction::EAST);

    // Lane 4: East Approach (moving West: x from +corridor to +int_box)
    auto lane_east_app = std::make_shared<Lane>(
        4, "East_Approach",
        Position(corridor_length_meters, half_w),
        Position(int_box, half_w),
        speed_limit_mps, Direction::WEST);

    // 2. Exit Lanes (Departing corridors)
    // Lane 11: North Exit (moving North: y from +int_box to +corridor)
    auto lane_north_exit = std::make_shared<Lane>(
        11, "North_Exit",
        Position(half_w, int_box),
        Position(half_w, corridor_length_meters),
        speed_limit_mps, Direction::NORTH);

    // Lane 12: South Exit (moving South: y from -int_box to -corridor)
    auto lane_south_exit = std::make_shared<Lane>(
        12, "South_Exit",
        Position(-half_w, -int_box),
        Position(-half_w, -corridor_length_meters),
        speed_limit_mps, Direction::SOUTH);

    // Lane 13: East Exit (moving East: x from +int_box to +corridor)
    auto lane_east_exit = std::make_shared<Lane>(
        13, "East_Exit",
        Position(int_box, -half_w),
        Position(corridor_length_meters, -half_w),
        speed_limit_mps, Direction::EAST);

    // Lane 14: West Exit (moving West: x from -int_box to -corridor)
    auto lane_west_exit = std::make_shared<Lane>(
        14, "West_Exit",
        Position(-int_box, half_w),
        Position(-corridor_length_meters, half_w),
        speed_limit_mps, Direction::WEST);

    // 3. Internal Intersection Connector Lanes
    // Straight connectors
    auto conn_s_n = std::make_shared<Lane>(101, "Connect_S_N", Position(half_w, -int_box), Position(half_w, int_box), intersection_speed_limit, Direction::NORTH);
    auto conn_n_s = std::make_shared<Lane>(102, "Connect_N_S", Position(-half_w, int_box), Position(-half_w, -int_box), intersection_speed_limit, Direction::SOUTH);
    auto conn_w_e = std::make_shared<Lane>(103, "Connect_W_E", Position(-int_box, -half_w), Position(int_box, -half_w), intersection_speed_limit, Direction::EAST);
    auto conn_e_w = std::make_shared<Lane>(104, "Connect_E_W", Position(int_box, half_w), Position(-int_box, half_w), intersection_speed_limit, Direction::WEST);

    // Right-turn connectors
    auto conn_s_e = std::make_shared<Lane>(105, "Connect_S_E", Position(half_w, -int_box), Position(int_box, -half_w), intersection_speed_limit, Direction::EAST);
    auto conn_n_w = std::make_shared<Lane>(106, "Connect_N_W", Position(-half_w, int_box), Position(-int_box, half_w), intersection_speed_limit, Direction::WEST);
    auto conn_w_s = std::make_shared<Lane>(107, "Connect_W_S", Position(-int_box, -half_w), Position(-half_w, -int_box), intersection_speed_limit, Direction::SOUTH);
    auto conn_e_n = std::make_shared<Lane>(108, "Connect_E_N", Position(int_box, half_w), Position(half_w, int_box), intersection_speed_limit, Direction::NORTH);

    // Left-turn connectors
    auto conn_s_w = std::make_shared<Lane>(109, "Connect_S_W", Position(half_w, -int_box), Position(-int_box, half_w), intersection_speed_limit, Direction::WEST);
    auto conn_n_e = std::make_shared<Lane>(110, "Connect_N_E", Position(-half_w, int_box), Position(int_box, -half_w), intersection_speed_limit, Direction::EAST);
    auto conn_w_n = std::make_shared<Lane>(111, "Connect_W_N", Position(-int_box, -half_w), Position(half_w, int_box), intersection_speed_limit, Direction::NORTH);
    auto conn_e_s = std::make_shared<Lane>(112, "Connect_E_S", Position(int_box, half_w), Position(-half_w, -int_box), intersection_speed_limit, Direction::SOUTH);

    // Wire approach lanes to intersection connectors
    lane_south_app->addSuccessorLane(101); // Straight to North
    lane_south_app->addSuccessorLane(105); // Right to East
    lane_south_app->addSuccessorLane(109); // Left to West

    lane_north_app->addSuccessorLane(102); // Straight to South
    lane_north_app->addSuccessorLane(106); // Right to West
    lane_north_app->addSuccessorLane(110); // Left to East

    lane_west_app->addSuccessorLane(103);  // Straight to East
    lane_west_app->addSuccessorLane(107);  // Right to South
    lane_west_app->addSuccessorLane(111);  // Left to North

    lane_east_app->addSuccessorLane(104);  // Straight to West
    lane_east_app->addSuccessorLane(108);  // Right to North
    lane_east_app->addSuccessorLane(112);  // Left to South

    // Wire intersection connectors to exit lanes
    conn_s_n->addSuccessorLane(11); // North Exit
    conn_e_n->addSuccessorLane(11);
    conn_w_n->addSuccessorLane(11);

    conn_n_s->addSuccessorLane(12); // South Exit
    conn_w_s->addSuccessorLane(12);
    conn_e_s->addSuccessorLane(12);

    conn_w_e->addSuccessorLane(13); // East Exit
    conn_s_e->addSuccessorLane(13);
    conn_n_e->addSuccessorLane(13);

    conn_e_w->addSuccessorLane(14); // West Exit
    conn_n_w->addSuccessorLane(14);
    conn_s_w->addSuccessorLane(14);

    // Register all lanes
    addLane(lane_south_app);
    addLane(lane_north_app);
    addLane(lane_west_app);
    addLane(lane_east_app);

    addLane(lane_north_exit);
    addLane(lane_south_exit);
    addLane(lane_east_exit);
    addLane(lane_west_exit);

    addLane(conn_s_n);
    addLane(conn_n_s);
    addLane(conn_w_e);
    addLane(conn_e_w);
    addLane(conn_s_e);
    addLane(conn_n_w);
    addLane(conn_w_s);
    addLane(conn_e_n);
    addLane(conn_s_w);
    addLane(conn_n_e);
    addLane(conn_w_n);
    addLane(conn_e_s);

    // Register spawn lanes
    spawn_lane_ids_ = { 1, 2, 3, 4 };

    // Create and register intersection
    auto intersection = std::make_shared<Intersection>(1, "Central_Intersection", Position(0.0, 0.0), int_box * 1.414);
    intersection->addIncomingLane(1);
    intersection->addIncomingLane(2);
    intersection->addIncomingLane(3);
    intersection->addIncomingLane(4);

    intersection->addOutgoingLane(11);
    intersection->addOutgoingLane(12);
    intersection->addOutgoingLane(13);
    intersection->addOutgoingLane(14);

    addIntersection(intersection);
}

} // namespace SmartTraffic
