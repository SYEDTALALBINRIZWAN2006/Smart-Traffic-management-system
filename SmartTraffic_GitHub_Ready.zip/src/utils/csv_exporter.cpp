#include "smart_traffic/utils/csv_exporter.h"
#include <filesystem>
#include <stdexcept>
#include <iomanip>

namespace SmartTraffic {

CsvExporter::CsvExporter(const std::string& output_filepath) {
    if (!output_filepath.empty()) {
        open(output_filepath);
    }
}

CsvExporter::~CsvExporter() {
    close();
}

void CsvExporter::open(const std::string& output_filepath) {
    close();
    filepath_ = output_filepath;

    if (filepath_.empty()) {
        is_open_ = false;
        row_count_ = 0;
        return;
    }

    // Ensure target parent directory exists
    std::filesystem::path path(filepath_);
    if (path.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(path.parent_path(), ec);
        if (ec) {
            throw std::runtime_error("Failed to create directory for CSV export: " + path.parent_path().string() + " (" + ec.message() + ")");
        }
    }

    file_stream_.open(filepath_, std::ios::out | std::ios::trunc);
    if (!file_stream_.is_open()) {
        throw std::runtime_error("Failed to open CSV file for writing: " + filepath_);
    }

    // Write header according to specifications: timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y
    file_stream_ << "timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y\n";
    file_stream_ << std::fixed << std::setprecision(4);

    is_open_ = true;
    row_count_ = 0;
}

void CsvExporter::writeRow(const GpsMeasurement& measurement) {
    if (!is_open_) {
        return; // Safely no-op when CSV export is disabled
    }

    file_stream_ << measurement.timestamp << ","
                 << measurement.vehicle_id << ","
                 << measurement.actual_x << ","
                 << measurement.actual_y << ","
                 << measurement.gps_x << ","
                 << measurement.gps_y << "\n";

    row_count_++;
}

void CsvExporter::writeRows(const std::vector<GpsMeasurement>& measurements) {
    for (const auto& m : measurements) {
        writeRow(m);
    }
}

void CsvExporter::flush() {
    if (is_open_) {
        file_stream_.flush();
    }
}

void CsvExporter::close() {
    if (is_open_) {
        file_stream_.flush();
        file_stream_.close();
        is_open_ = false;
    }
}

} // namespace SmartTraffic
