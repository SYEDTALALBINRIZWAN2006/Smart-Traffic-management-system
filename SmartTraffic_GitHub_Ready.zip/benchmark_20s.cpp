#include "smart_traffic/simulation/traffic_simulator.h"
#include "smart_traffic/config/simulation_config.h"
#include <iostream>
#include <iomanip>
#include <vector>

int main() {
    std::cout << "=========================================================================================================\n";
    std::cout << "               20-SECOND, 10-VEHICLE TEST CONFIGURATION BENCHMARK EVALUATION                             \n";
    std::cout << "=========================================================================================================\n";

    const std::vector<uint64_t> seeds = { 42, 1001, 7777 };
    const std::vector<double> noise_levels = { 1.5, 2.5, 4.0 };

    std::cout << std::left 
              << std::setw(8)  << "Seed"
              << std::setw(12) << "Noise (m)"
              << std::setw(16) << "GPS RMSE (m)"
              << std::setw(18) << "Kalman RMSE (m)"
              << std::setw(20) << "All-Tick RMSE (m)"
              << std::setw(16) << "Reduction (%)"
              << std::setw(14) << "Samples"
              << "\n";
    std::cout << std::string(105, '-') << "\n";

    double sum_gps = 0.0;
    double sum_kalman = 0.0;
    int count = 0;

    for (uint64_t seed : seeds) {
        for (double noise_std : noise_levels) {
            SmartTraffic::SimulationConfig config = SmartTraffic::SimulationConfig::createDefault();
            config.vehicle_count = 10;
            config.total_simulation_time = 20.0;
            config.random_seed = seed;
            config.gps_noise_stddev = noise_std;
            config.kalman_measurement_noise_stddev = noise_std;
            config.kalman_process_noise_stddev = 1.0;
            config.enable_console_progress = false;
            config.output_csv_path = "";
            config.tracking_csv_path = "";

            SmartTraffic::TrafficSimulator sim(config);
            const auto summary = sim.run();
            const auto& tm = summary.tracking_metrics;

            sum_gps += tm.gps_rmse_meters;
            sum_kalman += tm.kalman_rmse_meters;
            count++;

            std::cout << std::left
                      << std::setw(8)  << seed
                      << std::fixed << std::setprecision(1) << std::setw(12) << noise_std
                      << std::fixed << std::setprecision(4) << std::setw(16) << tm.gps_rmse_meters
                      << std::fixed << std::setprecision(4) << std::setw(18) << tm.kalman_rmse_meters
                      << std::fixed << std::setprecision(4) << std::setw(20) << tm.kalman_all_ticks_rmse_meters
                      << std::fixed << std::setprecision(2) << std::setw(16) << tm.error_reduction_percentage
                      << std::setw(14) << tm.comparable_sample_count
                      << "\n";
        }
    }
    std::cout << "=========================================================================================================\n";
    std::cout << "Mean GPS RMSE: " << (sum_gps / count) << " m | Mean Kalman RMSE: " << (sum_kalman / count) << " m\n";
    std::cout << "Overall Mean Error Reduction: " << ((sum_gps - sum_kalman) / sum_gps * 100.0) << " %\n";
    return 0;
}
