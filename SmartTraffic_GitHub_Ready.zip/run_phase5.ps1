$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
cmake -S . -B build-phase5 -DCMAKE_BUILD_TYPE=Release
if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed' }
cmake --build build-phase5 --config Release
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
ctest --test-dir build-phase5 -C Release --output-on-failure
if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
$exe = Join-Path $root 'build-phase5/Release/SmartTraffic.exe'
$api = Join-Path $root 'build-phase5/Release/SmartTrafficApi.exe'
if (-not (Test-Path $exe)) { $exe = Join-Path $root 'build-phase5/SmartTraffic.exe' }
if (-not (Test-Path $api)) { $api = Join-Path $root 'build-phase5/SmartTrafficApi.exe' }
& $exe
if ($LASTEXITCODE -ne 0) { throw 'Simulation failed' }
Write-Host 'Phase 5 API available at http://127.0.0.1:8080/api/summary'
& $api --db 'data/smarttraffic.db' --data data --import --port 8080
