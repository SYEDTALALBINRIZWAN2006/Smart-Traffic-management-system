$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$logDir = Join-Path $PSScriptRoot 'verification_logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
function Run-Step([string]$label, [string]$exe, [string[]]$arguments) {
  Write-Host "`n=== $label ==="
  & $exe @arguments 2>&1 | Tee-Object -FilePath (Join-Path $logDir ($label + '.log'))
  if ($LASTEXITCODE -ne 0) { throw "$label failed (exit $LASTEXITCODE)" }
}
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) { throw 'Open x64 Native Tools Command Prompt for Visual Studio first (cl.exe missing).' }
Run-Step '01-configure' 'cmake' @('-S','.','-B','build-msvc','-G','NMake Makefiles','-DCMAKE_BUILD_TYPE=Release')
Run-Step '02-build' 'cmake' @('--build','build-msvc','--config','Release')
Run-Step '03-ctest' 'ctest' @('--test-dir','build-msvc','-C','Release','--output-on-failure')
$exe = Join-Path $PSScriptRoot 'build-msvc/SmartTraffic.exe'
$tests = Join-Path $PSScriptRoot 'build-msvc/SmartTrafficTests.exe'
$worker = Join-Path $PSScriptRoot 'build-msvc/kalman_worker.exe'
foreach ($f in @($exe,$tests,$worker)) { if (-not (Test-Path $f)) { throw "Required executable missing: $f" } }
Push-Location (Join-Path $PSScriptRoot 'build-msvc')
try {
  Run-Step '04-individual-tests' $tests @()
  Run-Step '05-simulation' $exe @()
  Run-Step '06-benchmark' $exe @('--benchmark')
  $csvs = @{'traffic_simulation.csv'=6;'kalman_tracking.csv'=11;'traffic_analytics.csv'=9;'traffic_alerts.csv'=11;'kalman_benchmarks.csv'=12;'windows_os_metrics.csv'=10}
  foreach ($entry in $csvs.GetEnumerator()) {
    $path = Join-Path (Get-Location) ('data/' + $entry.Key)
    if (-not (Test-Path $path)) { throw "CSV missing: $path" }
    $rows = @(Import-Csv $path)
    if ($rows.Count -eq 0) { throw "CSV empty: $path" }
    $head = @((Get-Content $path -TotalCount 1) -split ',')
    if ($head.Count -ne $entry.Value) { throw "CSV column mismatch: $path" }
    foreach ($r in $rows) { if ($r.PSObject.Properties.Count -ne $entry.Value) { throw "CSV malformed: $path" } }
    Write-Host "CSV PASS: $($entry.Key) ($($rows.Count) rows)"
  }
} finally { Pop-Location }
'All verification steps executed successfully.' | Tee-Object -FilePath (Join-Path $logDir 'RESULT.txt')
