# SmartTraffic final repaired build — verification

## Fixes
- Dashboard analytics now reads the actual CSV/SQLite columns (`avg_network_speed_kmh`, `total_active_vehicles`, `network_congestion`, `avg_density_veh_per_km`).
- Dashboard retrieves all tracking rows through paginated `/api/tracking` calls instead of truncating to the first 1,000.
- REST API rejects invalid `limit`/`offset` parameters with HTTP 400, including non-numeric, negative, overflow, zero limit, and limit > 1000.

## Executed here (Linux)
- Fresh CMake C++17 Release build: PASS.
- CTest: 2/2 registered suites PASS.
- Simulation: PASS, four nonempty CSV exports.
- SQLite import: PASS, 744 GPS, 7,294 tracking, 600 analytics, 60 alerts, 30 latest vehicle snapshots.
- 26 additional integration probes: 26/26 PASS (see SmartTraffic_Final_Test_Report.txt distributed alongside ZIP).
- JavaScript syntax (`node --check`): PASS.

## Remaining verification limitations
- Native Windows MSVC build, Windows worker processes, shared-memory IPC and Windows benchmarks were not tested on this Linux environment.
- Automated real-browser clicking, chart pixel rendering and visual regression tests were not completed; static assets and JavaScript syntax were checked.
- The UI presents latest recorded simulation data, not a live GPS feed. No authentication: localhost-only prototype.
- No test suite can establish absence of all bugs. Use the Windows startup script and verify six dashboard pages before submission.

## Run
Linux: `./run_dashboard.sh` (requires CMake, C++17 compiler, SQLite development library).
Windows: `powershell -ExecutionPolicy Bypass -File .\\run_dashboard.ps1` (requires CMake, C++17 Windows compiler, SQLite development library).
Open http://127.0.0.1:8080 .
