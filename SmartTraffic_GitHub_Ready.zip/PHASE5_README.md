# Phase 5 — SQLite and REST API

Phase 5 adds **SmartTrafficApi** (C++17, SQLite3, local HTTP server), **smart_traffic_database** and **SmartTrafficDatabaseTests**. The existing simulation, Kalman, analytics, Windows worker and benchmark source files are retained.

## Dependencies

- C++17 compiler and CMake 3.15+
- SQLite3 development library and headers (`find_package(SQLite3 REQUIRED)`). On Windows, install SQLite3 via vcpkg, then configure with `-DCMAKE_TOOLCHAIN_FILE=C:/path/to/vcpkg/scripts/buildsystems/vcpkg.cmake`. The SQLite3 package is **not bundled**.
- Native Windows MSVC and Windows SDK are still required for Windows-specific Phase 4 verification; this Linux test does not establish Win32 runtime correctness.

## Run on Windows

From an x64 Native Tools prompt (with SQLite3 installed):

```powershell
powershell -ExecutionPolicy Bypass -File .\run_phase5.ps1
```

Alternatively configure and build using CMake, run `SmartTraffic.exe` to produce CSVs, then start `SmartTrafficApi.exe --db data/smarttraffic.db --data data --import --port 8080` from the project directory.

## REST endpoints

The API binds **127.0.0.1** only (no authentication; not for public deployment). GET endpoints:

- `/api/health` — service health
- `/api/summary` — row counts per dataset
- `/api/gps` — raw GPS observations
- `/api/vehicles` — tracking records (historical, not live positions)
- `/api/tracking` — Kalman tracking records
- `/api/analytics` — congestion and traffic snapshots
- `/api/alerts` — alert history
- `/api/benchmarks` — saved Kalman benchmarks, when present
- `/api/os-metrics` — saved Windows metrics, when present

Dataset endpoints support `?limit=100&offset=0` (maximum 1000 rows). `OPTIONS` is supported for browser CORS preflight. The database is imported at startup with `--import`; each import replaces previous rows atomically. This is a **historical snapshot API**, not live streaming. Restart with `--import` to refresh after a new simulation. CSV values are stored as JSON strings to preserve the original exported representation. Missing optional CSV exports produce empty tables. CSV headers must match the required raw GPS and Kalman schema; optional datasets use their exported headers.

## Security and limitations

The HTTP server is deliberately minimal and single-threaded. It is suitable for local demonstration only. It does not support authentication, TLS, rate limiting, real-time WebSockets, multi-client streaming or write endpoints. CSV source files are trusted local inputs, and malformed rows abort an import transaction. Do not expose this server to the Internet.

## Verification

Run `ctest --test-dir build-phase5 -C Release --output-on-failure`. This includes the existing portable suite and the new SQLite integration suite. On Windows it also includes Phase 4 Windows tests; those must be run on an actual Windows host. The API can be smoke-tested with `curl http://127.0.0.1:8080/api/health` and `/api/summary`.
