# Smart Traffic Intelligence & Vehicle Tracking System (Phase 1, 2 & 3 Backend)

A high-performance, modular, native Windows C++17 backend for vehicle traffic simulation, 2D road network kinematics, deterministic GPS sensor error modeling, 2D Constant-Velocity (CV) Kalman Filter state estimation, and macroscopic Traffic Intelligence & Alert Analytics.

---

## 1. Project Architecture & Overview

### Phase 1: Physical Traffic Simulation Foundation
- **Physical Coordinates & Units**: Cartesian coordinates in **meters ($m$)**, velocities in **meters per second ($m/s$)**, time in **seconds ($s$)**, and accelerations in **$m/s^2$**. Internal calculations are strictly SI.
- **Fixed Simulation Tick**: Vehicle kinematics, lane boundary checks, and car-following headway preservation execute at **100 ms ($dt = 0.1$ s, 10 Hz)**.
- **Configurable GPS Sampling**: GPS measurements are acquired at a separate configurable interval (**1.0 second, 1 Hz**) with deterministic 2D Gaussian sensor noise $\mathcal{N}(0, \sigma^2)$ derived from a fixed pseudo-random seed.
- **2D Road Network Topology**: Four corridors (North, South, East, West) converging at a central intersection with straight-through and turning routes.
- **Vehicle Fleet**: Manages 30 distinct vehicles across a 60-second operational simulation window with monotonic ID assignment.
- **Telemetry Export**: Produces high-fidelity CSV records (`data/traffic_simulation.csv`).

### Phase 2: Kalman Filter & Multi-Vehicle Tracking Engine
- **State Vector**: 4D state vector $\mathbf{x} = [x, y, v_x, v_y]^T$ tracking 2D Cartesian position ($m$) and velocity ($m/s$).
- **State Transition Matrix**:
  $$F(\Delta t) = \begin{bmatrix} 1 & 0 & \Delta t & 0 \\ 0 & 1 & 0 & \Delta t \\ 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 1 \end{bmatrix}$$
- **Process Noise Matrix $Q(\Delta t)$**: Continuous white-noise acceleration model with spectral density $q = \sigma_a^2$:
  $$Q(\Delta t) = \begin{bmatrix}
  \frac{\Delta t^3}{3} \sigma_a^2 & 0 & \frac{\Delta t^2}{2} \sigma_a^2 & 0 \\
  0 & \frac{\Delta t^3}{3} \sigma_a^2 & 0 & \frac{\Delta t^2}{2} \sigma_a^2 \\
  \frac{\Delta t^2}{2} \sigma_a^2 & 0 & \Delta t \sigma_a^2 & 0 \\
  0 & \frac{\Delta t^2}{2} \sigma_a^2 & 0 & \Delta t \sigma_a^2
  \end{bmatrix}$$
- **Measurement Model**:
  $$H = \begin{bmatrix} 1 & 0 & 0 & 0 \\ 0 & 1 & 0 & 0 \end{bmatrix}, \quad R = \begin{bmatrix} \sigma_{\text{gps}}^2 & 0 \\ 0 & \sigma_{\text{gps}}^2 \end{bmatrix}$$
- **Joseph Form Covariance Update**:
  $$P_{k|k} = (I - K_k H) P_{k|k-1} (I - K_k H)^T + K_k R K_k^T$$
  Guarantees numerical symmetry and positive semi-definiteness ($P = 0.5(P + P^T)$) across thousands of iterations.
- **TrackingManager**: Maintains independent, isolated Kalman filters per vehicle ID.
- **Initialization**: Initialized strictly from the first observed GPS reading ($[z_x, z_y, 0, 0]^T$ with velocity covariance $\sigma_{v}^2 = 100$). Never uses hidden ground truth.
- **Dual-Clock Operation**:
  - Predicts at every **100 ms simulation tick** ($\Delta t = 0.1\text{ s}$).
  - Corrects only when fresh GPS measurements arrive (**1.0 s interval**).
- **Tracking Telemetry**: Generates `data/kalman_tracking.csv` containing ground truth, noisy GPS, Kalman state estimates, and an explicit `gps_fresh` flag.

### Phase 3: Traffic Intelligence & Alert Analytics Engine
- **Separation of Concerns**: Authoritative ground-truth vehicle states are analyzed independently from GPS/Kalman tracking states. Analytics performs read-only inspection, guaranteeing zero interference with simulation determinism or tracking accuracy.
- **Macroscopic & Lane Metrics (`TrafficAnalyzer`)**:
  - Active vehicle counts system-wide, per road corridor, and per lane.
  - Average speeds in SI units ($m/s$) with reporting conversion to $km/h$.
  - Road occupancy ratio ($\text{total vehicle length} / \text{road length}$, clamped to $[0.0, 1.0]$).
  - Traffic density ($\text{vehicles} / \text{km}$).
  - Stationary/stopped vehicle tracking (speed $< 0.5\text{ m/s}$).
  - Completed vehicle journey counts.
- **Heuristic Congestion Classification**:
  - `LOW`: Free-flow traffic (occupancy $< 25\%$ or empty road).
  - `MODERATE`: Occupancy in $[25\%, 50\%)$ or speeds below $60\%$ of limit.
  - `HIGH`: Occupancy $\ge 50\%$, crawling speed ($\le 30\%$ of limit), or $\ge 60\%$ stopped vehicles.
- **Traffic Alert & Incident Engine (`AlertManager`)**:
  - **Speed Violations**: Detects vehicles exceeding lane speed limits ($+0.5\text{ m/s}$ tolerance) with severity grading (`LOW`, `MEDIUM`, `HIGH`).
  - **Abnormally Stopped Vehicles**: Detects vehicles stationary for $\ge 3.0\text{ seconds}$ on active travel lanes.
  - **Heavy Congestion**: Triggers corridor-level alerts when congestion reaches `HIGH`.
  - **Deduplication & Resolution**: Maintains persistent active alert states during continuous conditions, preventing duplicate event IDs per tick. Automatically transitions events to `RESOLVED` when conditions clear or vehicles depart.
- **Telemetry Export**: Produces `data/traffic_analytics.csv` (macroscopic snapshots) and `data/traffic_alerts.csv` (incident event logs). Both safely support headless execution when paths are empty.

---

## 2. Directory Structure

```
SmartTraffic/
├── CMakeLists.txt                      # Root CMake build configuration (MSVC & GCC)
├── README.md                           # Comprehensive documentation and instructions
├── .gitignore                          # Git ignore rules for build, binaries, data, logs
├── build.ps1                           # Automated PowerShell build script
├── run_benchmark.ps1                   # 9-grid accuracy benchmark runner (60s simulation)
├── run_20s.ps1                         # 9-grid accuracy benchmark runner (20s test suite)
├── verify_csv.ps1                      # Strict 4-CSV schema and NaN/Inf validator
├── config/
│   └── simulation_config.json          # Default simulation parameters
├── data/                               # CSV output directory
│   ├── traffic_simulation.csv          # Phase 1: Raw GPS sensor records
│   ├── kalman_tracking.csv             # Phase 2: Kalman Filter tracking telemetry
│   ├── traffic_analytics.csv           # Phase 3: Macroscopic traffic intelligence snapshots
│   └── traffic_alerts.csv              # Phase 3: Incident and alert event lifecycle logs
├── logs/                               # Execution logs directory
│   └── simulation.log
├── workers/                            # Reserved for Phase 4+ worker pools
│   └── README.md
├── third_party/
│   └── eigen3/                         # Official Eigen 3.4.0 library headers
│       └── Eigen/
│           ├── Dense                   # Dense linear algebra module
│           ├── Core                    # Core matrix and array classes
│           └── ...
├── include/
│   └── smart_traffic/
│       ├── core/
│       │   ├── types.h                 # Direction, VehicleState, physical constants
│       │   ├── position.h              # 2D coordinates (meters), lerp, Euclidean distance
│       │   ├── velocity.h              # 2D velocity vector (m/s), speed, heading
│       │   └── vehicle.h               # Vehicle model, bounds clamping, kinematics
│       ├── config/
│       │   └── simulation_config.h     # Configuration schema, validator, JSON loader
│       ├── road/
│       │   ├── lane.h                  # Directed 2D lane path, heading, length
│       │   ├── intersection.h          # Multi-corridor junction model
│       │   └── road_network.h          # 4-way topology builder and routing
│       ├── simulation/
│       │   ├── vehicle_manager.h       # Monotonic ID allocation and vehicle lifecycle
│       │   ├── gps_simulator.h         # Seeded Gaussian sensor noise generator
│       │   └── traffic_simulator.h     # Dual-clock tick scheduler and physics engine
│       ├── tracking/
│       │   ├── kalman_filter_2d.h      # 2D Constant-Velocity Kalman Filter (Joseph form)
│       │   └── tracking_manager.h      # Multi-vehicle tracker and metrics calculator
│       ├── analytics/
│       │   ├── traffic_event.h         # Congestion, Alert, and Severity types and structs
│       │   ├── traffic_analyzer.h      # Macroscopic density, occupancy, and speed analyzer
│       │   └── alert_manager.h         # Incident lifecycle, deduplication, and resolution
│       └── utils/
│           ├── csv_exporter.h          # Safe CSV streaming with empty-path toggle
│           └── logger.h                # Leveled file and console logger
├── src/
│   ├── core/
│   │   ├── position.cpp
│   │   ├── velocity.cpp
│   │   └── vehicle.cpp
│   ├── config/
│   │   └── simulation_config.cpp
│   ├── road/
│   │   ├── lane.cpp
│   │   ├── intersection.cpp
│   │   └── road_network.cpp
│   ├── simulation/
│   │   ├── vehicle_manager.cpp
│   │   ├── gps_simulator.cpp
│   │   └── traffic_simulator.cpp
│   ├── tracking/
│   │   ├── kalman_filter_2d.cpp
│   │   └── tracking_manager.cpp
│   ├── analytics/
│   │   ├── traffic_analyzer.cpp
│   │   └── alert_manager.cpp
│   ├── utils/
│   │   ├── csv_exporter.cpp
│   │   └── logger.cpp
│   └── main.cpp                        # Entry point and comprehensive summary reporter
└── tests/
    ├── test_framework.h                # Self-contained C++17 unit test runner
    ├── test_main.cpp                   # Test suite driver entry point
    ├── test_simulation_determinism.cpp # Deterministic seed and sampling tests (3 tests)
    ├── test_vehicle_count.cpp          # Lifecycle and 30-vehicle count tests (3 tests)
    ├── test_movement_constraints.cpp   # Kinematic clamps and headway preservation (3 tests)
    ├── test_kalman_filter.cpp          # Stationary, CV, noise reduction, Joseph stability (6 tests)
    ├── test_tracking_integration.cpp   # End-to-end integration and edge-case tests (7 tests)
    └── test_traffic_analytics.cpp      # Phase 3 Analytics, Alerts, and Congestion tests (12 tests)
```

---

## 3. Data Pipeline Architecture

```
SimulationConfig (JSON / Defaults)
       │
       ▼
  RoadNetwork ──► Lanes, Intersections, Directions
       │
       ▼
VehicleManager ──► Monotonic IDs, Spawn, Kinematics Clamps, Headway Clamps
       │
       ▼
TrafficSimulator ──► Fixed 100ms Simulation Ticks
       │
       ├─────────────────────────────────────────┐
       │                                         │
       ▼                                         ▼
[Authoritative Ground Truth]              [Sensor Domain]
       │                                         │
       ▼                                         ▼
TrafficAnalyzer & AlertManager             GPSSimulator (1.0s Seeded Noise)
       │                                         │
       ├──► Road & Network Density/Occupancy     ▼
       ├──► Heuristic Congestion (LOW/MOD/HIGH)  TrackingManager (Independent KF per ID)
       ├──► Speed Violations & Severity          │
       ├──► Stopped Vehicles & Incidents         ├──► 100ms Prediction Step
       └──► Deduplicated & Resolved Alerts       └──► 1.0s Joseph Form Correction Step
       │                                         │
       ▼                                         ▼
[traffic_analytics.csv, traffic_alerts.csv]    [traffic_simulation.csv, kalman_tracking.csv]
       │                                         │
       └────────────────────┬────────────────────┘
                            │
                            ▼
                     Console Summary Reporter
```

---

## 4. Build Instructions

### Option A: Microsoft Visual C++ (MSVC / Visual Studio 2019 / 2022)
Open **Developer PowerShell for VS 2022** or **x64 Native Tools Command Prompt for VS 2022**:

```powershell
# 1. Navigate to project root
cd C:\Users\Talal\Desktop\SmartTraffic

# 2. Generate Visual Studio 2022 solution
cmake -B build -S . -G "Visual Studio 17 2022" -A x64

# 3. Build Release binaries
cmake --build build --config Release
```

Generated binaries will be located in `build\Release\`:
- `build\Release\SmartTraffic.exe`
- `build\Release\SmartTrafficTests.exe`

### Option B: Native Windows GCC / TDM-GCC
Run the provided automated PowerShell build script:

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

---

## 5. Execution Instructions

### Running the Full 30-Vehicle, 60-Second Simulation
```powershell
.\build\SmartTraffic.exe config\simulation_config.json
```

### Running the Test Suite (34 Unit & Integration Tests)
```powershell
.\build\SmartTrafficTests.exe
```

### Running the 9-Grid Accuracy Benchmark (60s Simulation)
```powershell
powershell -ExecutionPolicy Bypass -File .\run_benchmark.ps1
```

### Validating Telemetry CSV Files (4 Files Validated)
```powershell
powershell -ExecutionPolicy Bypass -File .\verify_csv.ps1
```

---

## 6. Real Measured Benchmark Metrics

### A. Full 60-Second Simulation Grid (30 Vehicles, 600 Ticks)
| Random Seed | GPS Noise $\sigma$ | Raw GPS RMSE | Kalman RMSE (GPS Ticks) | Kalman RMSE (All Ticks) | Error Reduction (%) | Samples Evaluated |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| `42`   | $1.5\text{ m}$ | $2.1438\text{ m}$ | $2.0407\text{ m}$ | $3.2434\text{ m}$ | **$4.81\%$**  | 744 |
| `42`   | $2.5\text{ m}$ | $3.5730\text{ m}$ | $3.3092\text{ m}$ | $4.6724\text{ m}$ | **$7.38\%$**  | 744 |
| `42`   | $4.0\text{ m}$ | $5.7168\text{ m}$ | $5.1159\text{ m}$ | $6.6919\text{ m}$ | **$10.51\%$** | 744 |
| `1001` | $1.5\text{ m}$ | $2.1006\text{ m}$ | $2.0534\text{ m}$ | $3.2529\text{ m}$ | **$2.25\%$**  | 744 |
| `1001` | $2.5\text{ m}$ | $3.5010\text{ m}$ | $3.3402\text{ m}$ | $4.6938\text{ m}$ | **$4.59\%$**  | 744 |
| `1001` | $4.0\text{ m}$ | $5.6016\text{ m}$ | $5.1575\text{ m}$ | $6.7123\text{ m}$ | **$7.93\%$**  | 744 |
| `7777` | $1.5\text{ m}$ | $2.1884\text{ m}$ | $2.1109\text{ m}$ | $3.3200\text{ m}$ | **$3.54\%$**  | 744 |
| `7777` | $2.5\text{ m}$ | $3.6473\text{ m}$ | $3.4247\text{ m}$ | $4.8042\text{ m}$ | **$6.10\%$**  | 744 |
| `7777` | $4.0\text{ m}$ | $5.8357\text{ m}$ | $5.2821\text{ m}$ | $6.8863\text{ m}$ | **$9.49\%$**  | 744 |

### B. Short 20-Second Test Suite Grid (10 Vehicles, 200 Ticks)
| Random Seed | GPS Noise $\sigma$ | Raw GPS RMSE | Kalman RMSE (GPS Ticks) | Kalman RMSE (All Ticks) | Error Reduction (%) | Samples Evaluated |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| `42`   | $1.5\text{ m}$ | $2.2010\text{ m}$ | $2.1639\text{ m}$ | $3.3804\text{ m}$ | **$1.69\%$**  | 130 |
| `42`   | $2.5\text{ m}$ | $3.6683\text{ m}$ | $3.5222\text{ m}$ | $4.8649\text{ m}$ | **$3.98\%$**  | 130 |
| `42`   | $4.0\text{ m}$ | $5.8693\text{ m}$ | $5.4236\text{ m}$ | $6.9785\text{ m}$ | **$7.59\%$**  | 130 |
| `1001` | $1.5\text{ m}$ | $2.0556\text{ m}$ | $2.0213\text{ m}$ | $3.4204\text{ m}$ | **$1.67\%$**  | 130 |
| `1001` | $2.5\text{ m}$ | $3.4260\text{ m}$ | $3.2403\text{ m}$ | $4.7559\text{ m}$ | **$5.42\%$**  | 130 |
| `1001` | $4.0\text{ m}$ | $5.4815\text{ m}$ | $4.9361\text{ m}$ | $6.6221\text{ m}$ | **$9.95\%$**  | 130 |
| `7777` | $1.5\text{ m}$ | $2.0786\text{ m}$ | $2.0542\text{ m}$ | $3.4104\text{ m}$ | **$1.18\%$**  | 130 |
| `7777` | $2.5\text{ m}$ | $3.4644\text{ m}$ | $3.3064\text{ m}$ | $4.7877\text{ m}$ | **$4.56\%$**  | 130 |
| `7777` | $4.0\text{ m}$ | $5.5430\text{ m}$ | $5.0589\text{ m}$ | $6.7340\text{ m}$ | **$8.73\%$**  | 130 |
- **Aggregate Across 9 Test Scenarios**: Mean GPS RMSE: $3.75\text{ m}$, Mean Kalman RMSE: $3.53\text{ m}$, Net Noise Reduction: **$+6.10\%$**.

---

## 7. Automated Test Suite (34 Passed Tests)

All 34 unit, integration, analytics, and edge-case tests pass:

```
=======================================================
             SMART TRAFFIC TEST SUITE                  
=======================================================
[ RUN      ] TrafficAnalyticsTests.EmptyRoadsAndZeroDensity...
[       OK ] TrafficAnalyticsTests.EmptyRoadsAndZeroDensity
[ RUN      ] TrafficAnalyticsTests.SingleVehicleMetrics...
[       OK ] TrafficAnalyticsTests.SingleVehicleMetrics
[ RUN      ] TrafficAnalyticsTests.MultipleVehiclesAndLaneDistribution...
[       OK ] TrafficAnalyticsTests.MultipleVehiclesAndLaneDistribution
[ RUN      ] TrafficAnalyticsTests.CongestionLevelTransitions...
[       OK ] TrafficAnalyticsTests.CongestionLevelTransitions
[ RUN      ] TrafficAnalyticsTests.SpeedLimitViolationsDetection...
[       OK ] TrafficAnalyticsTests.SpeedLimitViolationsDetection
[ RUN      ] TrafficAnalyticsTests.SpeedViolationDeduplication...
[       OK ] TrafficAnalyticsTests.SpeedViolationDeduplication
[ RUN      ] TrafficAnalyticsTests.StoppedVehicleDetection...
[       OK ] TrafficAnalyticsTests.StoppedVehicleDetection
[ RUN      ] TrafficAnalyticsTests.EventResolutionLifecycle...
[       OK ] TrafficAnalyticsTests.EventResolutionLifecycle
[ RUN      ] TrafficAnalyticsTests.HeavyCongestionAlertLifecycle...
[       OK ] TrafficAnalyticsTests.HeavyCongestionAlertLifecycle
[ RUN      ] TrafficAnalyticsTests.CsvFormattingAndDisabling...
[       OK ] TrafficAnalyticsTests.CsvFormattingAndDisabling
[ RUN      ] TrafficAnalyticsTests.AnalyticsIntegrationDeterministicSimulation...
[       OK ] TrafficAnalyticsTests.AnalyticsIntegrationDeterministicSimulation
[ RUN      ] TrafficAnalyticsTests.InvalidInputAndEdgeCaseHandling...
[       OK ] TrafficAnalyticsTests.InvalidInputAndEdgeCaseHandling
[ RUN      ] TrackingIntegrationTests.FullTrafficSimulationTrackingIntegration...
[       OK ] TrackingIntegrationTests.FullTrafficSimulationTrackingIntegration
[ RUN      ] TrackingIntegrationTests.TrackingCsvFormatAndFreshnessFlagValidation...
[       OK ] TrackingIntegrationTests.TrackingCsvFormatAndFreshnessFlagValidation
[ RUN      ] TrackingIntegrationTests.TrackingMetricsAccurateWithCsvExportDisabled...
[       OK ] TrackingIntegrationTests.TrackingMetricsAccurateWithCsvExportDisabled
[ RUN      ] TrackingIntegrationTests.MultiSeedAndNoiseAccuracyValidation...
[       OK ] TrackingIntegrationTests.MultiSeedAndNoiseAccuracyValidation
[ RUN      ] TrackingIntegrationTests.EdgeCaseSingleVehicleAndLargeFleet...
[       OK ] TrackingIntegrationTests.EdgeCaseSingleVehicleAndLargeFleet
[ RUN      ] TrackingIntegrationTests.EdgeCaseZeroAndHighGpsNoise...
[       OK ] TrackingIntegrationTests.EdgeCaseZeroAndHighGpsNoise
[ RUN      ] TrackingIntegrationTests.EdgeCaseConfigValidationAndFallback...
[       OK ] TrackingIntegrationTests.EdgeCaseConfigValidationAndFallback
[ RUN      ] KalmanFilterTests.StationaryMotionConvergence...
[       OK ] KalmanFilterTests.StationaryMotionConvergence
[ RUN      ] KalmanFilterTests.ConstantVelocityEstimation...
[       OK ] KalmanFilterTests.ConstantVelocityEstimation
[ RUN      ] KalmanFilterTests.NoisyGpsNoiseReduction...
[       OK ] KalmanFilterTests.NoisyGpsNoiseReduction
[ RUN      ] KalmanFilterTests.MissingMeasurementsDeadReckoning...
[       OK ] KalmanFilterTests.MissingMeasurementsDeadReckoning
[ RUN      ] KalmanFilterTests.CovarianceNumericalStabilityJosephForm...
[       OK ] KalmanFilterTests.CovarianceNumericalStabilityJosephForm
[ RUN      ] KalmanFilterTests.IndependentVehicleTrackingNoCrossTalk...
[       OK ] KalmanFilterTests.IndependentVehicleTrackingNoCrossTalk
[ RUN      ] MovementConstraintTests.KinematicsRespectSpeedAndAccelerationLimits...
[       OK ] MovementConstraintTests.KinematicsRespectSpeedAndAccelerationLimits
[ RUN      ] MovementConstraintTests.LaneSpatialMappingAndDirection...
[       OK ] MovementConstraintTests.LaneSpatialMappingAndDirection
[ RUN      ] MovementConstraintTests.CarFollowingHeadwayPreservedInSimulation...
[       OK ] MovementConstraintTests.CarFollowingHeadwayPreservedInSimulation
[ RUN      ] VehicleCountTests.UniqueAndMonotonicVehicleIds...
[       OK ] VehicleCountTests.UniqueAndMonotonicVehicleIds
[ RUN      ] VehicleCountTests.VehicleLifecycleManagement...
[       OK ] VehicleCountTests.VehicleLifecycleManagement
[ RUN      ] VehicleCountTests.ConfiguredVehicleCountSpawning...
[       OK ] VehicleCountTests.ConfiguredVehicleCountSpawning
[ RUN      ] DeterminismTests.IdenticalSeedYieldsIdenticalSimulationTrajectory...
[       OK ] DeterminismTests.IdenticalSeedYieldsIdenticalSimulationTrajectory
[ RUN      ] DeterminismTests.DifferentSeedsYieldDivergentGpsNoise...
[       OK ] DeterminismTests.DifferentSeedsYieldDivergentGpsNoise
[ RUN      ] DeterminismTests.GpsSamplingIntervalStrictlyRespected...
[       OK ] DeterminismTests.GpsSamplingIntervalStrictlyRespected
-------------------------------------------------------
Test Results: 34 passed, 0 failed, 34 total.
=======================================================
```

---

## 8. CSV Telemetry Format Specifications

### 1. Raw GPS Telemetry: `data/traffic_simulation.csv`
Header (6 fields):
```csv
timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y
```
Exported only during GPS sampling epochs (1 Hz).

### 2. Kalman Tracking Telemetry: `data/kalman_tracking.csv`
Header (11 fields):
```csv
timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y,estimated_x,estimated_y,gps_error,kalman_error,gps_fresh
```
Every row has exactly **11 fields** separated by **10 commas**. `gps_fresh = 1` on 1 Hz GPS arrivals; `gps_fresh = 0` on 100 ms kinematic dead-reckoning prediction ticks.

### 3. Traffic Analytics Snapshots: `data/traffic_analytics.csv`
Header (9 fields):
```csv
timestamp,total_active_vehicles,completed_journeys,stopped_vehicles,avg_network_speed_mps,avg_network_speed_kmh,avg_occupancy,avg_density_veh_per_km,network_congestion
```
Records system-wide macroscopic occupancy, density, average network speed, and heuristic congestion classification at every 100 ms tick.

### 4. Traffic Alerts & Incidents: `data/traffic_alerts.csv`
Header (11 fields):
```csv
event_id,timestamp,resolved_timestamp,alert_type,status,vehicle_id,road_id,actual_speed,speed_limit,severity,message
```
Captures lifecycle transitions (`ACTIVE` on creation, `RESOLVED` on clearing) for speed violations, stopped vehicles, and heavy corridor congestion.

---

## 9. Known System Limitations

1. **Heuristic Congestion Classification**: The congestion detection levels (`LOW`, `MODERATE`, `HIGH`) are rule-based operational heuristics derived from spatial occupancy and velocity ratios; they are not calibrated macroscopic traffic models (e.g. Lighthill-Whitham-Richards).
2. **Constant-Velocity Motion Model**: Tracking uses a 2D Constant Velocity (CV) model with continuous white-noise acceleration. During sharp 90-degree intersection turns, turning lag is expected.
3. **Single Process Architecture**: Phase 1, Phase 2, and Phase 3 are implemented as a single-process C++17 engine. Multi-process Windows worker pools, IPC pipes, Crow REST endpoints, and SQLite storage are reserved for Phase 4+.

---

## Phase 4 — Native Windows operating-system integration

Phase 4 includes Win32 file I/O, virtual memory and process memory inspection,
worker-process management, shared-memory IPC, and sequential vs 2-/4-worker
Kalman tracking benchmarks. The worker executable is `kalman_worker.exe`.

### Windows build and verification (requires MSVC + Windows SDK)

Open an **x64 Native Tools Command Prompt for Visual Studio** and run:

```powershell
.\build.ps1
.\build-msvc\SmartTraffic.exe --benchmark
```

Or build using CMake directly:

```powershell
cmake -S . -B build-msvc -G "NMake Makefiles" -DCMAKE_BUILD_TYPE=Release
cmake --build build-msvc --config Release
ctest --test-dir build-msvc -C Release --output-on-failure
```

`SmartTrafficTests` depends on `kalman_worker`, and tests use the executable
path supplied by CMake. A missing worker executable is a test failure.

### Benchmark validity and limitations

- Each configuration requires **all configured trials to succeed**. If a trial
  fails, the configuration is marked unsuccessful rather than reporting a
  misleading median based on partial trials.
- Sequential and parallel final estimates are compared by vehicle ID,
  including position and velocity; duplicate or missing vehicle IDs invalidate
  the comparison. The benchmark CSV uses `-1` as an explicit invalid-comparison
  sentinel, never `0` for missing results.
- CPU and memory metrics are derived from Windows process APIs, not estimated
  percentages. Reported memory values are sampled and may not represent the
  maximum across every worker's lifetime.
- Small workloads can run **slower** in parallel because of worker startup,
  IPC and synchronization overhead. Do not assume speedup.
- This source tree can compile and test Phases 1–3 on non-Windows platforms;
  Phase 4 code and tests are built **only on Windows**.

### Independent verification status

The portable backend was compiled using Linux GCC and passed **34/34** tests,
with CTest **1/1** and a successful default 60-second simulation. **Native
Windows MSVC compilation, worker execution, and the 10 Phase 4 tests have not
been independently executed in this environment.** Run the commands above on
Windows before signing off Phase 4.
