# SmartTraffic Phase 6 — Command Center

## Windows quick start

Open PowerShell in this project folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_dashboard.ps1
```

**Requirements:** CMake and a C++17 toolchain with SQLite3 development library (and Eigen is bundled). MSVC with the SQLite3 dependency or an appropriately configured MinGW toolchain can be used. No Python or Node.js is needed for the UI. Open http://127.0.0.1:8080.

The PowerShell script builds, tests, runs the simulator, imports CSV files and starts the integrated C++ web server. Keep the terminal open while using the dashboard. Ctrl+C stops the server.

## Linux quick start

`bash run_dashboard.sh` (requires CMake, C++17 compiler, SQLite3 development files).

## Dashboard pages

- Overview — counts, network map, recent events, trend chart
- Live Network — latest *recorded* vehicle positions; **not real-time tracking**
- Vehicle Fleet — latest Kalman estimates and search
- Analytics — historical traffic trends and records
- Alerts & Events — alert history and search
- System Health — database totals and available Windows benchmark/OS metrics

The frontend is vanilla HTML/CSS/JS, served by `SmartTrafficApi` itself. It uses `/api/*` endpoints and refreshes stored records every 30 seconds. It does **not** stream simulation events, use geographical map tiles or claim real-time road GPS. The network map uses simulated Cartesian coordinates. For Windows Phase 4 tests, a native Windows runner is still required.

### API server directly

`SmartTrafficApi --db data/smarttraffic.db --data data --import --web web --port 8080`

Security: the server binds only to 127.0.0.1, without authentication. Do not expose it publicly.
