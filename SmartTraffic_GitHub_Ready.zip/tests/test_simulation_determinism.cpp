#include "test_framework.h"
#include "smart_traffic/simulation/traffic_simulator.h"
#include "smart_traffic/config/simulation_config.h"
#include <vector>
#include <cmath>

using namespace SmartTraffic;

TEST_CASE(DeterminismTests, IdenticalSeedYieldsIdenticalSimulationTrajectory) {
    SimulationConfig config1 = SimulationConfig::createDefault();
    config1.total_simulation_time = 15.0; // 150 ticks
    config1.vehicle_count = 10;
    config1.random_seed = 12345;
    config1.gps_sampling_interval_seconds = 1.0;
    config1.enable_console_progress = false;
    config1.output_csv_path = "data/test_det_run1.csv";
    config1.tracking_csv_path = "";
    config1.analytics_csv_path = "";
    config1.alerts_csv_path = "";

    SimulationConfig config2 = config1;
    config2.output_csv_path = "data/test_det_run2.csv";

    TrafficSimulator sim1(config1);
    TrafficSimulator sim2(config2);

    sim1.initialize();
    sim2.initialize();

    // Run both simulations step by step and compare state at every tick
    const size_t test_ticks = 150;
    size_t gps_sample_ticks_count = 0;

    for (size_t t = 0; t < test_ticks; ++t) {
        sim1.step();
        sim2.step();

        ASSERT_EQ(sim1.getTickCount(), sim2.getTickCount());
        ASSERT_NEAR(sim1.getCurrentTime(), sim2.getCurrentTime(), 1e-9);
        ASSERT_EQ(sim1.wasLatestTickGpsSampled(), sim2.wasLatestTickGpsSampled());

        if (sim1.wasLatestTickGpsSampled()) {
            gps_sample_ticks_count++;
            const auto& m1 = sim1.getLatestMeasurements();
            const auto& m2 = sim2.getLatestMeasurements();

            ASSERT_EQ(m1.size(), m2.size());

            for (size_t i = 0; i < m1.size(); ++i) {
                ASSERT_EQ(m1[i].vehicle_id, m2[i].vehicle_id);
                ASSERT_NEAR(m1[i].actual_x, m2[i].actual_x, 1e-9);
                ASSERT_NEAR(m1[i].actual_y, m2[i].actual_y, 1e-9);
                ASSERT_NEAR(m1[i].gps_x, m2[i].gps_x, 1e-9);
                ASSERT_NEAR(m1[i].gps_y, m2[i].gps_y, 1e-9);
                ASSERT_NEAR(m1[i].error_distance, m2[i].error_distance, 1e-9);
            }
        } else {
            ASSERT_TRUE(sim1.getLatestMeasurements().empty());
            ASSERT_TRUE(sim2.getLatestMeasurements().empty());
        }
    }

    // Over 15 seconds with 1-second GPS sampling interval, we expect exactly 15 GPS sampling events (t=0.0, 1.0 ... 14.0)
    ASSERT_EQ(gps_sample_ticks_count, 15U);
}

TEST_CASE(DeterminismTests, DifferentSeedsYieldDivergentGpsNoise) {
    SimulationConfig config1 = SimulationConfig::createDefault();
    config1.total_simulation_time = 10.0;
    config1.vehicle_count = 5;
    config1.random_seed = 1001;
    config1.gps_sampling_interval_seconds = 1.0;
    config1.enable_console_progress = false;
    config1.output_csv_path = "data/test_seed1.csv";
    config1.tracking_csv_path = "";
    config1.analytics_csv_path = "";
    config1.alerts_csv_path = "";

    SimulationConfig config2 = config1;
    config2.random_seed = 9999;
    config2.output_csv_path = "data/test_seed2.csv";

    TrafficSimulator sim1(config1);
    TrafficSimulator sim2(config2);

    sim1.initialize();
    sim2.initialize();

    bool found_divergent_sample = false;

    for (size_t t = 0; t < 50; ++t) {
        sim1.step();
        sim2.step();

        if (sim1.wasLatestTickGpsSampled()) {
            const auto& m1 = sim1.getLatestMeasurements();
            const auto& m2 = sim2.getLatestMeasurements();

            if (!m1.empty() && !m2.empty()) {
                ASSERT_EQ(m1.size(), m2.size());

                // Ground truth positions must match because traffic kinematics is deterministic
                ASSERT_NEAR(m1[0].actual_x, m2[0].actual_x, 1e-6);
                ASSERT_NEAR(m1[0].actual_y, m2[0].actual_y, 1e-6);

                // But simulated GPS measurements with different seeds must diverge
                const double diff_x = std::abs(m1[0].gps_x - m2[0].gps_x);
                const double diff_y = std::abs(m1[0].gps_y - m2[0].gps_y);
                if (diff_x > 1e-3 || diff_y > 1e-3) {
                    found_divergent_sample = true;
                }
            }
        }
    }

    ASSERT_TRUE(found_divergent_sample);
}

TEST_CASE(DeterminismTests, GpsSamplingIntervalStrictlyRespected) {
    SimulationConfig config = SimulationConfig::createDefault();
    config.total_simulation_time = 6.0;
    config.tick_duration_seconds = 0.1; // 100 ms ticks
    config.gps_sampling_interval_seconds = 1.0; // 1 second GPS interval
    config.vehicle_count = 5;
    config.enable_console_progress = false;
    config.output_csv_path = "data/test_interval.csv";
    config.tracking_csv_path = "";
    config.analytics_csv_path = "";
    config.alerts_csv_path = "";

    TrafficSimulator sim(config);
    sim.initialize();

    std::vector<double> sample_timestamps;

    for (size_t t = 0; t < 60; ++t) {
        sim.step();
        if (sim.wasLatestTickGpsSampled()) {
            // Timestamp of the tick that was sampled
            sample_timestamps.push_back(sim.getCurrentTime() - 0.1);
        }
    }

    // Expected samples at t = 0.0, 1.0, 2.0, 3.0, 4.0, 5.0 (6 samples)
    ASSERT_EQ(sample_timestamps.size(), 6U);
    for (size_t i = 0; i < sample_timestamps.size(); ++i) {
        ASSERT_NEAR(sample_timestamps[i], static_cast<double>(i), 1e-6);
    }
}
