#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <functional>
#include <cmath>
#include <sstream>
#include <type_traits>
#include <utility>

#include <filesystem>

namespace SmartTraffic::Test {

struct TestCase {
    std::string name;
    std::string suite;
    std::function<void()> func;
};

class TestRegistry {
public:
    static TestRegistry& instance() {
        static TestRegistry reg;
        return reg;
    }

    void registerTest(const std::string& suite, const std::string& name, std::function<void()> func) {
        tests_.push_back({name, suite, func});
    }

    int runAll() {
        int passed = 0;
        int failed = 0;

        std::cout << "=======================================================\n";
        std::cout << "             SMART TRAFFIC TEST SUITE                  \n";
        std::cout << "=======================================================\n";

        for (const auto& test : tests_) {
            std::cout << "[ RUN      ] " << test.suite << "." << test.name << "..." << std::endl;
            try {
                std::error_code ec_b;
                auto sz_before = std::filesystem::file_size("data/traffic_simulation.csv", ec_b);

                test.func();

                std::error_code ec_a;
                auto sz_after = std::filesystem::file_size("data/traffic_simulation.csv", ec_a);
                if (sz_before > 100 && sz_after <= 100) {
                    std::cout << "[ EXACT TRUNCATION IN ] " << test.suite << "." << test.name 
                              << " before=" << sz_before << " after=" << sz_after << std::endl;
                }
                std::cout << "[       OK ] " << test.suite << "." << test.name << std::endl;
                passed++;
            } catch (const std::exception& e) {
                std::cout << "[  FAILED  ] " << test.suite << "." << test.name << "\n";
                std::cout << "             Error: " << e.what() << std::endl;
                failed++;
            } catch (...) {
                std::cout << "[  FAILED  ] " << test.suite << "." << test.name << "\n";
                std::cout << "             Error: Unknown exception caught!" << std::endl;
                failed++;
            }
        }

        std::cout << "-------------------------------------------------------\n";
        std::cout << "Test Results: " << passed << " passed, " << failed << " failed, " 
                  << tests_.size() << " total." << std::endl;
        std::cout << "=======================================================\n";

        return (failed == 0) ? 0 : 1;
    }

private:
    std::vector<TestCase> tests_;
};

struct TestRegistrar {
    TestRegistrar(const std::string& suite, const std::string& name, std::function<void()> func) {
        TestRegistry::instance().registerTest(suite, name, func);
    }
};

namespace Detail {
    template <typename T, typename = void>
    struct is_streamable : std::false_type {};

    template <typename T>
    struct is_streamable<T, std::void_t<decltype(std::declval<std::ostream&>() << std::declval<const T&>())>> : std::true_type {};

    template <typename T>
    inline std::string formatValue(const T& val) {
        if constexpr (is_streamable<T>::value) {
            std::ostringstream ss;
            ss << val;
            return ss.str();
        } else if constexpr (std::is_enum_v<T>) {
            return std::to_string(static_cast<std::underlying_type_t<T>>(val));
        } else {
            return "<unprintable>";
        }
    }
} // namespace Detail

} // namespace SmartTraffic::Test

#define TEST_CASE(suite_name, test_name) \
    static void suite_name##_##test_name(); \
    static ::SmartTraffic::Test::TestRegistrar registrar_##suite_name##_##test_name( \
        #suite_name, #test_name, suite_name##_##test_name); \
    static void suite_name##_##test_name()

#define ASSERT_TRUE(condition) \
    do { \
        if (!(condition)) { \
            std::ostringstream ss; \
            ss << "Assertion failed: (" #condition ") at " << __FILE__ << ":" << __LINE__; \
            throw std::runtime_error(ss.str()); \
        } \
    } while (0)

#define ASSERT_FALSE(condition) \
    do { \
        if (condition) { \
            std::ostringstream ss; \
            ss << "Assertion failed: NOT (" #condition ") at " << __FILE__ << ":" << __LINE__; \
            throw std::runtime_error(ss.str()); \
        } \
    } while (0)

#define ASSERT_EQ(val1, val2) \
    do { \
        if ((val1) != (val2)) { \
            std::ostringstream ss; \
            ss << "Assertion failed: " #val1 " == " #val2 " (" \
               << ::SmartTraffic::Test::Detail::formatValue(val1) << " != " \
               << ::SmartTraffic::Test::Detail::formatValue(val2) << ") at " << __FILE__ << ":" << __LINE__; \
            throw std::runtime_error(ss.str()); \
        } \
    } while (0)

#define ASSERT_NE(val1, val2) \
    do { \
        if ((val1) == (val2)) { \
            std::ostringstream ss; \
            ss << "Assertion failed: " #val1 " != " #val2 " (" \
               << ::SmartTraffic::Test::Detail::formatValue(val1) << " == " \
               << ::SmartTraffic::Test::Detail::formatValue(val2) << ") at " << __FILE__ << ":" << __LINE__; \
            throw std::runtime_error(ss.str()); \
        } \
    } while (0)

#define ASSERT_NEAR(val1, val2, tolerance) \
    do { \
        const double diff = std::abs((val1) - (val2)); \
        if (diff > (tolerance)) { \
            std::ostringstream ss; \
            ss << "Assertion failed: |" #val1 " - " #val2 "| <= " #tolerance \
               << " (diff=" << diff << ", val1=" << ::SmartTraffic::Test::Detail::formatValue(val1) \
               << ", val2=" << ::SmartTraffic::Test::Detail::formatValue(val2) \
               << ") at " << __FILE__ << ":" << __LINE__; \
            throw std::runtime_error(ss.str()); \
        } \
    } while (0)

#define ASSERT_LE(val1, val2) \
    do { \
        if ((val1) > (val2)) { \
            std::ostringstream ss; \
            ss << "Assertion failed: " #val1 " <= " #val2 " (" \
               << ::SmartTraffic::Test::Detail::formatValue(val1) << " > " \
               << ::SmartTraffic::Test::Detail::formatValue(val2) << ") at " << __FILE__ << ":" << __LINE__; \
            throw std::runtime_error(ss.str()); \
        } \
    } while (0)

#define ASSERT_GE(val1, val2) \
    do { \
        if ((val1) < (val2)) { \
            std::ostringstream ss; \
            ss << "Assertion failed: " #val1 " >= " #val2 " (" \
               << ::SmartTraffic::Test::Detail::formatValue(val1) << " < " \
               << ::SmartTraffic::Test::Detail::formatValue(val2) << ") at " << __FILE__ << ":" << __LINE__; \
            throw std::runtime_error(ss.str()); \
        } \
    } while (0)
