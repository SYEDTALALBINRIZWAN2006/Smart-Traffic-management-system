#include "test_framework.h"
#include "smart_traffic/windows/windows_file_io.h"
#include "smart_traffic/windows/windows_memory_manager.h"
#include "smart_traffic/windows/windows_process_manager.h"
#include "smart_traffic/windows/shared_memory_ipc.h"
#include "smart_traffic/windows/kalman_benchmark_runner.h"
#include <fstream>
#include <sstream>
#include <cmath>

using namespace SmartTraffic;
using namespace SmartTraffic::Windows;

namespace {
    std::vector<std::string> splitCsvLine(const std::string& line) {
        std::vector<std::string> tokens;
        std::string token;
        std::istringstream stream(line);
        while (std::getline(stream, token, ',')) {
            tokens.push_back(token);
        }
        if (!line.empty() && line.back() == ',') {
            tokens.push_back("");
        }
        return tokens;
    }
}

TEST_CASE(WindowsOSTests, WindowsFileIOReadWriteAndMissingHandling) {
    const std::string test_file = "data/test_win_io.txt";
    const std::string test_data = "SmartTraffic Win32 Native File I/O Verification\nLine 2 Data";

    // 1. Write text
    ASSERT_TRUE(WindowsFileIO::writeAllText(test_file, test_data));
    ASSERT_TRUE(WindowsFileIO::fileExists(test_file));
    ASSERT_EQ(WindowsFileIO::getFileSize(test_file), test_data.size());

    // 2. Read back
    std::string read_back;
    ASSERT_TRUE(WindowsFileIO::readAllText(test_file, read_back));
    ASSERT_EQ(read_back, test_data);

    // 3. Append text
    const std::string append_data = "\nAppended Line 3";
    ASSERT_TRUE(WindowsFileIO::appendAllText(test_file, append_data));
    ASSERT_TRUE(WindowsFileIO::readAllText(test_file, read_back));
    ASSERT_EQ(read_back, test_data + append_data);

    // 4. Missing file handling
    std::string dummy;
    ASSERT_FALSE(WindowsFileIO::readAllText("data/non_existent_file_12345.txt", dummy));
    ASSERT_FALSE(WindowsFileIO::fileExists("data/non_existent_file_12345.txt"));
}

TEST_CASE(WindowsOSTests, WindowsMemoryAllocationAndMetrics) {
    // 1. VirtualAlloc & VirtualFree
    const size_t alloc_size = 64 * 1024; // 64 KB
    void* mem = WindowsMemoryManager::allocateVirtualMemory(alloc_size);
    ASSERT_TRUE(mem != nullptr);

    // Touch memory to commit pages
    int* int_ptr = static_cast<int*>(mem);
    int_ptr[0] = 42;
    int_ptr[100] = 1337;
    ASSERT_EQ(int_ptr[0], 42);
    ASSERT_EQ(int_ptr[100], 1337);

    ASSERT_TRUE(WindowsMemoryManager::freeVirtualMemory(mem));

    // 2. VirtualBuffer RAII wrapper
    {
        VirtualBuffer buf(32 * 1024);
        ASSERT_TRUE(buf.isValid());
        ASSERT_EQ(buf.size(), 32 * 1024U);
        char* c = static_cast<char*>(buf.data());
        c[0] = 'A';
        c[1024] = 'Z';
        ASSERT_EQ(c[0], 'A');
        ASSERT_EQ(c[1024], 'Z');
    }

    // 3. Process Memory Metrics via GetProcessMemoryInfo
    ProcessMemoryMetrics metrics;
    ASSERT_TRUE(WindowsMemoryManager::queryMemoryMetrics(metrics));
    ASSERT_TRUE(metrics.working_set_bytes > 0);
    ASSERT_TRUE(metrics.peak_working_set_bytes > 0);
    ASSERT_TRUE(metrics.private_bytes > 0);
}

TEST_CASE(WindowsOSTests, SharedMemoryIpcCommunicationAndSynchronization) {
    const std::string session_id = "test_ipc_sync_" + std::to_string(GetCurrentProcessId());
    const uint32_t channel_id = 99;

    SharedMemoryIPC server_ipc;
    ASSERT_TRUE(server_ipc.createChannel(session_id, channel_id));
    ASSERT_TRUE(server_ipc.isValid());
    ASSERT_TRUE(server_ipc.getResultEvent() != NULL);

    SharedMemoryIPC client_ipc;
    ASSERT_TRUE(client_ipc.openChannel(session_id, channel_id));
    ASSERT_TRUE(client_ipc.isValid());

    // Verify channel header
    auto* ch = client_ipc.getChannel();
    ASSERT_EQ(ch->magic_signature, IPC_MAGIC_SIGNATURE);
    ASSERT_EQ(ch->protocol_version, IPC_PROTOCOL_VERSION);
    ASSERT_EQ(ch->channel_id, channel_id);

    // Test task dispatch and worker wait
    std::vector<IpcVehicleTask> tasks(2);
    tasks[0].vehicle_id = 1;
    tasks[0].has_fresh_gps = 1;
    tasks[0].timestamp = 0.0;
    tasks[0].gps_x = 10.0;
    tasks[0].gps_y = 20.0;

    tasks[1].vehicle_id = 2;
    tasks[1].has_fresh_gps = 1;
    tasks[1].timestamp = 0.0;
    tasks[1].gps_x = 30.0;
    tasks[1].gps_y = 40.0;

    // Test async dispatch from server
    ASSERT_TRUE(server_ipc.dispatchTasksAsync(tasks));

    // Worker waits and retrieves command
    IpcCommand cmd = client_ipc.workerWaitForTask(200);
    ASSERT_EQ(cmd, IPC_CMD_PROCESS_BATCH);
    ASSERT_EQ(ch->task_count, 2U);

    // Worker writes result and signals
    ch->results[0].vehicle_id = 1;
    ch->results[0].status = 0;
    ch->results[0].estimated_x = 10.0;
    ch->results[0].estimated_y = 20.0;
    ch->results[0].estimated_vx = 0.0;
    ch->results[0].estimated_vy = 0.0;
    ch->result_count = 1;
    ASSERT_TRUE(client_ipc.workerSignalResultReady());

    // Server waits and collects
    ASSERT_TRUE(server_ipc.waitForResult(200));
    std::vector<IpcVehicleResult> res;
    ASSERT_TRUE(server_ipc.collectResults(res));
    ASSERT_EQ(res.size(), 1U);
    ASSERT_EQ(res[0].vehicle_id, 1U);

    client_ipc.close();
    server_ipc.close();
}

TEST_CASE(WindowsOSTests, WindowsProcessManagerLifecycleAndTimeout) {
    // Launch a process with a valid application or query current executable dir
    std::string cur_dir = WindowsProcessManager::getCurrentExecutableDirectory();
    ASSERT_FALSE(cur_dir.empty());

    // Missing worker is a test failure, not a silent pass.
    std::string worker_exe = SMARTTRAFFIC_WORKER_EXE;
    ASSERT_TRUE(WindowsFileIO::fileExists(worker_exe));
    WindowsProcess proc;
    ASSERT_TRUE(WindowsProcessManager::launchProcess(
        worker_exe, "--session invalid_session_xyz --channel 999", proc));
    ASSERT_TRUE(proc.isValid());
    DWORD exit_code = 0;
    ASSERT_TRUE(proc.waitForExit(3000, &exit_code));
    ASSERT_TRUE(exit_code != static_cast<DWORD>(STILL_ACTIVE));
    ASSERT_EQ(exit_code, 101U);
}

TEST_CASE(WindowsOSTests, WorkerProcessEndToEndKalmanTracking) {
    std::string worker_exe = SMARTTRAFFIC_WORKER_EXE;
    ASSERT_TRUE(WindowsFileIO::fileExists(worker_exe));

    const std::string session_id = "test_e2e_" + std::to_string(GetCurrentProcessId());
    const uint32_t channel_id = 0;

    SharedMemoryIPC ipc;
    ASSERT_TRUE(ipc.createChannel(session_id, channel_id));

    WindowsProcess worker;
    std::string args = "--session " + session_id + " --channel 0 --process-noise 1.0 --meas-noise 2.5";
    ASSERT_TRUE(WindowsProcessManager::launchProcess(worker_exe, args, worker));
    ASSERT_TRUE(worker.isValid());
    ASSERT_TRUE(worker.isRunning());

    // Tick 0: Initialize 3 vehicles with fresh GPS
    std::vector<IpcVehicleTask> t0(3);
    for (uint32_t i = 0; i < 3; ++i) {
        t0[i].vehicle_id = i + 1;
        t0[i].has_fresh_gps = 1;
        t0[i].is_departed = 0;
        t0[i].timestamp = 0.0;
        t0[i].dt = 0.1;
        t0[i].gps_x = 100.0 * (i + 1);
        t0[i].gps_y = 200.0 * (i + 1);
    }

    std::vector<IpcVehicleResult> r0;
    ASSERT_TRUE(ipc.dispatchTasksAndWait(t0, r0, 3000));
    ASSERT_EQ(r0.size(), 3U);
    for (uint32_t i = 0; i < 3; ++i) {
        ASSERT_EQ(r0[i].vehicle_id, i + 1);
        ASSERT_EQ(r0[i].status, 0U);
        ASSERT_NEAR(r0[i].estimated_x, 100.0 * (i + 1), 1e-4);
        ASSERT_NEAR(r0[i].estimated_y, 200.0 * (i + 1), 1e-4);
    }

    // Tick 1: Predict only (no fresh GPS)
    std::vector<IpcVehicleTask> t1(3);
    for (uint32_t i = 0; i < 3; ++i) {
        t1[i].vehicle_id = i + 1;
        t1[i].has_fresh_gps = 0;
        t1[i].is_departed = 0;
        t1[i].timestamp = 0.1;
        t1[i].dt = 0.1;
        t1[i].gps_x = 0.0;
        t1[i].gps_y = 0.0;
    }

    std::vector<IpcVehicleResult> r1;
    ASSERT_TRUE(ipc.dispatchTasksAndWait(t1, r1, 3000));
    ASSERT_EQ(r1.size(), 3U);

    // Tick 2: Vehicle 2 departs
    std::vector<IpcVehicleTask> t2(3);
    t2[0] = t1[0];
    t2[0].timestamp = 0.2;
    t2[1].vehicle_id = 2;
    t2[1].is_departed = 1; // Mark departed
    t2[2] = t1[2];
    t2[2].timestamp = 0.2;

    std::vector<IpcVehicleResult> r2;
    ASSERT_TRUE(ipc.dispatchTasksAndWait(t2, r2, 3000));
    ASSERT_EQ(r2.size(), 2U); // Vehicle 2 should not produce result
    ASSERT_EQ(r2[0].vehicle_id, 1U);
    ASSERT_EQ(r2[1].vehicle_id, 3U);

    // Shutdown worker gracefully
    ASSERT_TRUE(ipc.sendShutdownSignal(1000));
    DWORD exit_code = 999;
    ASSERT_TRUE(worker.waitForExit(3000, &exit_code));
    ASSERT_EQ(exit_code, 0U);

    ipc.close();
}

TEST_CASE(WindowsOSTests, MultiWorkerParallelVsSequentialNumericalEquivalence) {
    BenchmarkConfig config;
    config.simulation_ticks = 20;
    config.repeat_trials = 1;
    KalmanBenchmarkRunner runner(config);

    const auto workload = KalmanBenchmarkRunner::generateSyntheticWorkload(20, 20, 42);

    // 1. Sequential run
    BenchmarkResult seq = runner.runSingleBenchmark(20, 1, workload);
    ASSERT_TRUE(seq.success);
    ASSERT_EQ(seq.final_step_results.size(), 20U);

    // 2. Parallel run with 2 workers
    BenchmarkResult par = runner.runSingleBenchmark(20, 2, workload);
    ASSERT_TRUE(par.success);
    ASSERT_EQ(par.final_step_results.size(), 20U);

    // 3. Verify vehicle-by-vehicle state match
    std::unordered_map<uint32_t, IpcVehicleResult> seq_map;
    for (const auto& r : seq.final_step_results) {
        seq_map[r.vehicle_id] = r;
    }

    double max_diff = 0.0;
    for (const auto& pr : par.final_step_results) {
        auto it = seq_map.find(pr.vehicle_id);
        ASSERT_TRUE(it != seq_map.end());
        const double dx = pr.estimated_x - it->second.estimated_x;
        const double dy = pr.estimated_y - it->second.estimated_y;
        const double dist = std::sqrt(dx * dx + dy * dy);
        if (dist > max_diff) max_diff = dist;
        ASSERT_NEAR(pr.estimated_vx, it->second.estimated_vx, 1e-5);
        ASSERT_NEAR(pr.estimated_vy, it->second.estimated_vy, 1e-5);
    }

    ASSERT_LE(max_diff, 1e-5);
    ASSERT_GE(par.cpu_utilization_percent, 0.0);
    ASSERT_LE(par.cpu_utilization_percent, 100.0);
}

TEST_CASE(WindowsOSTests, IpcTimeoutAndFailureHandlingWithoutDeadlock) {
    const std::string session_id = "test_timeout_" + std::to_string(GetCurrentProcessId());
    const uint32_t channel_id = 77;

    SharedMemoryIPC ipc;
    ASSERT_TRUE(ipc.createChannel(session_id, channel_id));

    // Dispatch tasks to channel without any worker listening
    std::vector<IpcVehicleTask> tasks(1);
    tasks[0].vehicle_id = 999;
    tasks[0].has_fresh_gps = 1;
    tasks[0].gps_x = 0.0;
    tasks[0].gps_y = 0.0;

    std::vector<IpcVehicleResult> results;
    // Must timeout cleanly within 100ms and return false
    ASSERT_FALSE(ipc.dispatchTasksAndWait(tasks, results, 100));
    ASSERT_TRUE(results.empty());

    ipc.close();
}

TEST_CASE(WindowsOSTests, SyntheticWorkloadGenerationDeterminism) {
    auto w1 = KalmanBenchmarkRunner::generateSyntheticWorkload(10, 50, 42);
    auto w2 = KalmanBenchmarkRunner::generateSyntheticWorkload(10, 50, 42);

    ASSERT_EQ(w1.size(), 50U);
    ASSERT_EQ(w1[0].size(), 10U);

    for (size_t t = 0; t < 50; ++t) {
        for (size_t v = 0; v < 10; ++v) {
            ASSERT_EQ(w1[t][v].vehicle_id, w2[t][v].vehicle_id);
            ASSERT_NEAR(w1[t][v].gps_x, w2[t][v].gps_x, 1e-9);
            ASSERT_NEAR(w1[t][v].gps_y, w2[t][v].gps_y, 1e-9);
            ASSERT_EQ(w1[t][v].has_fresh_gps, w2[t][v].has_fresh_gps);
        }
    }
}

TEST_CASE(WindowsOSTests, SequentialBenchmarkExecutionAndMetrics) {
    BenchmarkConfig config;
    config.simulation_ticks = 20;
    config.repeat_trials = 1;
    KalmanBenchmarkRunner runner(config);

    const auto workload = KalmanBenchmarkRunner::generateSyntheticWorkload(10, 20, 42);
    BenchmarkResult res = runner.runSingleBenchmark(10, 1, workload);

    ASSERT_EQ(res.execution_mode, "Sequential");
    ASSERT_EQ(res.worker_count, 1U);
    ASSERT_EQ(res.vehicle_count, 10U);
    ASSERT_EQ(res.total_ticks, 20U);
    ASSERT_EQ(res.total_samples_processed, 200U);
    ASSERT_TRUE(res.compute_time_ms > 0.0);
    ASSERT_TRUE(res.throughput_samples_per_sec > 0.0);
    ASSERT_TRUE(res.peak_working_set_bytes > 0);
}

TEST_CASE(WindowsOSTests, BenchmarkOutputCsvFormatting) {
    BenchmarkConfig config;
    config.simulation_ticks = 10;
    config.repeat_trials = 1;
    config.os_metrics_csv_path = "data/test_win_os_metrics.csv";
    config.benchmark_csv_path = "data/test_kalman_benchmarks.csv";
    KalmanBenchmarkRunner runner(config);

    const auto workload = KalmanBenchmarkRunner::generateSyntheticWorkload(10, 10, 42);
    BenchmarkResult res = runner.runSingleBenchmark(10, 1, workload);

    std::vector<BenchmarkResult> results = { res };
    ASSERT_TRUE(runner.exportResultsToCsv(results));

    // Verify windows_os_metrics.csv (10 columns)
    std::string os_content;
    ASSERT_TRUE(WindowsFileIO::readAllText("data/test_win_os_metrics.csv", os_content));
    std::istringstream os_stream(os_content);
    std::string line;
    std::getline(os_stream, line);
    auto os_headers = splitCsvLine(line);
    ASSERT_EQ(os_headers.size(), 10U);

    // Verify kalman_benchmarks.csv (12 columns)
    std::string b_content;
    ASSERT_TRUE(WindowsFileIO::readAllText("data/test_kalman_benchmarks.csv", b_content));
    std::istringstream b_stream(b_content);
    std::getline(b_stream, line);
    auto b_headers = splitCsvLine(line);
    ASSERT_EQ(b_headers.size(), 12U);
}
