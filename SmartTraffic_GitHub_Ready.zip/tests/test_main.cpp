#include "test_framework.h"

int main() {
    return SmartTraffic::Test::TestRegistry::instance().runAll();
}
