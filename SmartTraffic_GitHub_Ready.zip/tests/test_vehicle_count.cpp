#include "test_framework.h"
#include "smart_traffic/simulation/vehicle_manager.h"
#include "smart_traffic/simulation/traffic_simulator.h"
#include <unordered_set>
#include <cstdint>

using namespace SmartTraffic;

TEST_CASE(VehicleCountTests, UniqueAndMonotonicVehicleIds) {
    VehicleManager manager;
    std::unordered_set<uint32_t> seen_ids;

    const size_t test_count = 50;
    for (size_t i = 0; i < test_count; ++i) {
        auto v = manager.createVehicle(1, 10.0, 13.0, 0.0);
        ASSERT_TRUE(v != nullptr);
        ASSERT_EQ(seen_ids.count(v->getId()), 0U);
        seen_ids.insert(v->getId());
        ASSERT_EQ(v->getId(), static_cast<uint32_t>(i + 1));
    }

    ASSERT_EQ(manager.getTotalCreatedCount(), test_count);
}

TEST_CASE(VehicleCountTests, VehicleLifecycleManagement) {
    VehicleManager manager;

    auto v1 = manager.createVehicle(1, 8.0, 12.0, 0.0);
    auto v2 = manager.createVehicle(2, 9.0, 13.0, 1.0);

    ASSERT_EQ(v1->getState(), VehicleState::PENDING_SPAWN);
    ASSERT_EQ(manager.getActiveCount(), 0U);

    manager.activateVehicle(v1);
    ASSERT_EQ(v1->getState(), VehicleState::ACTIVE);
    ASSERT_EQ(manager.getActiveCount(), 1U);

    manager.activateVehicle(v2);
    ASSERT_EQ(manager.getActiveCount(), 2U);

    ASSERT_TRUE(manager.getActiveVehicle(v1->getId()) == v1);
    ASSERT_TRUE(manager.getActiveVehicle(v2->getId()) == v2);

    manager.markVehicleCompleted(v1->getId());
    ASSERT_EQ(v1->getState(), VehicleState::COMPLETED);
    ASSERT_EQ(manager.getActiveCount(), 1U);
    ASSERT_EQ(manager.getCompletedCount(), 1U);
    ASSERT_TRUE(manager.getActiveVehicle(v1->getId()) == nullptr);

    manager.removeVehicle(v2->getId());
    ASSERT_EQ(v2->getState(), VehicleState::DESPAWNED);
    ASSERT_EQ(manager.getActiveCount(), 0U);
}

TEST_CASE(VehicleCountTests, ConfiguredVehicleCountSpawning) {
    SimulationConfig config = SimulationConfig::createDefault();
    config.vehicle_count = 30;
    config.total_simulation_time = 60.0;
    config.spawn_interval_seconds = 1.0; // Stagger 1s each
    config.enable_console_progress = false;
    config.output_csv_path = "data/test_count_run.csv";
    config.tracking_csv_path = "";
    config.analytics_csv_path = "";
    config.alerts_csv_path = "";

    TrafficSimulator sim(config);
    const auto summary = sim.run();

    // Verify exactly 30 vehicles were spawned and accounted for
    ASSERT_EQ(summary.vehicles_spawned, 30U);
    ASSERT_EQ(summary.vehicles_completed + summary.active_vehicles_at_end, 30U);
    ASSERT_TRUE(summary.total_ticks == 600U);
}
