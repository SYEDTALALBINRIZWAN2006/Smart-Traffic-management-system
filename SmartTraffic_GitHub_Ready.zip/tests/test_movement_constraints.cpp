#include "test_framework.h"
#include "smart_traffic/core/vehicle.h"
#include "smart_traffic/road/lane.h"
#include "smart_traffic/simulation/traffic_simulator.h"

using namespace SmartTraffic;

TEST_CASE(MovementConstraintTests, KinematicsRespectSpeedAndAccelerationLimits) {
    Vehicle vehicle(1, 101, 0.0, 15.0);
    vehicle.setMaxSpeed(20.0);        // 20 m/s max
    vehicle.setMaxAcceleration(2.5);  // 2.5 m/s^2
    vehicle.setMaxDeceleration(4.5);  // 4.5 m/s^2

    const double dt = 0.1;
    const double speed_limit = 13.89; // 50 km/h

    // 1. Extreme requested acceleration must be clamped to max_acceleration
    vehicle.updateKinematics(100.0, dt, speed_limit); // Requested 100 m/s^2
    // Speed should be clamped to 0.0 + 2.5 * 0.1 = 0.25 m/s
    ASSERT_NEAR(vehicle.getCurrentSpeed(), 0.25, 1e-4);

    // 2. Continuous acceleration up to speed limit
    for (int i = 0; i < 100; ++i) {
        vehicle.updateKinematics(5.0, dt, speed_limit);
    }
    // Speed must not exceed road speed limit
    ASSERT_LE(vehicle.getCurrentSpeed(), speed_limit);
    ASSERT_LE(vehicle.getCurrentSpeed(), vehicle.getMaxSpeed());

    // 3. Extreme braking must not cause negative speed (reversing)
    for (int i = 0; i < 50; ++i) {
        vehicle.updateKinematics(-20.0, dt, speed_limit);
    }
    ASSERT_GE(vehicle.getCurrentSpeed(), 0.0);
    ASSERT_NEAR(vehicle.getCurrentSpeed(), 0.0, 1e-4);
}

TEST_CASE(MovementConstraintTests, LaneSpatialMappingAndDirection) {
    Lane lane(1, "Test_Lane", Position(0.0, 0.0), Position(100.0, 0.0), 13.89, Direction::EAST);

    ASSERT_NEAR(lane.getLength(), 100.0, 1e-6);

    // Start of lane
    Position p0 = lane.getPositionAtDistance(0.0);
    ASSERT_NEAR(p0.x, 0.0, 1e-4);
    ASSERT_NEAR(p0.y, 0.0, 1e-4);

    // Midpoint of lane
    Position p50 = lane.getPositionAtDistance(50.0);
    ASSERT_NEAR(p50.x, 50.0, 1e-4);
    ASSERT_NEAR(p50.y, 0.0, 1e-4);

    // End of lane
    Position p100 = lane.getPositionAtDistance(100.0);
    ASSERT_NEAR(p100.x, 100.0, 1e-4);
    ASSERT_NEAR(p100.y, 0.0, 1e-4);

    // Velocity vector points in positive X direction
    Velocity v = lane.getVelocityVector(10.0);
    ASSERT_NEAR(v.vx, 10.0, 1e-4);
    ASSERT_NEAR(v.vy, 0.0, 1e-4);
    ASSERT_NEAR(v.speed(), 10.0, 1e-4);
}

TEST_CASE(MovementConstraintTests, CarFollowingHeadwayPreservedInSimulation) {
    SimulationConfig config = SimulationConfig::createDefault();
    config.vehicle_count = 15;
    config.total_simulation_time = 30.0;
    config.spawn_interval_seconds = 1.2;
    config.min_headway_distance = 4.0;
    config.enable_console_progress = false;
    config.output_csv_path = "data/test_headway.csv";
    config.tracking_csv_path = "";
    config.analytics_csv_path = "";
    config.alerts_csv_path = "";

    TrafficSimulator sim(config);
    sim.initialize();

    // Verify during all simulation ticks that no two vehicles on the same lane collide or violate physical bounds
    for (size_t t = 0; t < 300; ++t) {
        sim.step();

        const auto& road = sim.getRoadNetwork();
        const auto& vm = sim.getVehicleManager();

        for (const auto& [lane_id, lane] : road.getAllLanes()) {
            auto vehicles_on_lane = vm.getVehiclesOnLane(lane_id);
            if (vehicles_on_lane.size() >= 2) {
                for (size_t i = 1; i < vehicles_on_lane.size(); ++i) {
                    const auto& lead = vehicles_on_lane[i - 1];
                    const auto& follow = vehicles_on_lane[i];

                    // Lead vehicle must be further along lane than follower
                    ASSERT_GE(lead->getDistanceAlongLane(), follow->getDistanceAlongLane());

                    // Center-to-center distance must be non-negative
                    const double dist = lead->getPosition().distanceTo(follow->getPosition());
                    ASSERT_GE(dist, 0.0);
                }
            }
        }
    }
}
