#include "test_framework.h"
#include "smart_traffic/simulation/traffic_simulator.h"
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

using namespace SmartTraffic;

namespace {
    std::vector<std::string> splitCsvLine(const std::string& line) {
        std::vector<std::string> tokens;
        std::string token;
        std::istringstream stream(line);
        while (std::getline(stream, token, ',')) {
            tokens.push_back(token);
        }
        // If line ends with a comma, trailing field is empty
        if (!line.empty() && line.back() == ',') {
            tokens.push_back("");
        }
        return tokens;
    }
}

TEST_CASE(TrackingIntegrationTests, FullTrafficSimulationTrackingIntegration) {
    SimulationConfig config = SimulationConfig::createDefault();
    config.vehicle_count = 30;
    config.total_simulation_time = 60.0;
    config.random_seed = 42;
    config.gps_sampling_interval_seconds = 1.0;
    config.enable_console_progress = false;
    config.output_csv_path = "data/test_integ_raw.csv";
    config.tracking_csv_path = "data/test_integ_tracking.csv";
    config.analytics_csv_path = "";
    config.alerts_csv_path = "";

    TrafficSimulator sim(config);
    const auto summary = sim.run();

    ASSERT_EQ(summary.vehicles_spawned, 30U);
    ASSERT_EQ(summary.total_ticks, 600U);

    const auto& tm = summary.tracking_metrics;
    ASSERT_EQ(tm.total_vehicles_tracked, 30U);
    ASSERT_TRUE(tm.comparable_sample_count > 0);
    ASSERT_TRUE(tm.total_prediction_ticks > 0);

    // Verify no NaNs or Infs
    ASSERT_FALSE(std::isnan(tm.gps_rmse_meters));
    ASSERT_FALSE(std::isinf(tm.gps_rmse_meters));
    ASSERT_FALSE(std::isnan(tm.kalman_rmse_meters));
    ASSERT_FALSE(std::isinf(tm.kalman_rmse_meters));
    ASSERT_FALSE(std::isnan(tm.kalman_all_ticks_rmse_meters));
    ASSERT_FALSE(std::isinf(tm.kalman_all_ticks_rmse_meters));

    // Kalman Filter should reduce estimation error compared to raw GPS on comparable timestamps
    ASSERT_TRUE(tm.kalman_rmse_meters < tm.gps_rmse_meters);
    ASSERT_TRUE(tm.error_reduction_percentage > 0.0);
}

TEST_CASE(TrackingIntegrationTests, TrackingCsvFormatAndFreshnessFlagValidation) {
    SimulationConfig config = SimulationConfig::createDefault();
    config.vehicle_count = 5;
    config.total_simulation_time = 10.0;
    config.random_seed = 1234;
    config.gps_sampling_interval_seconds = 1.0;
    config.enable_console_progress = false;
    config.output_csv_path = "data/test_fmt_raw.csv";
    config.tracking_csv_path = "data/test_fmt_tracking.csv";
    config.analytics_csv_path = "";
    config.alerts_csv_path = "";

    TrafficSimulator sim(config);
    sim.run();

    std::ifstream file(config.tracking_csv_path);
    ASSERT_TRUE(file.is_open());

    std::string header;
    ASSERT_TRUE(static_cast<bool>(std::getline(file, header)));
    ASSERT_EQ(header, "timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y,estimated_x,estimated_y,gps_error,kalman_error,gps_fresh");

    std::string line;
    size_t fresh_count = 0;
    size_t non_fresh_count = 0;
    size_t total_rows = 0;

    while (std::getline(file, line)) {
        if (line.empty()) continue;
        total_rows++;

        // Parse every row using field splitting
        const auto tokens = splitCsvLine(line);
        // Strict verification: every row must have exactly 11 columns
        ASSERT_EQ(tokens.size(), 11U);

        const std::string& fresh_str = tokens[10];
        if (fresh_str == "1") {
            fresh_count++;
            // Fresh GPS measurement row: GPS columns and error must be populated
            ASSERT_FALSE(tokens[4].empty()); // gps_x
            ASSERT_FALSE(tokens[5].empty()); // gps_y
            ASSERT_FALSE(tokens[8].empty()); // gps_error
            ASSERT_FALSE(tokens[6].empty()); // estimated_x
            ASSERT_FALSE(tokens[7].empty()); // estimated_y
            ASSERT_FALSE(tokens[9].empty()); // kalman_error
        } else if (fresh_str == "0") {
            non_fresh_count++;
            // Prediction-only row: GPS columns and gps_error must be empty
            ASSERT_TRUE(tokens[4].empty());  // gps_x
            ASSERT_TRUE(tokens[5].empty());  // gps_y
            ASSERT_TRUE(tokens[8].empty());  // gps_error
            // Estimated columns and kalman_error must be populated
            ASSERT_FALSE(tokens[6].empty()); // estimated_x
            ASSERT_FALSE(tokens[7].empty()); // estimated_y
            ASSERT_FALSE(tokens[9].empty()); // kalman_error
        } else {
            throw std::runtime_error("Invalid gps_fresh indicator value: " + fresh_str);
        }
    }

    ASSERT_TRUE(total_rows > 0);
    ASSERT_TRUE(fresh_count > 0);
    ASSERT_TRUE(non_fresh_count > 0);
}

TEST_CASE(TrackingIntegrationTests, TrackingMetricsAccurateWithCsvExportDisabled) {
    // 1. Run simulation WITH CSV export
    SimulationConfig config_with_csv = SimulationConfig::createDefault();
    config_with_csv.vehicle_count = 8;
    config_with_csv.total_simulation_time = 15.0;
    config_with_csv.random_seed = 555;
    config_with_csv.enable_console_progress = false;
    config_with_csv.output_csv_path = "data/test_metrics_with_csv.csv";
    config_with_csv.tracking_csv_path = "data/test_metrics_with_tracking.csv";
    config_with_csv.analytics_csv_path = "";
    config_with_csv.alerts_csv_path = "";

    TrafficSimulator sim_with(config_with_csv);
    const auto summary_with = sim_with.run();

    // 2. Run simulation WITHOUT CSV export (empty paths)
    SimulationConfig config_without_csv = config_with_csv;
    config_without_csv.output_csv_path = "";
    config_without_csv.tracking_csv_path = "";

    TrafficSimulator sim_without(config_without_csv);
    sim_without.getTrackingManager(); // verify access
    const auto summary_without = sim_without.run();

    const auto& tm_with = summary_with.tracking_metrics;
    const auto& tm_without = summary_without.tracking_metrics;

    // Metrics must be fully computed even with CSV export disabled
    ASSERT_TRUE(tm_without.comparable_sample_count > 0);
    ASSERT_TRUE(tm_without.total_prediction_ticks > 0);
    ASSERT_TRUE(tm_without.total_vehicles_tracked > 0);

    // Metrics must match identically
    ASSERT_EQ(tm_without.comparable_sample_count, tm_with.comparable_sample_count);
    ASSERT_EQ(tm_without.total_prediction_ticks, tm_with.total_prediction_ticks);
    ASSERT_EQ(tm_without.total_vehicles_tracked, tm_with.total_vehicles_tracked);
    ASSERT_NEAR(tm_without.gps_rmse_meters, tm_with.gps_rmse_meters, 1e-9);
    ASSERT_NEAR(tm_without.kalman_rmse_meters, tm_with.kalman_rmse_meters, 1e-9);
    ASSERT_NEAR(tm_without.kalman_all_ticks_rmse_meters, tm_with.kalman_all_ticks_rmse_meters, 1e-9);
    ASSERT_NEAR(tm_without.error_reduction_percentage, tm_with.error_reduction_percentage, 1e-9);
}

TEST_CASE(TrackingIntegrationTests, MultiSeedAndNoiseAccuracyValidation) {
    const std::vector<uint64_t> test_seeds = { 42, 1001, 7777 };
    const std::vector<double> test_noise_levels = { 1.5, 2.5, 4.0 };

    double total_sum_sq_gps = 0.0;
    double total_sum_sq_kalman = 0.0;
    uint64_t total_comparable_samples = 0;

    for (uint64_t seed : test_seeds) {
        for (double noise_std : test_noise_levels) {
            SimulationConfig config = SimulationConfig::createDefault();
            config.vehicle_count = 10;
            config.total_simulation_time = 20.0;
            config.random_seed = seed;
            config.gps_noise_stddev = noise_std;
            config.kalman_measurement_noise_stddev = noise_std;
            config.kalman_process_noise_stddev = 1.0;
            config.enable_console_progress = false;
            config.output_csv_path = "";
            config.tracking_csv_path = "";
            config.analytics_csv_path = "";
            config.alerts_csv_path = "";

            TrafficSimulator sim(config);
            const auto summary = sim.run();
            const auto& tm = summary.tracking_metrics;

            // 1. Positive sample counts
            ASSERT_TRUE(tm.comparable_sample_count > 0);
            ASSERT_TRUE(tm.total_prediction_ticks > 0);
            ASSERT_TRUE(tm.total_vehicles_tracked > 0);
            ASSERT_EQ(tm.total_vehicles_tracked, summary.vehicles_spawned);

            // 2. Valid finite RMSE values
            ASSERT_TRUE(std::isfinite(tm.gps_rmse_meters));
            ASSERT_TRUE(std::isfinite(tm.kalman_rmse_meters));
            ASSERT_TRUE(std::isfinite(tm.kalman_all_ticks_rmse_meters));
            ASSERT_TRUE(tm.gps_rmse_meters > 0.0);
            ASSERT_TRUE(tm.kalman_rmse_meters > 0.0);
            ASSERT_TRUE(tm.kalman_all_ticks_rmse_meters > 0.0);

            // 3. Valid filter state and covariance in active tracking manager
            for (const auto& vehicle : sim.getVehicleManager().getActiveVehicles()) {
                if (!vehicle) continue;
                const auto* filter = sim.getTrackingManager().getFilter(vehicle->getId());
                if (filter) {
                    ASSERT_TRUE(filter->hasValidState());
                    ASSERT_TRUE(filter->getCovariance()(0, 0) > 0.0);
                    ASSERT_TRUE(filter->getCovariance()(1, 1) > 0.0);
                    ASSERT_TRUE(filter->getCovariance()(2, 2) > 0.0);
                    ASSERT_TRUE(filter->getCovariance()(3, 3) > 0.0);
                }
            }

            // 4. Deterministic reproducibility verification
            {
                TrafficSimulator sim_repeat(config);
                const auto summary_repeat = sim_repeat.run();
                ASSERT_NEAR(summary_repeat.tracking_metrics.gps_rmse_meters, tm.gps_rmse_meters, 1e-9);
                ASSERT_NEAR(summary_repeat.tracking_metrics.kalman_rmse_meters, tm.kalman_rmse_meters, 1e-9);
                ASSERT_NEAR(summary_repeat.tracking_metrics.kalman_all_ticks_rmse_meters, tm.kalman_all_ticks_rmse_meters, 1e-9);
            }

            // 5. In high noise scenarios (sigma = 4.0m), Kalman filter strictly outperforms raw GPS
            if (noise_std >= 4.0) {
                ASSERT_TRUE(tm.kalman_rmse_meters < tm.gps_rmse_meters);
                ASSERT_TRUE(tm.error_reduction_percentage > 0.0);
            }

            // Accumulate for aggregate evaluation across all 9 scenarios
            total_sum_sq_gps += (tm.gps_rmse_meters * tm.gps_rmse_meters) * tm.comparable_sample_count;
            total_sum_sq_kalman += (tm.kalman_rmse_meters * tm.kalman_rmse_meters) * tm.comparable_sample_count;
            total_comparable_samples += tm.comparable_sample_count;
        }
    }

    // 6. Aggregate GPS vs Kalman accuracy comparison across all 9 evaluation scenarios
    ASSERT_TRUE(total_comparable_samples > 0);
    const double aggregate_gps_rmse = std::sqrt(total_sum_sq_gps / total_comparable_samples);
    const double aggregate_kalman_rmse = std::sqrt(total_sum_sq_kalman / total_comparable_samples);
    const double aggregate_error_reduction = ((aggregate_gps_rmse - aggregate_kalman_rmse) / aggregate_gps_rmse) * 100.0;

    // The Kalman tracking engine must achieve net positive noise reduction across the multi-scenario grid
    ASSERT_TRUE(aggregate_kalman_rmse < aggregate_gps_rmse);
    ASSERT_TRUE(aggregate_error_reduction > 0.0);
}

TEST_CASE(TrackingIntegrationTests, EdgeCaseSingleVehicleAndLargeFleet) {
    // 1. Single vehicle scenario
    {
        SimulationConfig config = SimulationConfig::createDefault();
        config.vehicle_count = 1;
        config.total_simulation_time = 15.0;
        config.random_seed = 42;
        config.enable_console_progress = false;
        config.output_csv_path = "";
        config.tracking_csv_path = "";
        config.analytics_csv_path = "";
        config.alerts_csv_path = "";

        TrafficSimulator sim(config);
        const auto summary = sim.run();

        ASSERT_EQ(summary.vehicles_spawned, 1U);
        ASSERT_EQ(summary.tracking_metrics.total_vehicles_tracked, 1U);
        ASSERT_TRUE(summary.tracking_metrics.comparable_sample_count > 0);
        ASSERT_FALSE(std::isnan(summary.tracking_metrics.kalman_rmse_meters));
    }

    // 2. Dense fleet scenario (50 vehicles)
    {
        SimulationConfig config = SimulationConfig::createDefault();
        config.vehicle_count = 50;
        config.total_simulation_time = 25.0;
        config.spawn_interval_seconds = 0.4;
        config.random_seed = 1001;
        config.enable_console_progress = false;
        config.output_csv_path = "";
        config.tracking_csv_path = "";
        config.analytics_csv_path = "";
        config.alerts_csv_path = "";

        TrafficSimulator sim(config);
        const auto summary = sim.run();

        ASSERT_EQ(summary.vehicles_spawned, 50U);
        ASSERT_EQ(summary.tracking_metrics.total_vehicles_tracked, 50U);
        ASSERT_FALSE(std::isnan(summary.tracking_metrics.kalman_rmse_meters));
        ASSERT_TRUE(summary.tracking_metrics.error_reduction_percentage > 0.0);
    }
}

TEST_CASE(TrackingIntegrationTests, EdgeCaseZeroAndHighGpsNoise) {
    // 1. Zero GPS Noise (perfect GPS)
    {
        SimulationConfig config = SimulationConfig::createDefault();
        config.vehicle_count = 5;
        config.total_simulation_time = 15.0;
        config.gps_noise_stddev = 0.0;
        config.kalman_measurement_noise_stddev = 0.1; // small nonzero measurement noise model
        config.enable_console_progress = false;
        config.output_csv_path = "";
        config.tracking_csv_path = "";
        config.analytics_csv_path = "";
        config.alerts_csv_path = "";

        TrafficSimulator sim(config);
        const auto summary = sim.run();
        const auto& tm = summary.tracking_metrics;

        ASSERT_NEAR(tm.gps_rmse_meters, 0.0, 1e-4);
        ASSERT_FALSE(std::isnan(tm.kalman_rmse_meters));
        ASSERT_FALSE(std::isinf(tm.kalman_rmse_meters));
    }

    // 2. High GPS Noise (sigma = 10.0m)
    {
        SimulationConfig config = SimulationConfig::createDefault();
        config.vehicle_count = 5;
        config.total_simulation_time = 20.0;
        config.gps_noise_stddev = 10.0;
        config.kalman_measurement_noise_stddev = 10.0;
        config.enable_console_progress = false;
        config.output_csv_path = "";
        config.tracking_csv_path = "";
        config.analytics_csv_path = "";
        config.alerts_csv_path = "";

        TrafficSimulator sim(config);
        const auto summary = sim.run();
        const auto& tm = summary.tracking_metrics;

        ASSERT_TRUE(tm.gps_rmse_meters > 10.0);
        ASSERT_TRUE(tm.kalman_rmse_meters < tm.gps_rmse_meters);
        ASSERT_TRUE(tm.error_reduction_percentage > 0.0);
    }
}

TEST_CASE(TrackingIntegrationTests, EdgeCaseConfigValidationAndFallback) {
    // 1. Invalid vehicle count = 0 throws
    {
        SimulationConfig config = SimulationConfig::createDefault();
        config.vehicle_count = 0;
        bool caught = false;
        try {
            config.validate();
        } catch (const std::invalid_argument&) {
            caught = true;
        }
        ASSERT_TRUE(caught);
    }

    // 2. Invalid tick duration <= 0 throws
    {
        SimulationConfig config = SimulationConfig::createDefault();
        config.tick_duration_seconds = -0.1;
        bool caught = false;
        try {
            config.validate();
        } catch (const std::invalid_argument&) {
            caught = true;
        }
        ASSERT_TRUE(caught);
    }

    // 3. Fallback to default when loading non-existent file
    {
        SimulationConfig config = SimulationConfig::createDefault();
        bool loaded = config.loadFromFile("non_existent_config_file_12345.json");
        ASSERT_FALSE(loaded);
        ASSERT_EQ(config.vehicle_count, 30U);
        ASSERT_NEAR(config.total_simulation_time, 60.0, 1e-6);
    }
}

