#include "smart_traffic/database/traffic_database.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
int main() {
    namespace fs = std::filesystem;
    const fs::path dir = fs::temp_directory_path() / "smarttraffic_phase5_test";
    fs::remove_all(dir);
    fs::create_directories(dir);
    try {
        {
            std::ofstream out(dir / "traffic_simulation.csv");
            out << "timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y\n0.1,1,1,2,3,4\n0.2,2,2,3,4,5\n";
        }
        {
            std::ofstream out(dir / "kalman_tracking.csv");
            out << "timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y,estimated_x,estimated_y,gps_error,kalman_error,gps_fresh\n";
            out << "0.1,1,1,2,3,4,1.2,2.2,2.0,0.2,1\n";
        }
        SmartTraffic::TrafficDatabase db((dir / "test.db").string());
        db.importCsvDirectory(dir.string());
        if (db.count("gps_measurements") != 2 || db.count("tracking_estimates") != 1) throw std::runtime_error("Incorrect imported counts");
        if (db.queryJson("gps_measurements", 1).find("\"total\":2") == std::string::npos) throw std::runtime_error("Pagination failed");
        if (db.queryJson("tracking_estimates").find("estimated_x") == std::string::npos) throw std::runtime_error("Tracking schema failed");
        db.importCsvDirectory(dir.string());
        if (db.count("gps_measurements") != 2) throw std::runtime_error("Repeated import duplicated rows");
        bool rejected = false;
        try { (void)db.count("sqlite_master"); } catch (const std::invalid_argument&) { rejected = true; }
        if (!rejected) throw std::runtime_error("Invalid table not rejected");
        {
            std::ofstream out(dir / "traffic_simulation.csv");
            out << "timestamp,vehicle_id,actual_x,actual_y,gps_x,gps_y\ninvalid,row\n";
        }
        rejected = false;
        try { db.importCsvDirectory(dir.string()); } catch (const std::exception&) { rejected = true; }
        if (!rejected || db.count("gps_measurements") != 2) throw std::runtime_error("Rollback on malformed CSV failed");
        // Missing required files must never erase previously imported data.
        rejected = false;
        try { db.importCsvDirectory((dir / "nonexistent").string()); } catch (const std::exception&) { rejected = true; }
        if (!rejected || db.count("gps_measurements") != 2) throw std::runtime_error("Missing directory erased data");
        fs::remove(dir / "kalman_tracking.csv");
        rejected = false;
        try { db.importCsvDirectory(dir.string()); } catch (const std::exception&) { rejected = true; }
        if (!rejected || db.count("gps_measurements") != 2) throw std::runtime_error("Missing required tracking CSV erased data");
        const std::string vehicles = db.latestVehiclesJson();
        if (vehicles.find("\"total\":1") == std::string::npos || vehicles.find("\"vehicle_id\":\"1\"") == std::string::npos)
            throw std::runtime_error("Latest vehicle snapshot incorrect");
        if (db.latestVehiclesJson(1, 1).find("\"data\":[]") == std::string::npos)
            throw std::runtime_error("Latest vehicle pagination failed");
        std::cout << "Phase 5 SQLite tests: 10 checks passed\n";
    } catch (const std::exception& e) {
        std::cerr << "Phase 5 SQLite tests failed: " << e.what() << '\n';
        fs::remove_all(dir);
        return 1;
    }
    fs::remove_all(dir);
    return 0;
}
