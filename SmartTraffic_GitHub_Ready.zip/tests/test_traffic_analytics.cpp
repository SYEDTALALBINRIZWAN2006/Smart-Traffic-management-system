#include "test_framework.h"
#include "smart_traffic/analytics/traffic_analyzer.h"
#include "smart_traffic/analytics/alert_manager.h"
#include "smart_traffic/simulation/traffic_simulator.h"
#include "smart_traffic/road/road_network.h"
#include "smart_traffic/core/vehicle.h"
#include <fstream>
#include <sstream>
#include <vector>
#include <cmath>

using namespace SmartTraffic;

namespace {
    std::vector<std::string> splitCsvLine(const std::string& line) {
        std::vector<std::string> tokens;
        std::string token;
        std::istringstream stream(line);
        while (std::getline(stream, token, ',')) {
            tokens.push_back(token);
        }
        if (!line.empty() && line.back() == ',') {
            tokens.push_back("");
        }
        return tokens;
    }
}

TEST_CASE(TrafficAnalyticsTests, EmptyRoadsAndZeroDensity) {
    RoadNetwork net;
    net.buildStandardFourWayIntersection(150.0, 3.5, 13.89);

    TrafficAnalyzer analyzer;
    std::vector<std::shared_ptr<Vehicle>> empty_vehicles;

    analyzer.update(1.0, 0.1, empty_vehicles, net, 0);

    const auto& metrics = analyzer.getLatestMetrics();
    ASSERT_EQ(metrics.total_active_vehicles, 0U);
    ASSERT_EQ(metrics.total_stopped_vehicles, 0U);
    ASSERT_NEAR(metrics.average_network_speed_mps, 0.0, 1e-6);
    ASSERT_NEAR(metrics.average_network_speed_kmh, 0.0, 1e-6);
    ASSERT_NEAR(metrics.average_occupancy, 0.0, 1e-6);
    ASSERT_NEAR(metrics.average_density_vehicles_per_km, 0.0, 1e-6);
    ASSERT_EQ(metrics.network_congestion_level, CongestionLevel::LOW);

    // Verify all individual roads have safe zero values
    for (const auto& [lane_id, lane] : net.getAllLanes()) {
        const auto* rm = analyzer.getRoadMetrics(lane_id);
        ASSERT_TRUE(rm != nullptr);
        ASSERT_EQ(rm->vehicle_count, 0U);
        ASSERT_NEAR(rm->average_speed_mps, 0.0, 1e-6);
        ASSERT_NEAR(rm->occupancy, 0.0, 1e-6);
        ASSERT_NEAR(rm->density_vehicles_per_km, 0.0, 1e-6);
        ASSERT_EQ(rm->congestion_level, CongestionLevel::LOW);
        ASSERT_FALSE(std::isnan(rm->occupancy));
        ASSERT_FALSE(std::isinf(rm->occupancy));
    }
}

TEST_CASE(TrafficAnalyticsTests, SingleVehicleMetrics) {
    RoadNetwork net;
    net.buildStandardFourWayIntersection(150.0, 3.5, 13.89);

    auto v1 = std::make_shared<Vehicle>(1, 1, 10.0, 13.89, 0.0);
    v1->setLength(5.0);
    v1->setCurrentSpeed(10.0); // 10 m/s = 36 km/h

    std::vector<std::shared_ptr<Vehicle>> vehicles = { v1 };
    TrafficAnalyzer analyzer;
    analyzer.update(1.0, 0.1, vehicles, net, 2);

    const auto& metrics = analyzer.getLatestMetrics();
    ASSERT_EQ(metrics.total_active_vehicles, 1U);
    ASSERT_EQ(metrics.completed_journeys, 2U);
    ASSERT_NEAR(metrics.average_network_speed_mps, 10.0, 1e-6);
    ASSERT_NEAR(metrics.average_network_speed_kmh, 36.0, 1e-6);

    const auto* rm1 = analyzer.getRoadMetrics(1);
    ASSERT_TRUE(rm1 != nullptr);
    ASSERT_EQ(rm1->vehicle_count, 1U);
    ASSERT_NEAR(rm1->average_speed_mps, 10.0, 1e-6);
    ASSERT_NEAR(rm1->average_speed_kmh, 36.0, 1e-6);

    // Lane 1 length = 150 - 12 = 138 meters
    const double expected_occupancy = 5.0 / 138.0;
    const double expected_density = (1.0 / 138.0) * 1000.0;
    ASSERT_NEAR(rm1->occupancy, expected_occupancy, 1e-4);
    ASSERT_NEAR(rm1->density_vehicles_per_km, expected_density, 1e-4);
    ASSERT_EQ(rm1->congestion_level, CongestionLevel::LOW);
}

TEST_CASE(TrafficAnalyticsTests, MultipleVehiclesAndLaneDistribution) {
    RoadNetwork net;
    net.buildStandardFourWayIntersection(150.0, 3.5, 13.89);

    auto v1 = std::make_shared<Vehicle>(1, 1, 10.0, 13.89, 0.0);
    auto v2 = std::make_shared<Vehicle>(2, 1, 12.0, 13.89, 0.5);
    auto v3 = std::make_shared<Vehicle>(3, 2, 8.0, 13.89, 1.0);

    std::vector<std::shared_ptr<Vehicle>> vehicles = { v1, v2, v3 };
    TrafficAnalyzer analyzer;
    analyzer.update(2.0, 0.1, vehicles, net, 0);

    ASSERT_EQ(analyzer.getTotalActiveVehicles(), 3U);
    ASSERT_EQ(analyzer.getVehicleCountOnLane(1), 2U);
    ASSERT_EQ(analyzer.getVehicleCountOnLane(2), 1U);
    ASSERT_EQ(analyzer.getVehicleCountOnLane(3), 0U);

    const auto* rm1 = analyzer.getRoadMetrics(1);
    ASSERT_TRUE(rm1 != nullptr);
    ASSERT_EQ(rm1->vehicle_count, 2U);
    ASSERT_NEAR(rm1->average_speed_mps, 11.0, 1e-6); // (10 + 12) / 2 = 11.0
    ASSERT_NEAR(rm1->average_speed_kmh, 39.6, 1e-6);

    const auto* rm2 = analyzer.getRoadMetrics(2);
    ASSERT_TRUE(rm2 != nullptr);
    ASSERT_EQ(rm2->vehicle_count, 1U);
    ASSERT_NEAR(rm2->average_speed_mps, 8.0, 1e-6);

    // Network average = (10 + 12 + 8) / 3 = 10.0 m/s
    ASSERT_NEAR(analyzer.getAverageNetworkSpeedMps(), 10.0, 1e-6);
    ASSERT_NEAR(analyzer.getAverageNetworkSpeedKmh(), 36.0, 1e-6);
}

TEST_CASE(TrafficAnalyticsTests, CongestionLevelTransitions) {
    TrafficAnalyzer analyzer;

    // 1. LOW: Free flow, occupancy < 0.25, normal speed
    ASSERT_EQ(analyzer.evaluateCongestion(0.10, 13.0, 13.89, 2, 0), CongestionLevel::LOW);

    // 2. MODERATE: Occupancy between 0.25 and 0.50
    ASSERT_EQ(analyzer.evaluateCongestion(0.35, 12.0, 13.89, 5, 0), CongestionLevel::MODERATE);

    // 3. MODERATE: Moderate occupancy with speed drop to < 60%
    ASSERT_EQ(analyzer.evaluateCongestion(0.20, 6.0, 13.89, 3, 0), CongestionLevel::MODERATE);

    // 4. HIGH: Extreme occupancy >= 0.50
    ASSERT_EQ(analyzer.evaluateCongestion(0.55, 10.0, 13.89, 10, 0), CongestionLevel::HIGH);

    // 5. HIGH: High occupancy (>= 0.30) with crawling speed (<= 30% limit)
    ASSERT_EQ(analyzer.evaluateCongestion(0.35, 3.0, 13.89, 6, 2), CongestionLevel::HIGH);

    // 6. HIGH: Severe stopped ratio (>= 60%) with >= 3 vehicles
    ASSERT_EQ(analyzer.evaluateCongestion(0.20, 2.0, 13.89, 4, 3), CongestionLevel::HIGH);

    // 7. LOW: Empty road must strictly be LOW
    ASSERT_EQ(analyzer.evaluateCongestion(0.0, 0.0, 13.89, 0, 0), CongestionLevel::LOW);
}

TEST_CASE(TrafficAnalyticsTests, SpeedLimitViolationsDetection) {
    RoadNetwork net;
    net.buildStandardFourWayIntersection(150.0, 3.5, 13.89);

    AlertManager alert_mgr;

    // Vehicle 1 speeds at 15.0 m/s (Limit: 13.89 m/s, Excess: 1.11 m/s = ~8% over -> LOW)
    auto v1 = std::make_shared<Vehicle>(1, 1, 15.0, 15.0, 0.0);
    v1->setCurrentSpeed(15.0);

    // Vehicle 2 speeds at 19.0 m/s (Limit: 13.89 m/s, Excess: 5.11 m/s = ~37% over -> HIGH)
    auto v2 = std::make_shared<Vehicle>(2, 2, 19.0, 19.0, 0.0);
    v2->setCurrentSpeed(19.0);

    // Vehicle 3 is within speed limit (12.0 m/s)
    auto v3 = std::make_shared<Vehicle>(3, 3, 12.0, 13.89, 0.0);
    v3->setCurrentSpeed(12.0);

    std::vector<std::shared_ptr<Vehicle>> vehicles = { v1, v2, v3 };
    TrafficAnalyzer analyzer;
    analyzer.update(1.0, 0.1, vehicles, net, 0);

    alert_mgr.processAlerts(1.0, vehicles, analyzer, net);

    ASSERT_EQ(alert_mgr.getActiveAlertCount(), 2U);
    ASSERT_EQ(alert_mgr.getSummary().speed_violations_count, 2U);

    auto active = alert_mgr.getActiveAlerts();
    bool found_v1 = false;
    bool found_v2 = false;

    for (const auto& alert : active) {
        ASSERT_EQ(alert.type, AlertType::SPEED_VIOLATION);
        ASSERT_EQ(alert.status, AlertStatus::ACTIVE);
        if (alert.vehicle_id == 1) {
            found_v1 = true;
            ASSERT_EQ(alert.severity, ViolationSeverity::LOW);
            ASSERT_NEAR(alert.actual_speed_mps, 15.0, 1e-4);
        } else if (alert.vehicle_id == 2) {
            found_v2 = true;
            ASSERT_EQ(alert.severity, ViolationSeverity::HIGH);
            ASSERT_NEAR(alert.actual_speed_mps, 19.0, 1e-4);
        }
    }
    ASSERT_TRUE(found_v1);
    ASSERT_TRUE(found_v2);
}

TEST_CASE(TrafficAnalyticsTests, SpeedViolationDeduplication) {
    RoadNetwork net;
    net.buildStandardFourWayIntersection(150.0, 3.5, 13.89);

    AlertManager alert_mgr;
    TrafficAnalyzer analyzer;

    auto v1 = std::make_shared<Vehicle>(1, 1, 16.0, 16.0, 0.0);
    v1->setCurrentSpeed(16.0);
    std::vector<std::shared_ptr<Vehicle>> vehicles = { v1 };

    // Simulate 10 consecutive ticks while vehicle 1 is continuously speeding
    for (int tick = 0; tick < 10; ++tick) {
        double t = tick * 0.1;
        analyzer.update(t, 0.1, vehicles, net, 0);
        alert_mgr.processAlerts(t, vehicles, analyzer, net);
    }

    // Must still have exactly 1 active alert and total 1 alert created (deduplicated)
    ASSERT_EQ(alert_mgr.getActiveAlertCount(), 1U);
    ASSERT_EQ(alert_mgr.getTotalAlertCount(), 1U);
    ASSERT_EQ(alert_mgr.getSummary().speed_violations_count, 1U);
}

TEST_CASE(TrafficAnalyticsTests, StoppedVehicleDetection) {
    RoadNetwork net;
    net.buildStandardFourWayIntersection(150.0, 3.5, 13.89);

    AlertManager alert_mgr;
    TrafficAnalyzer analyzer;

    auto v1 = std::make_shared<Vehicle>(1, 1, 0.0, 0.0, 0.0);
    v1->setCurrentSpeed(0.0); // Stopped
    std::vector<std::shared_ptr<Vehicle>> vehicles = { v1 };

    // Tick 0 to 2.5s: stopped duration < 3.0s threshold -> NO alert
    for (double t = 0.0; t <= 2.5; t += 0.5) {
        analyzer.update(t, 0.5, vehicles, net, 0);
        alert_mgr.processAlerts(t, vehicles, analyzer, net);
        ASSERT_EQ(alert_mgr.getActiveAlertCount(), 0U);
    }

    // At t = 3.5s: stopped duration = 3.5s >= 3.0s threshold -> Alert triggered!
    analyzer.update(3.5, 0.5, vehicles, net, 0);
    alert_mgr.processAlerts(3.5, vehicles, analyzer, net);

    ASSERT_EQ(alert_mgr.getActiveAlertCount(), 1U);
    auto active = alert_mgr.getActiveAlerts();
    ASSERT_EQ(active[0].type, AlertType::STOPPED_VEHICLE);
    ASSERT_EQ(active[0].vehicle_id, 1U);
}

TEST_CASE(TrafficAnalyticsTests, EventResolutionLifecycle) {
    RoadNetwork net;
    net.buildStandardFourWayIntersection(150.0, 3.5, 13.89);

    AlertManager alert_mgr;
    TrafficAnalyzer analyzer;

    auto v1 = std::make_shared<Vehicle>(1, 1, 16.0, 16.0, 0.0);
    v1->setCurrentSpeed(16.0);
    std::vector<std::shared_ptr<Vehicle>> vehicles = { v1 };

    // 1. Trigger speeding alert at t = 1.0s
    analyzer.update(1.0, 0.1, vehicles, net, 0);
    alert_mgr.processAlerts(1.0, vehicles, analyzer, net);
    ASSERT_EQ(alert_mgr.getActiveAlertCount(), 1U);
    ASSERT_EQ(alert_mgr.getHistoricalAlertCount(), 0U);

    // 2. Vehicle decelerates to 12.0 m/s (below limit 13.89 m/s) at t = 2.0s
    v1->setCurrentSpeed(12.0);
    analyzer.update(2.0, 0.1, vehicles, net, 0);
    alert_mgr.processAlerts(2.0, vehicles, analyzer, net);

    // Alert must now be resolved
    ASSERT_EQ(alert_mgr.getActiveAlertCount(), 0U);
    ASSERT_EQ(alert_mgr.getHistoricalAlertCount(), 1U);

    const auto& history = alert_mgr.getHistoricalAlerts();
    ASSERT_EQ(history[0].status, AlertStatus::RESOLVED);
    ASSERT_NEAR(history[0].timestamp, 1.0, 1e-4);
    ASSERT_NEAR(history[0].resolved_timestamp, 2.0, 1e-4);
}

TEST_CASE(TrafficAnalyticsTests, HeavyCongestionAlertLifecycle) {
    RoadNetwork net;
    net.buildStandardFourWayIntersection(150.0, 3.5, 13.89);

    AlertManager alert_mgr;
    TrafficAnalyzer analyzer;

    // Pack Lane 1 with vehicles to trigger HIGH congestion (length = 138m)
    // 16 vehicles * 5m length = 80m -> occupancy = 80/138 = 58% (> 50% threshold)
    std::vector<std::shared_ptr<Vehicle>> packed_vehicles;
    for (uint32_t i = 1; i <= 16; ++i) {
        auto v = std::make_shared<Vehicle>(i, 1, 2.0, 13.89, 0.0);
        v->setLength(5.0);
        v->setCurrentSpeed(2.0);
        packed_vehicles.push_back(v);
    }

    analyzer.update(5.0, 0.1, packed_vehicles, net, 0);
    const auto* rm1 = analyzer.getRoadMetrics(1);
    ASSERT_TRUE(rm1 != nullptr);
    ASSERT_EQ(rm1->congestion_level, CongestionLevel::HIGH);

    alert_mgr.processAlerts(5.0, packed_vehicles, analyzer, net);
    ASSERT_EQ(alert_mgr.getActiveAlertCount(), 1U);
    auto active = alert_mgr.getActiveAlerts();
    ASSERT_EQ(active[0].type, AlertType::HEAVY_CONGESTION);
    ASSERT_EQ(active[0].road_id, 1U);

    // Clear vehicles from lane 1 -> congestion drops to LOW
    std::vector<std::shared_ptr<Vehicle>> cleared_vehicles;
    analyzer.update(6.0, 0.1, cleared_vehicles, net, 16);
    alert_mgr.processAlerts(6.0, cleared_vehicles, analyzer, net);

    // Congestion alert resolved
    ASSERT_EQ(alert_mgr.getActiveAlertCount(), 0U);
    ASSERT_EQ(alert_mgr.getHistoricalAlertCount(), 1U);
    ASSERT_EQ(alert_mgr.getHistoricalAlerts()[0].status, AlertStatus::RESOLVED);
}

TEST_CASE(TrafficAnalyticsTests, CsvFormattingAndDisabling) {
    // 1. Run simulation WITH CSV export enabled
    {
        SimulationConfig config = SimulationConfig::createDefault();
        config.vehicle_count = 5;
        config.total_simulation_time = 10.0;
        config.random_seed = 42;
        config.enable_console_progress = false;
        config.output_csv_path = "";
        config.tracking_csv_path = "";
        config.analytics_csv_path = "data/test_fmt_analytics.csv";
        config.alerts_csv_path = "data/test_fmt_alerts.csv";

        TrafficSimulator sim(config);
        const auto summary = sim.run();

        // Check Analytics CSV formatting (9 columns)
        std::ifstream a_file("data/test_fmt_analytics.csv");
        ASSERT_TRUE(a_file.is_open());
        std::string line;
        std::getline(a_file, line);
        auto headers = splitCsvLine(line);
        ASSERT_EQ(headers.size(), 9U);

        size_t a_rows = 0;
        while (std::getline(a_file, line)) {
            if (line.empty()) continue;
            auto cols = splitCsvLine(line);
            ASSERT_EQ(cols.size(), 9U);
            a_rows++;
        }
        ASSERT_TRUE(a_rows > 0);

        // Check Alerts CSV formatting (11 columns)
        std::ifstream al_file("data/test_fmt_alerts.csv");
        ASSERT_TRUE(al_file.is_open());
        std::getline(al_file, line);
        auto al_headers = splitCsvLine(line);
        ASSERT_EQ(al_headers.size(), 11U);
    }

    // 2. Run simulation WITHOUT CSV export (empty paths)
    {
        SimulationConfig config = SimulationConfig::createDefault();
        config.vehicle_count = 5;
        config.total_simulation_time = 10.0;
        config.random_seed = 42;
        config.enable_console_progress = false;
        config.output_csv_path = "";
        config.tracking_csv_path = "";
        config.analytics_csv_path = "";
        config.alerts_csv_path = "";

        TrafficSimulator sim(config);
        const auto summary = sim.run();

        // Metrics and summary must be fully computed even with CSV export disabled
        ASSERT_TRUE(summary.analytics_summary.total_snapshots > 0);
        ASSERT_FALSE(std::isnan(summary.analytics_summary.overall_mean_speed_mps));
    }
}

TEST_CASE(TrafficAnalyticsTests, AnalyticsIntegrationDeterministicSimulation) {
    SimulationConfig config1 = SimulationConfig::createDefault();
    config1.vehicle_count = 15;
    config1.total_simulation_time = 25.0;
    config1.random_seed = 9876;
    config1.enable_console_progress = false;
    config1.output_csv_path = "";
    config1.tracking_csv_path = "";
    config1.analytics_csv_path = "";
    config1.alerts_csv_path = "";

    TrafficSimulator sim1(config1);
    const auto sum1 = sim1.run();

    TrafficSimulator sim2(config1);
    const auto sum2 = sim2.run();

    // Verify analytics determinism
    ASSERT_EQ(sum1.analytics_summary.total_snapshots, sum2.analytics_summary.total_snapshots);
    ASSERT_EQ(sum1.analytics_summary.peak_active_vehicles, sum2.analytics_summary.peak_active_vehicles);
    ASSERT_NEAR(sum1.analytics_summary.overall_mean_speed_mps, sum2.analytics_summary.overall_mean_speed_mps, 1e-9);
    ASSERT_NEAR(sum1.analytics_summary.peak_occupancy, sum2.analytics_summary.peak_occupancy, 1e-9);
    ASSERT_EQ(sum1.alert_summary.total_alerts_created, sum2.alert_summary.total_alerts_created);
    ASSERT_EQ(sum1.alert_summary.speed_violations_count, sum2.alert_summary.speed_violations_count);

    // Verify Kalman Filter metrics are completely unaffected
    ASSERT_NEAR(sum1.tracking_metrics.gps_rmse_meters, sum2.tracking_metrics.gps_rmse_meters, 1e-9);
    ASSERT_NEAR(sum1.tracking_metrics.kalman_rmse_meters, sum2.tracking_metrics.kalman_rmse_meters, 1e-9);
}

TEST_CASE(TrafficAnalyticsTests, InvalidInputAndEdgeCaseHandling) {
    TrafficAnalyzer analyzer;
    RoadNetwork net;

    // Passing empty vehicles or negative dt must not throw or crash
    std::vector<std::shared_ptr<Vehicle>> null_veh_list = { nullptr };
    analyzer.update(0.0, -0.1, null_veh_list, net, 0);

    ASSERT_EQ(analyzer.getTotalActiveVehicles(), 0U);
    ASSERT_EQ(analyzer.getRoadMetrics(9999), nullptr); // Non-existent road
    ASSERT_EQ(analyzer.getVehicleCountOnLane(9999), 0U);
}
