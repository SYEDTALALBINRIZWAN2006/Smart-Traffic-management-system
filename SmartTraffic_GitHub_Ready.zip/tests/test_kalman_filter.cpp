#include "test_framework.h"
#include "smart_traffic/tracking/kalman_filter_2d.h"
#include "smart_traffic/tracking/tracking_manager.h"
#include <random>
#include <cmath>
#include <vector>

using namespace SmartTraffic;

TEST_CASE(KalmanFilterTests, StationaryMotionConvergence) {
    KalmanFilter2D kf(0.5, 2.5, 10.0);
    const double true_x = 50.0;
    const double true_y = -30.0;

    std::mt19937_64 rng(42);
    std::normal_distribution<double> noise(0.0, 2.5);

    // Initial GPS measurement at t = 0
    const double z0_x = true_x + noise(rng);
    const double z0_y = true_y + noise(rng);
    kf.initialize(z0_x, z0_y, 0.0);

    ASSERT_TRUE(kf.isInitialized());
    ASSERT_TRUE(kf.hasValidState());

    double sum_sq_gps_err = 0.0;
    double sum_sq_kf_err = 0.0;
    size_t samples = 0;

    // Simulate 30 seconds: 100ms predictions, 1s GPS updates
    for (int sec = 1; sec <= 30; ++sec) {
        // 10 prediction ticks per second (100 ms each)
        for (int tick = 0; tick < 10; ++tick) {
            kf.predict(0.100);
            ASSERT_TRUE(kf.hasValidState());
        }

        // GPS measurement once per second
        const double z_x = true_x + noise(rng);
        const double z_y = true_y + noise(rng);
        kf.correct(z_x, z_y, static_cast<double>(sec));

        ASSERT_TRUE(kf.hasValidState());

        const double gps_err = std::hypot(z_x - true_x, z_y - true_y);
        const double kf_err = std::hypot(kf.getEstimatedX() - true_x, kf.getEstimatedY() - true_y);

        sum_sq_gps_err += gps_err * gps_err;
        sum_sq_kf_err += kf_err * kf_err;
        samples++;
    }

    const double gps_rmse = std::sqrt(sum_sq_gps_err / samples);
    const double kf_rmse = std::sqrt(sum_sq_kf_err / samples);

    // Filter must achieve lower RMSE than noisy GPS measurements
    ASSERT_LE(kf_rmse, gps_rmse);

    // Stationary velocity estimate must converge near 0
    ASSERT_LE(kf.getEstimatedSpeed(), 1.0);
}

TEST_CASE(KalmanFilterTests, ConstantVelocityEstimation) {
    KalmanFilter2D kf(0.8, 2.5, 15.0);
    const double true_vx = 12.0; // 12 m/s East
    const double true_vy = 0.0;

    std::mt19937_64 rng(101);
    std::normal_distribution<double> noise(0.0, 2.5);

    double true_x = 0.0;
    double true_y = 10.0;

    kf.initialize(true_x + noise(rng), true_y + noise(rng), 0.0);

    for (int sec = 1; sec <= 40; ++sec) {
        for (int tick = 0; tick < 10; ++tick) {
            true_x += true_vx * 0.100;
            true_y += true_vy * 0.100;
            kf.predict(0.100);
            ASSERT_TRUE(kf.hasValidState());
        }

        const double z_x = true_x + noise(rng);
        const double z_y = true_y + noise(rng);
        kf.correct(z_x, z_y, static_cast<double>(sec));
        ASSERT_TRUE(kf.hasValidState());
    }

    // Velocity estimate should be close to true velocity
    ASSERT_NEAR(kf.getEstimatedVx(), true_vx, 2.0);
    ASSERT_NEAR(kf.getEstimatedVy(), true_vy, 1.5);
    ASSERT_NEAR(kf.getEstimatedX(), true_x, 3.5);
}

TEST_CASE(KalmanFilterTests, NoisyGpsNoiseReduction) {
    KalmanFilter2D kf(1.0, 2.5, 15.0);
    const double vx = 10.0;
    const double vy = 5.0;

    std::mt19937_64 rng(777);
    std::normal_distribution<double> noise(0.0, 2.5);

    double x = 0.0;
    double y = 0.0;
    kf.initialize(x + noise(rng), y + noise(rng), 0.0);

    double sum_sq_gps = 0.0;
    double sum_sq_kf = 0.0;
    size_t count = 0;

    for (int sec = 1; sec <= 60; ++sec) {
        for (int t = 0; t < 10; ++t) {
            x += vx * 0.100;
            y += vy * 0.100;
            kf.predict(0.100);
        }

        const double z_x = x + noise(rng);
        const double z_y = y + noise(rng);
        kf.correct(z_x, z_y, static_cast<double>(sec));

        // Skip transient burn-in (first 5 seconds) to evaluate steady state
        if (sec > 5) {
            const double g_err = std::hypot(z_x - x, z_y - y);
            const double k_err = std::hypot(kf.getEstimatedX() - x, kf.getEstimatedY() - y);
            sum_sq_gps += g_err * g_err;
            sum_sq_kf += k_err * k_err;
            count++;
        }
    }

    const double gps_rmse = std::sqrt(sum_sq_gps / count);
    const double kf_rmse = std::sqrt(sum_sq_kf / count);

    // Steady state Kalman RMSE must be strictly lower than raw GPS RMSE
    ASSERT_TRUE(kf_rmse < gps_rmse);
}

TEST_CASE(KalmanFilterTests, MissingMeasurementsDeadReckoning) {
    KalmanFilter2D kf(0.8, 2.5, 15.0);
    const double vx = 14.0;
    const double vy = 0.0;

    std::mt19937_64 rng(999);
    std::normal_distribution<double> noise(0.0, 2.5);

    double x = 0.0;
    double y = 0.0;
    kf.initialize(x + noise(rng), y + noise(rng), 0.0);

    // 1. Initial 10 seconds with GPS updates
    for (int sec = 1; sec <= 10; ++sec) {
        for (int t = 0; t < 10; ++t) {
            x += vx * 0.100;
            y += vy * 0.100;
            kf.predict(0.100);
        }
        kf.correct(x + noise(rng), y + noise(rng), static_cast<double>(sec));
    }

    const double pre_blackout_pos_var = kf.getCovariance()(0, 0);

    // 2. 5-second GPS blackout (50 ticks of pure dead-reckoning prediction)
    for (int t = 0; t < 50; ++t) {
        x += vx * 0.100;
        y += vy * 0.100;
        kf.predict(0.100);
        ASSERT_TRUE(kf.hasValidState());
    }

    // During blackout, uncertainty (covariance) must increase
    const double post_blackout_pos_var = kf.getCovariance()(0, 0);
    ASSERT_TRUE(post_blackout_pos_var > pre_blackout_pos_var);

    // Position estimate should still roughly track true motion via dead-reckoning
    ASSERT_NEAR(kf.getEstimatedX(), x, 6.0);

    // 3. Resumed GPS measurement: filter incorporates without instability
    const double z_resume_x = x + noise(rng);
    const double z_resume_y = y + noise(rng);
    kf.correct(z_resume_x, z_resume_y, 16.0);

    ASSERT_TRUE(kf.hasValidState());
    // Uncertainty drops back down after fresh correction
    ASSERT_TRUE(kf.getCovariance()(0, 0) < post_blackout_pos_var);
}

TEST_CASE(KalmanFilterTests, CovarianceNumericalStabilityJosephForm) {
    KalmanFilter2D kf(1.0, 2.5, 15.0);
    kf.initialize(0.0, 0.0, 0.0);

    std::mt19937_64 rng(314159);
    std::uniform_real_distribution<double> dt_dist(0.05, 0.20);
    std::normal_distribution<double> z_dist(0.0, 2.5);

    double current_time = 0.0;

    for (int i = 0; i < 500; ++i) {
        const double dt = dt_dist(rng);
        current_time += dt;
        kf.predict(dt);

        ASSERT_TRUE(kf.hasValidState());

        if (i % 5 == 0) {
            const double zx = z_dist(rng);
            const double zy = z_dist(rng);
            kf.correct(zx, zy, current_time);
            ASSERT_TRUE(kf.hasValidState());
        }

        const auto& P = kf.getCovariance();

        // Verify symmetry: P = P^T
        for (int r = 0; r < 4; ++r) {
            for (int c = 0; c < 4; ++c) {
                ASSERT_NEAR(P(r, c), P(c, r), 1e-9);
            }
        }

        // Verify diagonal elements are strictly positive
        for (int d = 0; d < 4; ++d) {
            ASSERT_TRUE(P(d, d) > 0.0);
        }

        // Verify positive trace
        ASSERT_TRUE(P.trace() > 0.0);
    }
}

TEST_CASE(KalmanFilterTests, IndependentVehicleTrackingNoCrossTalk) {
    TrackingManager tm(1.0, 2.5, "data/test_cross_talk.csv");

    auto v1 = std::make_shared<Vehicle>(1, 1, 10.0, 10.0, 0.0);
    v1->setPosition(Position(0.0, 0.0));
    v1->setVelocity(Velocity(10.0, 0.0));

    auto v2 = std::make_shared<Vehicle>(2, 2, 15.0, 15.0, 0.0);
    v2->setPosition(Position(100.0, 200.0));
    v2->setVelocity(Velocity(0.0, 15.0));

    std::vector<std::shared_ptr<Vehicle>> active = { v1, v2 };

    // Initial GPS measurements at t = 0.0
    GpsMeasurement m1_0;
    m1_0.timestamp = 0.0;
    m1_0.vehicle_id = 1;
    m1_0.actual_x = 0.0;
    m1_0.actual_y = 0.0;
    m1_0.gps_x = 0.5;
    m1_0.gps_y = -0.2;

    GpsMeasurement m2_0;
    m2_0.timestamp = 0.0;
    m2_0.vehicle_id = 2;
    m2_0.actual_x = 100.0;
    m2_0.actual_y = 200.0;
    m2_0.gps_x = 100.3;
    m2_0.gps_y = 199.8;

    tm.update(0.0, 0.1, active, { m1_0, m2_0 }, true);

    ASSERT_EQ(tm.getActiveFilterCount(), 2U);

    const auto* f1 = tm.getFilter(1);
    const auto* f2 = tm.getFilter(2);
    ASSERT_TRUE(f1 != nullptr);
    ASSERT_TRUE(f2 != nullptr);

    // Initial states initialized to respective initial GPS readings
    ASSERT_NEAR(f1->getEstimatedX(), 0.5, 1e-4);
    ASSERT_NEAR(f1->getEstimatedY(), -0.2, 1e-4);
    ASSERT_NEAR(f2->getEstimatedX(), 100.3, 1e-4);
    ASSERT_NEAR(f2->getEstimatedY(), 199.8, 1e-4);

    // Advance 9 prediction ticks (0.1s to 0.9s)
    for (int t = 1; t <= 9; ++t) {
        v1->setPosition(Position(t * 1.0, 0.0));
        v2->setPosition(Position(100.0, 200.0 + t * 1.5));
        tm.update(t * 0.1, 0.1, active, {}, false);
    }

    // Supply independent second GPS measurements at t = 1.0s
    GpsMeasurement m1_1;
    m1_1.timestamp = 1.0;
    m1_1.vehicle_id = 1;
    m1_1.actual_x = 10.0;
    m1_1.actual_y = 0.0;
    m1_1.gps_x = 10.4;
    m1_1.gps_y = 0.1;

    GpsMeasurement m2_1;
    m2_1.timestamp = 1.0;
    m2_1.vehicle_id = 2;
    m2_1.actual_x = 100.0;
    m2_1.actual_y = 215.0;
    m2_1.gps_x = 99.8;
    m2_1.gps_y = 215.3;

    v1->setPosition(Position(10.0, 0.0));
    v2->setPosition(Position(100.0, 215.0));
    tm.update(1.0, 0.1, active, { m1_1, m2_1 }, true);

    // Verify independent tracking:
    // Vehicle 1 has moved East along X; Y remains near 0
    ASSERT_TRUE(f1->getEstimatedX() > 5.0);
    ASSERT_NEAR(f1->getEstimatedY(), 0.0, 1.0);
    ASSERT_TRUE(f1->getEstimatedVx() > 4.0);

    // Vehicle 2 has moved North along Y; X remains near 100
    ASSERT_NEAR(f2->getEstimatedX(), 100.0, 1.5);
    ASSERT_TRUE(f2->getEstimatedY() > 205.0);
    ASSERT_TRUE(f2->getEstimatedVy() > 7.0);

    // Depart vehicle 1 and advance one tick with only vehicle 2 active
    active = { v2 };
    v2->setPosition(Position(100.0, 216.5));
    tm.update(1.1, 0.1, active, {}, false);

    // Verify vehicle departure cleanup: vehicle 1 is erased, vehicle 2 persists
    ASSERT_EQ(tm.getActiveFilterCount(), 1U);
    ASSERT_TRUE(tm.getFilter(1) == nullptr);
    ASSERT_TRUE(tm.getFilter(2) != nullptr);

    // Vehicle 2 state remains completely undisturbed and valid
    ASSERT_NEAR(tm.getFilter(2)->getEstimatedX(), 100.0, 1.5);
    ASSERT_TRUE(tm.getFilter(2)->hasValidState());
}
