#pragma once
#include <sqlite3.h>
#include <string>
#include <vector>

namespace SmartTraffic {
class TrafficDatabase {
public:
    explicit TrafficDatabase(const std::string& filename);
    ~TrafficDatabase();
    TrafficDatabase(const TrafficDatabase&) = delete;
    TrafficDatabase& operator=(const TrafficDatabase&) = delete;
    void importCsvDirectory(const std::string& directory);
    long long count(const std::string& table) const;
    std::string queryJson(const std::string& table, int limit = 100, int offset = 0) const;
    std::string summaryJson() const;
    std::string latestVehiclesJson(int limit = 100, int offset = 0) const;
    static std::string jsonEscape(const std::string& value);
private:
    sqlite3* db_ = nullptr;
    void execute(const std::string& sql);
    void importCsv(const std::string& filename, const std::string& table, const std::vector<std::string>& columns);
};
}
