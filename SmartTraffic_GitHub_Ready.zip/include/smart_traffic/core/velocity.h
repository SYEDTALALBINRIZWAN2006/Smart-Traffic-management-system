#pragma once

#include <iosfwd>
#include <string>

namespace SmartTraffic {

/**
 * @brief Represents a 2-dimensional velocity vector in meters per second (m/s).
 */
struct Velocity {
    double vx{0.0};  ///< X component of velocity in m/s
    double vy{0.0};  ///< Y component of velocity in m/s

    Velocity() noexcept = default;
    constexpr Velocity(double vx_mps, double vy_mps) noexcept : vx(vx_mps), vy(vy_mps) {}

    /**
     * @brief Computes scalar speed (magnitude of velocity vector) in m/s.
     */
    double speed() const noexcept;

    /**
     * @brief Computes heading angle in radians [-PI, PI], where 0 radians is along positive X-axis.
     */
    double headingRadians() const noexcept;

    /**
     * @brief Computes heading angle in degrees [0, 360).
     */
    double headingDegrees() const noexcept;

    /**
     * @brief Creates a Velocity vector from scalar speed and heading angle in radians.
     */
    static Velocity fromSpeedAndHeading(double speed_mps, double heading_rad) noexcept;

    Velocity operator+(const Velocity& other) const noexcept;
    Velocity operator-(const Velocity& other) const noexcept;
    Velocity operator*(double scalar) const noexcept;
    Velocity& operator+=(const Velocity& other) noexcept;
    Velocity& operator-=(const Velocity& other) noexcept;

    bool operator==(const Velocity& other) const noexcept;
    bool operator!=(const Velocity& other) const noexcept;

    std::string toString() const;

    friend std::ostream& operator<<(std::ostream& os, const Velocity& vel);
};

} // namespace SmartTraffic
