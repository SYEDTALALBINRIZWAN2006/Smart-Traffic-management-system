#pragma once

#include <cstdint>
#include <string>
#include <cmath>

namespace SmartTraffic {

/**
 * @brief Represents the lifecycle state of a vehicle within the simulation.
 */
enum class VehicleState {
    PENDING_SPAWN = 0,  ///< Vehicle registered but not yet inserted onto a lane
    ACTIVE = 1,         ///< Vehicle currently moving on the road network
    COMPLETED = 2,      ///< Vehicle has completed its designated route
    DESPAWNED = 3       ///< Vehicle removed due to collision, error, or boundary exit
};

/**
 * @brief Cardinal directions for road network orientation.
 */
enum class Direction {
    NORTH = 0,
    SOUTH = 1,
    EAST = 2,
    WEST = 3
};

/**
 * @brief Convert Direction enum to human-readable string.
 */
inline std::string directionToString(Direction dir) {
    switch (dir) {
        case Direction::NORTH: return "NORTH";
        case Direction::SOUTH: return "SOUTH";
        case Direction::EAST:  return "EAST";
        case Direction::WEST:  return "WEST";
        default:               return "UNKNOWN";
    }
}

/**
 * @brief Convert VehicleState enum to human-readable string.
 */
inline std::string vehicleStateToString(VehicleState state) {
    switch (state) {
        case VehicleState::PENDING_SPAWN: return "PENDING_SPAWN";
        case VehicleState::ACTIVE:        return "ACTIVE";
        case VehicleState::COMPLETED:     return "COMPLETED";
        case VehicleState::DESPAWNED:     return "DESPAWNED";
        default:                          return "UNKNOWN";
    }
}

/**
 * @brief Global simulation physical constants.
 */
namespace Constants {
    constexpr double DEFAULT_TICK_SECONDS = 0.100;    // 100 ms fixed tick
    constexpr double PI = 3.14159265358979323846;
    constexpr double EPSILON = 1e-6;                  // Precision threshold for floating comparisons
    constexpr double KMH_TO_MPS = 1000.0 / 3600.0;    // Convert km/h to m/s (~0.277778)
    constexpr double MPS_TO_KMH = 3600.0 / 1000.0;    // Convert m/s to km/h (3.6)
}

} // namespace SmartTraffic
