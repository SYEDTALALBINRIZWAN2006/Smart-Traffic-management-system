#pragma once

#include <iosfwd>
#include <string>

namespace SmartTraffic {

/**
 * @brief Represents a 2-dimensional position in Cartesian space using meters.
 */
struct Position {
    double x{0.0};  ///< X coordinate in meters
    double y{0.0};  ///< Y coordinate in meters

    Position() noexcept = default;
    constexpr Position(double x_meters, double y_meters) noexcept : x(x_meters), y(y_meters) {}

    /**
     * @brief Calculates Euclidean distance between this position and another in meters.
     */
    double distanceTo(const Position& other) const noexcept;

    /**
     * @brief Checks if two positions are within a given Euclidean tolerance distance.
     */
    bool isNear(const Position& other, double tolerance = 1e-4) const noexcept;

    /**
     * @brief Linear interpolation between this position and target position.
     * @param target End position.
     * @param t Interpolation parameter in range [0.0, 1.0].
     */
    Position lerp(const Position& target, double t) const noexcept;

    Position operator+(const Position& other) const noexcept;
    Position operator-(const Position& other) const noexcept;
    Position operator*(double scalar) const noexcept;
    Position& operator+=(const Position& other) noexcept;
    Position& operator-=(const Position& other) noexcept;

    bool operator==(const Position& other) const noexcept;
    bool operator!=(const Position& other) const noexcept;

    std::string toString() const;

    friend std::ostream& operator<<(std::ostream& os, const Position& pos);
};

} // namespace SmartTraffic
