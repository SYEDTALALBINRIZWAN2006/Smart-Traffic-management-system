#pragma once

#include "smart_traffic/core/types.h"
#include "smart_traffic/core/position.h"
#include "smart_traffic/core/velocity.h"
#include <string>

namespace SmartTraffic {

/**
 * @brief Represents an individual motorized vehicle within the simulation.
 * Coordinates are in meters and velocities in meters/second.
 */
class Vehicle {
public:
    Vehicle(uint32_t id, 
            uint32_t lane_id, 
            double initial_speed_mps = 0.0, 
            double target_speed_mps = 13.89, // ~50 km/h
            double spawn_time_sec = 0.0);

    // Identity and State Accessors
    uint32_t getId() const noexcept { return id_; }
    VehicleState getState() const noexcept { return state_; }
    void setState(VehicleState state) noexcept { state_ = state; }

    // Spatial and Kinematics Accessors
    const Position& getPosition() const noexcept { return position_; }
    void setPosition(const Position& pos) noexcept { position_ = pos; }

    const Velocity& getVelocity() const noexcept { return velocity_; }
    void setVelocity(const Velocity& vel) noexcept;

    double getCurrentSpeed() const noexcept { return current_speed_; }
    void setCurrentSpeed(double speed) noexcept;

    double getTargetSpeed() const noexcept { return target_speed_; }
    void setTargetSpeed(double speed) noexcept;

    double getMaxSpeed() const noexcept { return max_speed_; }
    void setMaxSpeed(double max_spd) noexcept;

    double getMaxAcceleration() const noexcept { return max_acceleration_; }
    void setMaxAcceleration(double max_acc) noexcept;

    double getMaxDeceleration() const noexcept { return max_deceleration_; }
    void setMaxDeceleration(double max_dec) noexcept;

    // Physical Dimensions
    double getLength() const noexcept { return length_; }
    void setLength(double length) noexcept { length_ = length; }

    double getWidth() const noexcept { return width_; }
    void setWidth(double width) noexcept { width_ = width; }

    // Lane and Route Tracking
    uint32_t getCurrentLaneId() const noexcept { return current_lane_id_; }
    void setCurrentLaneId(uint32_t lane_id) noexcept { current_lane_id_ = lane_id; }

    double getDistanceAlongLane() const noexcept { return distance_along_lane_; }
    void setDistanceAlongLane(double dist) noexcept { distance_along_lane_ = dist; }

    double getSpawnTime() const noexcept { return spawn_time_; }
    double getTotalDistanceTraveled() const noexcept { return total_distance_traveled_; }

    /**
     * @brief Applies acceleration/deceleration over time step dt with strict physical constraint clamping.
     * @param desired_acc Desired acceleration in m/s^2 (positive for acceleration, negative for braking).
     * @param dt Time delta in seconds.
     * @param speed_limit Upper speed bound imposed by current lane in m/s.
     * @return Distance traversed during this time step in meters.
     */
    double updateKinematics(double desired_acc, double dt, double speed_limit);

    /**
     * @brief Advances vehicle position along current lane.
     */
    void advanceDistanceAlongLane(double delta_s) noexcept;

    /**
     * @brief Transitions vehicle from current lane to a connecting successor lane.
     */
    void transitionToLane(uint32_t new_lane_id, double initial_distance = 0.0) noexcept;

    std::string toString() const;

private:
    uint32_t id_{0};
    Position position_{0.0, 0.0};
    Velocity velocity_{0.0, 0.0};

    double current_speed_{0.0};       // m/s
    double target_speed_{13.89};      // m/s (default ~50 km/h)
    double max_speed_{25.0};          // m/s (default 90 km/h)
    double max_acceleration_{2.5};    // m/s^2 (comfortable passenger car accel)
    double max_deceleration_{4.5};    // m/s^2 (controlled braking)

    double length_{4.5};              // meters
    double width_{1.8};               // meters

    uint32_t current_lane_id_{0};
    double distance_along_lane_{0.0}; // meters from lane start
    VehicleState state_{VehicleState::PENDING_SPAWN};

    double spawn_time_{0.0};          // seconds
    double total_distance_traveled_{0.0}; // cumulative meters
};

} // namespace SmartTraffic
