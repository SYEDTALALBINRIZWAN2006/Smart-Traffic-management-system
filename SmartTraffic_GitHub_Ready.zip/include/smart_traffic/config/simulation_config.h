#pragma once

#include <string>
#include <cstdint>

namespace SmartTraffic {

/**
 * @brief Centralized configuration for the traffic simulation backend.
 */
struct SimulationConfig {
    // Timing and Duration
    double tick_duration_seconds{0.100};   // 100 ms fixed simulation tick
    double total_simulation_time{60.0};    // 60 seconds total run time

    // Traffic Parameters
    uint32_t vehicle_count{30};            // Total vehicles to simulate (30)
    double spawn_interval_seconds{1.5};    // Time headway between vehicle spawns
    double default_speed_limit{13.89};     // 50 km/h (~13.89 m/s)
    double min_headway_distance{5.0};      // Minimum safety distance between vehicles in meters

    // Stochasticity and Sensor Parameters
    uint64_t random_seed{42};              // Deterministic seed for PRNG
    double gps_noise_stddev{2.5};          // Gaussian GPS error standard deviation in meters
    double gps_bias_x{0.0};                // Systematic sensor bias in X (meters)
    double gps_bias_y{0.0};                // Systematic sensor bias in Y (meters)
    double gps_sampling_interval_seconds{1.0}; // Configurable GPS sampling period in seconds (e.g. 1.0s)

    // Kalman Filter Tracking Parameters
    double kalman_process_noise_stddev{1.0};      // Process noise acceleration stddev (m/s^2)
    double kalman_measurement_noise_stddev{2.5};  // Expected measurement noise stddev (meters)
    std::string tracking_csv_path{"data/kalman_tracking.csv"}; // Kalman tracking telemetry export

    // Output and Storage Paths
    std::string output_csv_path{"data/traffic_simulation.csv"};
    std::string log_file_path{"logs/simulation.log"};
    bool enable_console_progress{true};
    bool enable_raw_csv{true};             // Toggle raw GPS measurement CSV export
    bool enable_tracking_csv{true};        // Toggle Kalman tracking telemetry CSV export

    // Phase 3: Traffic Analytics & Alerts Configuration
    std::string analytics_csv_path{"data/traffic_analytics.csv"};
    std::string alerts_csv_path{"data/traffic_alerts.csv"};
    bool enable_analytics_csv{true};       // Toggle traffic analytics CSV export
    bool enable_alerts_csv{true};          // Toggle traffic alerts CSV export
    double stopped_speed_threshold_mps{0.5};    // Vehicles below 0.5 m/s (~1.8 km/h) are stopped
    double stopped_duration_threshold_sec{3.0}; // Seconds stationary before triggering alert
    double speed_violation_tolerance_mps{0.5};  // Margin above speed limit before alert (~1.8 km/h)

    bool isRawCsvEnabled() const noexcept { return enable_raw_csv && !output_csv_path.empty(); }
    bool isTrackingCsvEnabled() const noexcept { return enable_tracking_csv && !tracking_csv_path.empty(); }
    bool isAnalyticsCsvEnabled() const noexcept { return enable_analytics_csv && !analytics_csv_path.empty(); }
    bool isAlertsCsvEnabled() const noexcept { return enable_alerts_csv && !alerts_csv_path.empty(); }

    /**
     * @brief Creates a default production-ready configuration.
     */
    static SimulationConfig createDefault();

    /**
     * @brief Validates all configuration parameters.
     * @throws std::invalid_argument If any parameter violates physical/logical constraints.
     */
    void validate() const;

    /**
     * @brief Loads configuration from a key-value or JSON-formatted file.
     * @return true if successfully loaded, false otherwise.
     */
    bool loadFromFile(const std::string& filepath);

    /**
     * @brief Saves current configuration to file.
     */
    bool saveToFile(const std::string& filepath) const;
};

} // namespace SmartTraffic
