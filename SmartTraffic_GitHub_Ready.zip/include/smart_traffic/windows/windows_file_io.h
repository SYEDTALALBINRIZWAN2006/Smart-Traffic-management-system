#pragma once

#include "smart_traffic/windows/scoped_handle.h"
#include "smart_traffic/simulation/gps_simulator.h"
#include <string>
#include <vector>
#include <cstdint>

namespace SmartTraffic {
namespace Windows {

/**
 * @brief Low-level Windows File I/O subsystem utilizing Win32 APIs (CreateFileW, ReadFile, WriteFile).
 */
class WindowsFileIO {
public:
    WindowsFileIO() = default;

    /**
     * @brief Writes full string content to a file, replacing existing content.
     */
    static bool writeAllText(const std::string& filepath, const std::string& content);
    static bool writeAllText(const std::wstring& filepath, const std::string& content);

    /**
     * @brief Appends text content to an existing or newly created file.
     */
    static bool appendAllText(const std::string& filepath, const std::string& content);
    static bool appendAllText(const std::wstring& filepath, const std::string& content);

    /**
     * @brief Reads entire file content into an output string buffer.
     */
    static bool readAllText(const std::string& filepath, std::string& out_content);
    static bool readAllText(const std::wstring& filepath, std::string& out_content);

    /**
     * @brief Parses a GPS telemetry CSV file into structured GpsMeasurement records.
     */
    static bool readGpsDataset(const std::string& csv_path, std::vector<GpsMeasurement>& out_measurements);

    /**
     * @brief Checks if a file exists using native Win32 attributes.
     */
    static bool fileExists(const std::string& filepath);

    /**
     * @brief Retrieves file size in bytes using Win32 GetFileSizeEx.
     */
    static uint64_t getFileSize(const std::string& filepath);

    /**
     * @brief Converts UTF-8 std::string to UTF-16 std::wstring for Win32 *W APIs.
     */
    static std::wstring utf8ToWide(const std::string& utf8_str);

    /**
     * @brief Converts UTF-16 std::wstring to UTF-8 std::string.
     */
    static std::string wideToUtf8(const std::wstring& wide_str);
};

} // namespace Windows
} // namespace SmartTraffic
