#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <psapi.h>
#include <cstdint>
#include <cstddef>

namespace SmartTraffic {
namespace Windows {

/**
 * @brief Memory utilization snapshots collected via Win32 GetProcessMemoryInfo.
 */
struct ProcessMemoryMetrics {
    size_t working_set_bytes{0};        // Physical RAM currently in use by process
    size_t peak_working_set_bytes{0};   // Maximum working set size observed
    size_t private_bytes{0};            // Committed virtual memory private to process
    size_t peak_private_bytes{0};       // Peak committed private bytes
};

/**
 * @brief RAII buffer allocating and releasing virtual memory pages via VirtualAlloc / VirtualFree.
 */
class VirtualBuffer {
public:
    VirtualBuffer() noexcept : data_(nullptr), size_(0) {}
    explicit VirtualBuffer(size_t size_bytes, DWORD protect = PAGE_READWRITE);
    ~VirtualBuffer() noexcept;

    VirtualBuffer(const VirtualBuffer&) = delete;
    VirtualBuffer& operator=(const VirtualBuffer&) = delete;

    VirtualBuffer(VirtualBuffer&& other) noexcept;
    VirtualBuffer& operator=(VirtualBuffer&& other) noexcept;

    void* data() noexcept { return data_; }
    const void* data() const noexcept { return data_; }
    size_t size() const noexcept { return size_; }
    bool isValid() const noexcept { return data_ != nullptr; }
    explicit operator bool() const noexcept { return isValid(); }

    void release() noexcept;

private:
    void* data_{nullptr};
    size_t size_{0};
};

/**
 * @brief Windows Virtual Memory Manager and Process Memory Monitor.
 */
class WindowsMemoryManager {
public:
    /**
     * @brief Reserves and commits virtual memory pages using VirtualAlloc.
     */
    static void* allocateVirtualMemory(size_t size_bytes, DWORD protect = PAGE_READWRITE) noexcept;

    /**
     * @brief Releases allocated virtual memory pages using VirtualFree(..., 0, MEM_RELEASE).
     */
    static bool freeVirtualMemory(void* address) noexcept;

    /**
     * @brief Queries current working set and private bytes via Win32 GetProcessMemoryInfo.
     */
    static bool queryMemoryMetrics(ProcessMemoryMetrics& out_metrics, HANDLE process_handle = GetCurrentProcess()) noexcept;

    static size_t getCurrentWorkingSetBytes() noexcept;
    static size_t getPeakWorkingSetBytes() noexcept;
    static size_t getPrivateBytes() noexcept;
};

} // namespace Windows
} // namespace SmartTraffic
