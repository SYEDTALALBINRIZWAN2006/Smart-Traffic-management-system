#pragma once

#include <cstdint>

namespace SmartTraffic {
namespace Windows {

constexpr uint32_t IPC_PROTOCOL_VERSION = 1;
constexpr uint32_t IPC_MAGIC_SIGNATURE = 0x53545241; // ASCII 'STRA'
constexpr uint32_t MAX_IPC_VEHICLES = 2048;

enum IpcCommand : uint32_t {
    IPC_CMD_IDLE = 0,
    IPC_CMD_PROCESS_BATCH = 1,
    IPC_CMD_SHUTDOWN = 2
};

#pragma pack(push, 8)

struct IpcVehicleTask {
    uint32_t vehicle_id;
    uint8_t has_fresh_gps;
    uint8_t is_departed;
    uint8_t reserved[2];
    double timestamp;
    double dt;
    double gps_x;
    double gps_y;
};

struct IpcVehicleResult {
    uint32_t vehicle_id;
    uint8_t status; // 0 = OK, 1 = Error
    uint8_t reserved[3];
    double estimated_x;
    double estimated_y;
    double estimated_vx;
    double estimated_vy;
};

/**
 * @brief Versioned, aligned shared memory structure for high-throughput zero-copy IPC.
 */
struct SharedMemoryChannel {
    // Header
    uint32_t magic_signature;
    uint32_t protocol_version;
    uint32_t channel_id;
    uint32_t reserved;

    // Control and Synchronization
    volatile uint32_t command;
    volatile uint32_t task_sequence_number;
    volatile uint32_t task_count;

    // Task payload
    IpcVehicleTask tasks[MAX_IPC_VEHICLES];

    // Result payload
    volatile uint32_t result_sequence_number;
    volatile uint32_t result_count;
    IpcVehicleResult results[MAX_IPC_VEHICLES];
};

#pragma pack(pop)

} // namespace Windows
} // namespace SmartTraffic
