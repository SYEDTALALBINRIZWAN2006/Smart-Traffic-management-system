#pragma once

#include "smart_traffic/windows/scoped_handle.h"
#include <string>
#include <vector>
#include <cstdint>

namespace SmartTraffic {
namespace Windows {

/**
 * @brief Represents a spawned Win32 child process managing PROCESS_INFORMATION handles via RAII.
 */
class WindowsProcess {
public:
    WindowsProcess() = default;
    WindowsProcess(HANDLE process_handle, HANDLE thread_handle, DWORD pid, DWORD tid) noexcept
        : process_handle_(process_handle),
          thread_handle_(thread_handle),
          process_id_(pid),
          thread_id_(tid) {}

    ~WindowsProcess() = default;

    WindowsProcess(const WindowsProcess&) = delete;
    WindowsProcess& operator=(const WindowsProcess&) = delete;

    WindowsProcess(WindowsProcess&& other) noexcept = default;
    WindowsProcess& operator=(WindowsProcess&& other) noexcept = default;

    bool isValid() const noexcept { return process_handle_.isValid(); }
    HANDLE getProcessHandle() const noexcept { return process_handle_.get(); }
    DWORD getProcessId() const noexcept { return process_id_; }

    /**
     * @brief Checks if process is currently still running.
     */
    bool isRunning() const noexcept;

    /**
     * @brief Waits for process termination up to timeout_ms milliseconds.
     */
    bool waitForExit(DWORD timeout_ms, DWORD* out_exit_code = nullptr) const noexcept;

    /**
     * @brief Queries exit code of terminated process.
     */
    bool getExitCode(DWORD& out_exit_code) const noexcept;

    /**
     * @brief Forcibly terminates process if running.
     */
    bool terminate(DWORD exit_code = 1) noexcept;

    void close() noexcept {
        process_handle_.close();
        thread_handle_.close();
        process_id_ = 0;
        thread_id_ = 0;
    }

private:
    ScopedHandle process_handle_;
    ScopedHandle thread_handle_;
    DWORD process_id_{0};
    DWORD thread_id_{0};
};

/**
 * @brief Win32 Process creation, lifecycle management, and monitoring subsystem.
 */
class WindowsProcessManager {
public:
    /**
     * @brief Spawns a child process using CreateProcessW.
     */
    static bool launchProcess(const std::string& executable_path,
                             const std::string& command_line_args,
                             WindowsProcess& out_process,
                             bool create_no_window = true);

    static bool launchProcess(const std::wstring& executable_path,
                             const std::wstring& command_line_args,
                             WindowsProcess& out_process,
                             bool create_no_window = true);

    /**
     * @brief Waits for a collection of worker processes to complete within a given timeout.
     */
    static bool waitForAll(const std::vector<WindowsProcess>& processes, DWORD timeout_ms);

    /**
     * @brief Terminates all active processes in collection.
     */
    static void terminateAll(std::vector<WindowsProcess>& processes);

    /**
     * @brief Retrieves the directory of the current running executable.
     */
    static std::string getCurrentExecutableDirectory();
};

} // namespace Windows
} // namespace SmartTraffic
