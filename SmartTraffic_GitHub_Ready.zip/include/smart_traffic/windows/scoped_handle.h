#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>

namespace SmartTraffic {
namespace Windows {

/**
 * @brief RAII wrapper for native Windows HANDLE objects.
 * Automatically closes handle upon destruction if valid.
 */
class ScopedHandle {
public:
    ScopedHandle() noexcept : handle_(INVALID_HANDLE_VALUE) {}
    explicit ScopedHandle(HANDLE handle) noexcept : handle_(handle) {}

    ~ScopedHandle() noexcept {
        close();
    }

    ScopedHandle(const ScopedHandle&) = delete;
    ScopedHandle& operator=(const ScopedHandle&) = delete;

    ScopedHandle(ScopedHandle&& other) noexcept : handle_(other.handle_) {
        other.handle_ = INVALID_HANDLE_VALUE;
    }

    ScopedHandle& operator=(ScopedHandle&& other) noexcept {
        if (this != &other) {
            close();
            handle_ = other.handle_;
            other.handle_ = INVALID_HANDLE_VALUE;
        }
        return *this;
    }

    void reset(HANDLE handle = INVALID_HANDLE_VALUE) noexcept {
        if (handle_ != handle) {
            close();
            handle_ = handle;
        }
    }

    HANDLE release() noexcept {
        HANDLE tmp = handle_;
        handle_ = INVALID_HANDLE_VALUE;
        return tmp;
    }

    HANDLE get() const noexcept {
        return handle_;
    }

    bool isValid() const noexcept {
        return handle_ != NULL && handle_ != INVALID_HANDLE_VALUE;
    }

    explicit operator bool() const noexcept {
        return isValid();
    }

    HANDLE* put() noexcept {
        close();
        return &handle_;
    }

    void close() noexcept {
        if (isValid()) {
            CloseHandle(handle_);
            handle_ = INVALID_HANDLE_VALUE;
        }
    }

private:
    HANDLE handle_{INVALID_HANDLE_VALUE};
};

} // namespace Windows
} // namespace SmartTraffic
