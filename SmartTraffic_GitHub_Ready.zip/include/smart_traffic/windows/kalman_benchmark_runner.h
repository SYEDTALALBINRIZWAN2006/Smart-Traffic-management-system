#pragma once

#include "smart_traffic/windows/shared_memory_ipc.h"
#include "smart_traffic/windows/windows_process_manager.h"
#include "smart_traffic/windows/windows_memory_manager.h"
#include "smart_traffic/tracking/kalman_filter_2d.h"
#include <vector>
#include <string>
#include <unordered_map>
#include <chrono>

namespace SmartTraffic {
namespace Windows {

struct BenchmarkConfig {
    std::vector<uint32_t> fleet_sizes = { 30, 100, 500, 1000 };
    std::vector<uint32_t> worker_counts = { 1, 2, 4 };
    uint32_t simulation_ticks = 100; // 10.0 seconds of simulation data (10 Hz ticks)
    uint32_t repeat_trials = 3;      // 3 trials to compute median timing
    double process_noise_stddev = 1.0;
    double measurement_noise_stddev = 2.5;
    std::string worker_executable_path = "build/kalman_worker.exe";
    std::string os_metrics_csv_path = "data/windows_os_metrics.csv";
    std::string benchmark_csv_path = "data/kalman_benchmarks.csv";
};

struct BenchmarkResult {
    std::string execution_mode;       // "Sequential", "Parallel_2W", "Parallel_4W"
    uint32_t worker_count{1};
    uint32_t vehicle_count{0};
    uint32_t total_ticks{0};
    uint64_t total_samples_processed{0};
    double startup_overhead_ms{0.0};
    double compute_time_ms{0.0};      // Median compute time
    double total_execution_time_ms{0.0};
    double speedup{1.0};              // Relative to sequential baseline
    double throughput_samples_per_sec{0.0};
    double cpu_utilization_percent{0.0};
    size_t peak_working_set_bytes{0};
    size_t peak_private_bytes{0};
    double max_numerical_diff_meters{0.0};
    bool numerical_equivalence_passed{true};
    bool success{true};
    std::vector<IpcVehicleResult> final_step_results;
};

/**
 * @brief High-precision Multiprocessing Benchmark Orchestrator for 2D Kalman Filter state estimation.
 */
class KalmanBenchmarkRunner {
public:
    explicit KalmanBenchmarkRunner(const BenchmarkConfig& config = BenchmarkConfig{});
    ~KalmanBenchmarkRunner();

    /**
     * @brief Generates deterministic test trajectories for N vehicles over T ticks.
     */
    static std::vector<std::vector<IpcVehicleTask>> generateSyntheticWorkload(uint32_t vehicle_count,
                                                                             uint32_t tick_count,
                                                                             uint64_t seed = 42);

    /**
     * @brief Runs complete benchmark suite across all configured fleet sizes and worker counts.
     */
    std::vector<BenchmarkResult> runAllBenchmarks();

    /**
     * @brief Executes a single benchmark configuration (Sequential or Parallel).
     */
    BenchmarkResult runSingleBenchmark(uint32_t vehicle_count,
                                       uint32_t worker_count,
                                       const std::vector<std::vector<IpcVehicleTask>>& workload);

    /**
     * @brief Exports benchmark tables to CSV files using native WindowsFileIO.
     */
    bool exportResultsToCsv(const std::vector<BenchmarkResult>& results);

    const BenchmarkConfig& getConfig() const noexcept { return config_; }

private:
    struct BenchmarkRunMeasurement {
        bool success{false};
        double startup_ms{0.0};
        double compute_ms{0.0};
        double total_ms{0.0};
        double cpu_percent{0.0};
        size_t working_set{0};
        size_t private_bytes{0};
        std::vector<IpcVehicleResult> final_step_results;
    };

    BenchmarkRunMeasurement executeSequential(uint32_t vehicle_count,
                                             const std::vector<std::vector<IpcVehicleTask>>& workload);

    BenchmarkRunMeasurement executeParallel(uint32_t vehicle_count,
                                           uint32_t worker_count,
                                           const std::vector<std::vector<IpcVehicleTask>>& workload);

    BenchmarkConfig config_;
    LARGE_INTEGER timer_frequency_{};
};

} // namespace Windows
} // namespace SmartTraffic
