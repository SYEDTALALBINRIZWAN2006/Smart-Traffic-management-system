#pragma once

#include "smart_traffic/windows/scoped_handle.h"
#include "smart_traffic/windows/ipc_protocol.h"
#include <string>
#include <vector>

namespace SmartTraffic {
namespace Windows {

/**
 * @brief Synchronized Win32 Shared Memory IPC Channel using CreateFileMappingW, MapViewOfFile, and Events.
 */
class SharedMemoryIPC {
public:
    SharedMemoryIPC() = default;
    ~SharedMemoryIPC() noexcept;

    SharedMemoryIPC(const SharedMemoryIPC&) = delete;
    SharedMemoryIPC& operator=(const SharedMemoryIPC&) = delete;

    SharedMemoryIPC(SharedMemoryIPC&& other) noexcept;
    SharedMemoryIPC& operator=(SharedMemoryIPC&& other) noexcept;

    /**
     * @brief Creates a new shared memory channel and named events (Orchestrator / Server mode).
     */
    bool createChannel(const std::string& session_id, uint32_t channel_id);

    /**
     * @brief Opens an existing shared memory channel and named events (Worker / Client mode).
     */
    bool openChannel(const std::string& session_id, uint32_t channel_id);

    /**
     * @brief Closes and unmaps the shared memory channel and event handles.
     */
    void close() noexcept;

    bool isValid() const noexcept { return channel_view_ != nullptr; }
    SharedMemoryChannel* getChannel() noexcept { return channel_view_; }
    const SharedMemoryChannel* getChannel() const noexcept { return channel_view_; }

    /**
     * @brief Master dispatches tasks to worker and waits for completion.
     */
    bool dispatchTasksAndWait(const std::vector<IpcVehicleTask>& tasks,
                             std::vector<IpcVehicleResult>& out_results,
                             DWORD timeout_ms = 5000);

    /**
     * @brief Master writes tasks to shared memory and signals worker (non-blocking).
     */
    bool dispatchTasksAsync(const std::vector<IpcVehicleTask>& tasks);

    /**
     * @brief Waits for result event for this channel.
     */
    bool waitForResult(DWORD timeout_ms = 5000) const noexcept;

    /**
     * @brief Master collects results from shared memory after worker signals completion.
     */
    bool collectResults(std::vector<IpcVehicleResult>& out_results);

    /**
     * @brief Returns the raw result event HANDLE for WaitForMultipleObjects.
     */
    HANDLE getResultEvent() const noexcept { return result_event_.get(); }

    /**
     * @brief Master sends shutdown command to worker.
     */
    bool sendShutdownSignal(DWORD timeout_ms = 2000);

    /**
     * @brief Worker waits for next task or shutdown command from master.
     */
    IpcCommand workerWaitForTask(DWORD timeout_ms = 5000);

    /**
     * @brief Worker signals to master that result processing is complete.
     */
    bool workerSignalResultReady();

    std::string getSessionId() const noexcept { return session_id_; }
    uint32_t getChannelId() const noexcept { return channel_id_; }

private:
    std::string session_id_;
    uint32_t channel_id_{0};
    ScopedHandle mapping_handle_;
    ScopedHandle task_event_;
    ScopedHandle result_event_;
    SharedMemoryChannel* channel_view_{nullptr};
};

} // namespace Windows
} // namespace SmartTraffic
