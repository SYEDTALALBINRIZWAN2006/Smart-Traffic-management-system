#pragma once

#include "smart_traffic/core/vehicle.h"
#include <memory>
#include <vector>
#include <unordered_map>
#include <cstdint>

namespace SmartTraffic {

/**
 * @brief Manages vehicle lifecycle, unique ID generation, and lane occupancy tracking.
 */
class VehicleManager {
public:
    VehicleManager() noexcept;

    /**
     * @brief Creates and registers a new vehicle with a strictly unique ID.
     * @param lane_id Initial spawn lane ID.
     * @param initial_speed_mps Starting speed in m/s.
     * @param target_speed_mps Desired cruising speed in m/s.
     * @param spawn_time_sec Simulation timestamp when vehicle is created.
     * @return Shared pointer to the newly spawned vehicle.
     */
    std::shared_ptr<Vehicle> createVehicle(uint32_t lane_id,
                                          double initial_speed_mps,
                                          double target_speed_mps,
                                          double spawn_time_sec);

    /**
     * @brief Checks if a lane is safe to accept a new vehicle spawn without headway collision.
     * @param lane_id The target spawn lane.
     * @param min_safe_headway_meters Minimum distance required from lane start.
     */
    bool canSpawnOnLane(uint32_t lane_id, double min_safe_headway_meters) const noexcept;

    /**
     * @brief Activates a pending vehicle, placing it into the active tracking map.
     */
    void activateVehicle(std::shared_ptr<Vehicle> vehicle);

    /**
     * @brief Marks an active vehicle as completed and moves it to completed archive.
     */
    void markVehicleCompleted(uint32_t vehicle_id);

    /**
     * @brief Removes a vehicle from active simulation due to despawn or error.
     */
    void removeVehicle(uint32_t vehicle_id);

    /**
     * @brief Retrieves a vehicle by unique ID from active list.
     */
    std::shared_ptr<Vehicle> getActiveVehicle(uint32_t vehicle_id) const;

    /**
     * @brief Retrieves all vehicles currently active in the simulation.
     */
    std::vector<std::shared_ptr<Vehicle>> getActiveVehicles() const;

    /**
     * @brief Retrieves all active vehicles traveling along a specific lane, sorted by distance along lane (descending).
     */
    std::vector<std::shared_ptr<Vehicle>> getVehiclesOnLane(uint32_t lane_id) const;

    size_t getActiveCount() const noexcept { return active_vehicles_.size(); }
    size_t getCompletedCount() const noexcept { return completed_vehicles_.size(); }
    size_t getTotalCreatedCount() const noexcept { return total_created_count_; }

    /**
     * @brief Resets all vehicle states, clearing active and completed sets and resetting ID counter.
     */
    void reset() noexcept;

private:
    uint32_t next_vehicle_id_{1};
    size_t total_created_count_{0};

    std::unordered_map<uint32_t, std::shared_ptr<Vehicle>> active_vehicles_;
    std::vector<std::shared_ptr<Vehicle>> completed_vehicles_;
};

} // namespace SmartTraffic
