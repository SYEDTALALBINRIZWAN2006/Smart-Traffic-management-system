#pragma once

#include "smart_traffic/config/simulation_config.h"
#include "smart_traffic/road/road_network.h"
#include "smart_traffic/simulation/vehicle_manager.h"
#include "smart_traffic/simulation/gps_simulator.h"
#include "smart_traffic/utils/csv_exporter.h"
#include "smart_traffic/tracking/tracking_manager.h"
#include "smart_traffic/analytics/traffic_analyzer.h"
#include "smart_traffic/analytics/alert_manager.h"
#include <memory>
#include <vector>
#include <functional>

namespace SmartTraffic {

/**
 * @brief Summary report produced upon simulation completion.
 */
struct SimulationSummary {
    uint64_t total_ticks{0};
    double total_simulated_time_sec{0.0};
    uint32_t vehicles_spawned{0};
    uint32_t vehicles_completed{0};
    size_t active_vehicles_at_end{0};
    size_t total_gps_records{0};
    double mean_gps_error_meters{0.0};
    double max_gps_error_meters{0.0};
    std::string csv_export_filepath;
    double execution_wall_time_ms{0.0};

    // Phase 2: Kalman Tracking Metrics and Telemetry
    TrackingMetrics tracking_metrics;
    std::string tracking_csv_filepath;

    // Phase 3: Traffic Analytics & Alerts
    TrafficAnalyticsSummary analytics_summary;
    AlertSummary alert_summary;
    std::string analytics_csv_filepath;
    std::string alerts_csv_filepath;
};

/**
 * @brief Central simulation engine coordinating time steps, physics, road rules, and sensor output.
 */
class TrafficSimulator {
public:
    explicit TrafficSimulator(const SimulationConfig& config = SimulationConfig::createDefault());

    /**
     * @brief Initializes road network, sensors, and simulation state.
     */
    void initialize();

    /**
     * @brief Advances the simulation by exactly one fixed tick (100 ms).
     */
    void step();

    /**
     * @brief Runs full simulation until total_simulation_time is reached.
     * @return Comprehensive summary of the simulation run.
     */
    SimulationSummary run();

    /**
     * @brief Resets simulation to t=0, clearing active vehicles and re-seeding RNG.
     */
    void reset();

    // State Inspection
    double getCurrentTime() const noexcept { return current_time_; }
    uint64_t getTickCount() const noexcept { return tick_count_; }
    const SimulationConfig& getConfig() const noexcept { return config_; }
    const VehicleManager& getVehicleManager() const noexcept { return vehicle_manager_; }
    const RoadNetwork& getRoadNetwork() const noexcept { return road_network_; }
    const TrackingManager& getTrackingManager() const noexcept { return tracking_manager_; }
    TrackingManager& getTrackingManager() noexcept { return tracking_manager_; }
    const TrafficAnalyzer& getTrafficAnalyzer() const noexcept { return traffic_analyzer_; }
    TrafficAnalyzer& getTrafficAnalyzer() noexcept { return traffic_analyzer_; }
    const AlertManager& getAlertManager() const noexcept { return alert_manager_; }
    AlertManager& getAlertManager() noexcept { return alert_manager_; }
    const std::vector<GpsMeasurement>& getLatestMeasurements() const noexcept { return latest_measurements_; }
    bool wasLatestTickGpsSampled() const noexcept { return was_latest_tick_gps_sampled_; }

    /**
     * @brief Optional callback invoked after each tick for telemetry or real-time inspection.
     */
    void setTickCallback(std::function<void(double current_time, uint64_t tick, const std::vector<GpsMeasurement>&)> callback) {
        tick_callback_ = callback;
    }

private:
    void attemptSpawning();
    void updateVehicleMovements(double dt);
    void collectGpsMeasurements();

    SimulationConfig config_;
    RoadNetwork road_network_;
    VehicleManager vehicle_manager_;
    GPSSimulator gps_simulator_;
    CsvExporter csv_exporter_;
    TrackingManager tracking_manager_;
    TrafficAnalyzer traffic_analyzer_;
    AlertManager alert_manager_;

    double current_time_{0.0};
    uint64_t tick_count_{0};
    uint32_t vehicles_spawned_{0};
    double next_spawn_time_{0.0};
    size_t spawn_lane_index_{0};
    double next_gps_sample_time_{0.0};
    bool was_latest_tick_gps_sampled_{false};

    std::vector<GpsMeasurement> latest_measurements_;

    // Performance and statistical metrics
    double accumulated_gps_error_{0.0};
    double max_gps_error_{0.0};
    size_t total_measurements_recorded_{0};

    std::function<void(double, uint64_t, const std::vector<GpsMeasurement>&)> tick_callback_;
};

} // namespace SmartTraffic
