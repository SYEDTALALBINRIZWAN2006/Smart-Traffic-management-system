#pragma once

#include "smart_traffic/core/position.h"
#include "smart_traffic/core/vehicle.h"
#include <random>
#include <cstdint>

namespace SmartTraffic {

/**
 * @brief Represents a GPS sensor measurement sample containing ground truth and noisy simulated readings.
 */
struct GpsMeasurement {
    double timestamp{0.0};       // Simulation time in seconds
    uint32_t vehicle_id{0};      // Unique vehicle ID
    double actual_x{0.0};        // True ground-truth X position in meters
    double actual_y{0.0};        // True ground-truth Y position in meters
    double gps_x{0.0};           // Simulated noisy GPS X position in meters
    double gps_y{0.0};           // Simulated noisy GPS Y position in meters
    double error_distance{0.0};  // Euclidean distance between ground truth and GPS measurement

    Position getActualPosition() const noexcept { return Position(actual_x, actual_y); }
    Position getGpsPosition() const noexcept { return Position(gps_x, gps_y); }
};

/**
 * @brief Simulates realistic GPS sensor output corrupted by deterministic Gaussian noise.
 */
class GPSSimulator {
public:
    /**
     * @brief Constructor initializing the PRNG with a fixed seed.
     * @param seed Deterministic seed for mt19937_64.
     * @param noise_stddev Standard deviation of measurement error in meters (default 2.5m).
     * @param bias_x Systematic sensor bias in X in meters (default 0.0m).
     * @param bias_y Systematic sensor bias in Y in meters (default 0.0m).
     */
    explicit GPSSimulator(uint64_t seed = 42,
                          double noise_stddev = 2.5,
                          double bias_x = 0.0,
                          double bias_y = 0.0);

    /**
     * @brief Generates a noisy GPS measurement for a given vehicle at the current timestamp.
     */
    GpsMeasurement sample(const Vehicle& vehicle, double timestamp_sec);

    /**
     * @brief Generates a noisy GPS measurement from an arbitrary ground truth position.
     */
    GpsMeasurement samplePosition(uint32_t vehicle_id, const Position& true_pos, double timestamp_sec);

    /**
     * @brief Reseeds the random number generator to a specific seed for reproducible runs.
     */
    void reseed(uint64_t new_seed) noexcept;

    double getNoiseStdDev() const noexcept { return noise_stddev_; }
    void setNoiseStdDev(double stddev);

    double getBiasX() const noexcept { return bias_x_; }
    double getBiasY() const noexcept { return bias_y_; }
    void setBias(double bx, double by) noexcept { bias_x_ = bx; bias_y_ = by; }

private:
    uint64_t initial_seed_{42};
    double noise_stddev_{2.5};
    double bias_x_{0.0};
    double bias_y_{0.0};

    std::mt19937_64 rng_;
    std::normal_distribution<double> normal_dist_;
};

} // namespace SmartTraffic
