#pragma once

#include "smart_traffic/simulation/gps_simulator.h"
#include <string>
#include <fstream>
#include <vector>

namespace SmartTraffic {

/**
 * @brief Thread-safe CSV file writer exporting vehicle tracking and GPS measurement records.
 */
class CsvExporter {
public:
    explicit CsvExporter(const std::string& output_filepath = "data/traffic_simulation.csv");
    ~CsvExporter();

    /**
     * @brief Opens the CSV file and writes header row.
     * @throws std::runtime_error If file cannot be created or opened.
     */
    void open(const std::string& output_filepath);

    /**
     * @brief Writes a single GPS measurement row.
     */
    void writeRow(const GpsMeasurement& measurement);

    /**
     * @brief Writes a batch of GPS measurements.
     */
    void writeRows(const std::vector<GpsMeasurement>& measurements);

    /**
     * @brief Flushes pending buffer writes to disk.
     */
    void flush();

    /**
     * @brief Closes the CSV file handle.
     */
    void close();

    bool isOpen() const noexcept { return is_open_; }
    size_t getRowCount() const noexcept { return row_count_; }
    const std::string& getFilepath() const noexcept { return filepath_; }

private:
    std::string filepath_;
    std::ofstream file_stream_;
    bool is_open_{false};
    size_t row_count_{0};
};

} // namespace SmartTraffic
