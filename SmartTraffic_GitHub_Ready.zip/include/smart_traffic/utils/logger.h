#pragma once

#include <string>
#include <mutex>
#include <fstream>
#include <memory>

namespace SmartTraffic {

enum class LogLevel {
    DEBUG = 0,
    INFO = 1,
    WARN = 2,
    ERR = 3
};

class Logger {
public:
    static Logger& getInstance();

    void setLogLevel(LogLevel level) noexcept { current_level_ = level; }
    void setLogFile(const std::string& filepath);

    void debug(const std::string& message);
    void info(const std::string& message);
    void warn(const std::string& message);
    void error(const std::string& message);

    void log(LogLevel level, const std::string& message);

private:
    Logger();
    ~Logger();

    std::string levelToString(LogLevel level) const;
    std::string getTimestampString() const;

    LogLevel current_level_{LogLevel::INFO};
    std::mutex mutex_;
    std::ofstream file_stream_;
    bool has_file_{false};
};

} // namespace SmartTraffic
