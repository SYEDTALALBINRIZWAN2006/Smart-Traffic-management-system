#pragma once

#include "smart_traffic/core/position.h"
#include <cstdint>
#include <vector>
#include <unordered_map>
#include <string>

namespace SmartTraffic {

/**
 * @brief Represents an intersection joining incoming approaches to outgoing exit lanes.
 */
class Intersection {
public:
    Intersection(uint32_t id,
                 const std::string& name,
                 const Position& center,
                 double radius_meters);

    uint32_t getId() const noexcept { return id_; }
    const std::string& getName() const noexcept { return name_; }
    const Position& getCenter() const noexcept { return center_; }
    double getRadius() const noexcept { return radius_; }

    void addIncomingLane(uint32_t lane_id);
    void addOutgoingLane(uint32_t lane_id);
    void addLaneRoute(uint32_t incoming_lane_id, uint32_t outgoing_lane_id);

    const std::vector<uint32_t>& getIncomingLanes() const noexcept { return incoming_lane_ids_; }
    const std::vector<uint32_t>& getOutgoingLanes() const noexcept { return outgoing_lane_ids_; }
    std::vector<uint32_t> getConnectedOutgoingLanes(uint32_t incoming_lane_id) const;

    /**
     * @brief Checks if a given 2D position lies inside the intersection envelope.
     */
    bool isInside(const Position& pos) const noexcept;

    std::string toString() const;

private:
    uint32_t id_{0};
    std::string name_;
    Position center_{0.0, 0.0};
    double radius_{15.0}; // Default 15 meters radius

    std::vector<uint32_t> incoming_lane_ids_;
    std::vector<uint32_t> outgoing_lane_ids_;
    std::unordered_map<uint32_t, std::vector<uint32_t>> incoming_to_outgoing_routes_;
};

} // namespace SmartTraffic
