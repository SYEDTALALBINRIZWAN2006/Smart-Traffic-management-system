#pragma once

#include "smart_traffic/core/types.h"
#include "smart_traffic/core/position.h"
#include "smart_traffic/core/velocity.h"
#include <vector>
#include <string>

namespace SmartTraffic {

/**
 * @brief Represents a directed physical lane along which vehicles travel in meters.
 */
class Lane {
public:
    Lane(uint32_t id,
         const std::string& name,
         const Position& start_point,
         const Position& end_point,
         double speed_limit_mps = 13.89, // ~50 km/h
         Direction direction = Direction::NORTH);

    uint32_t getId() const noexcept { return id_; }
    const std::string& getName() const noexcept { return name_; }
    const Position& getStartPoint() const noexcept { return start_point_; }
    const Position& getEndPoint() const noexcept { return end_point_; }
    double getLength() const noexcept { return length_; }
    double getSpeedLimit() const noexcept { return speed_limit_; }
    Direction getDirection() const noexcept { return direction_; }

    void setSpeedLimit(double limit) noexcept;
    void addSuccessorLane(uint32_t next_lane_id);
    const std::vector<uint32_t>& getSuccessorLanes() const noexcept { return successor_lane_ids_; }

    /**
     * @brief Computes 2D spatial position at a given distance along this lane in meters.
     */
    Position getPositionAtDistance(double distance) const noexcept;

    /**
     * @brief Computes velocity vector aligned with lane direction for a given speed.
     */
    Velocity getVelocityVector(double speed_mps) const noexcept;

    /**
     * @brief Computes the heading angle of this lane in radians.
     */
    double getHeadingRadians() const noexcept;

    /**
     * @brief Checks if a vehicle has reached or exceeded the lane length.
     */
    bool isAtEndOfLane(double distance) const noexcept;

    std::string toString() const;

private:
    uint32_t id_{0};
    std::string name_;
    Position start_point_{0.0, 0.0};
    Position end_point_{0.0, 0.0};
    double length_{0.0};              // Total lane length in meters
    double speed_limit_{13.89};       // m/s
    Direction direction_{Direction::NORTH};
    std::vector<uint32_t> successor_lane_ids_;
};

} // namespace SmartTraffic
