#pragma once

#include "smart_traffic/road/lane.h"
#include "smart_traffic/road/intersection.h"
#include <memory>
#include <unordered_map>
#include <vector>
#include <optional>

namespace SmartTraffic {

/**
 * @brief Manages the 2D road topology including lanes, intersections, and route navigation.
 */
class RoadNetwork {
public:
    RoadNetwork();

    /**
     * @brief Builds a standard 4-way intersection network with North, South, East, and West corridors.
     * @param corridor_length_meters Distance from intersection center to outer boundary (default 150m).
     * @param lane_width_meters Width of each lane (default 3.5m).
     * @param speed_limit_mps Speed limit for approach and exit lanes (default 13.89 m/s = 50 km/h).
     */
    void buildStandardFourWayIntersection(double corridor_length_meters = 150.0,
                                         double lane_width_meters = 3.5,
                                         double speed_limit_mps = 13.89);

    void addLane(std::shared_ptr<Lane> lane);
    void addIntersection(std::shared_ptr<Intersection> intersection);

    std::shared_ptr<Lane> getLane(uint32_t lane_id) const;
    std::shared_ptr<Intersection> getIntersection(uint32_t intersection_id) const;

    /**
     * @brief Returns all lane IDs that can be used for vehicle entry / spawning.
     */
    const std::vector<uint32_t>& getSpawnLaneIds() const noexcept { return spawn_lane_ids_; }

    /**
     * @brief Selects the next connected lane when reaching the end of the current lane.
     * @param current_lane_id ID of the current lane.
     * @param route_seed Deterministic choice index for choosing between multiple successors.
     * @return Next lane ID if a successor exists, or std::nullopt if the route is completed.
     */
    std::optional<uint32_t> getNextLaneId(uint32_t current_lane_id, uint64_t route_seed) const;

    size_t getLaneCount() const noexcept { return lanes_.size(); }
    size_t getIntersectionCount() const noexcept { return intersections_.size(); }

    const std::unordered_map<uint32_t, std::shared_ptr<Lane>>& getAllLanes() const noexcept { return lanes_; }

private:
    std::unordered_map<uint32_t, std::shared_ptr<Lane>> lanes_;
    std::unordered_map<uint32_t, std::shared_ptr<Intersection>> intersections_;
    std::vector<uint32_t> spawn_lane_ids_;
};

} // namespace SmartTraffic
