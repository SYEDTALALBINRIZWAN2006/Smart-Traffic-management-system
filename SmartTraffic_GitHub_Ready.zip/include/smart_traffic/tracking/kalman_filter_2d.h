#pragma once

#include <Eigen/Dense>
#include <cstdint>
#include <string>

namespace SmartTraffic {

/**
 * @brief 2D Constant-Velocity (CV) Kalman Filter for vehicle tracking.
 * State vector: [x, y, vx, vy]^T (position in meters, velocity in meters/second).
 * Measurement vector: [x_gps, y_gps]^T (GPS position in meters).
 */
class KalmanFilter2D {
public:
    /**
     * @brief Constructs a 2D Kalman Filter with configurable process and measurement noise.
     * @param process_accel_stddev Standard deviation of acceleration process noise in m/s^2.
     * @param measurement_stddev Standard deviation of GPS measurement noise in meters.
     * @param initial_velocity_stddev Prior uncertainty in velocity before convergence (m/s).
     */
    explicit KalmanFilter2D(double process_accel_stddev = 1.0,
                            double measurement_stddev = 2.5,
                            double initial_velocity_stddev = 15.0);

    /**
     * @brief Initializes the filter state from the first available GPS measurement.
     * Hidden ground-truth state is never used for initialization.
     * @param z_x Initial GPS X reading in meters.
     * @param z_y Initial GPS Y reading in meters.
     * @param timestamp Simulation epoch time in seconds.
     */
    void initialize(double z_x, double z_y, double timestamp);

    /**
     * @brief Predicts the state and error covariance ahead by delta time dt.
     * @param dt Time step in seconds (e.g. 0.100s simulation tick).
     */
    void predict(double dt);

    /**
     * @brief Corrects/updates the state and covariance with a fresh GPS measurement.
     * Uses the Joseph form covariance update for numerical symmetry and positive definiteness.
     * @param z_x Fresh GPS X reading in meters.
     * @param z_y Fresh GPS Y reading in meters.
     * @param timestamp Measurement time in seconds.
     */
    void correct(double z_x, double z_y, double timestamp);

    // State Accessors
    bool isInitialized() const noexcept { return is_initialized_; }
    double getLastUpdateTime() const noexcept { return last_update_time_; }
    uint64_t getUpdateCount() const noexcept { return update_count_; }

    const Eigen::Vector4d& getState() const noexcept { return x_; }
    const Eigen::Matrix4d& getCovariance() const noexcept { return P_; }
    const Eigen::Matrix<double, 4, 2>& getKalmanGain() const noexcept { return K_; }
    const Eigen::Matrix2d& getInnovationCovariance() const noexcept { return S_; }

    double getEstimatedX() const noexcept { return x_(0); }
    double getEstimatedY() const noexcept { return x_(1); }
    double getEstimatedVx() const noexcept { return x_(2); }
    double getEstimatedVy() const noexcept { return x_(3); }
    double getEstimatedSpeed() const noexcept;

    // Filter Parameter Configuration
    void setProcessNoiseStdDev(double stddev) noexcept;
    void setMeasurementNoiseStdDev(double stddev) noexcept;

    double getProcessNoiseStdDev() const noexcept { return q_accel_stddev_; }
    double getMeasurementNoiseStdDev() const noexcept { return r_gps_stddev_; }

    /**
     * @brief Checks if state vector or covariance contains any NaN or infinite values.
     */
    bool hasValidState() const noexcept;

    std::string toString() const;

private:
    void computeProcessNoiseMatrix(double dt, Eigen::Matrix4d& Q_out) const noexcept;
    void sanitizeState() noexcept;

    bool is_initialized_{false};
    double last_update_time_{0.0};
    uint64_t update_count_{0};

    // Filter Parameters
    double q_accel_stddev_{1.0};      // m/s^2 (continuous acceleration disturbance)
    double r_gps_stddev_{2.5};        // meters (GPS noise stddev)
    double p_init_vel_stddev_{15.0};  // m/s (initial velocity uncertainty)

    // State and Covariance
    Eigen::Vector4d x_{0.0, 0.0, 0.0, 0.0}; // [x, y, vx, vy]^T
    Eigen::Matrix4d P_{Eigen::Matrix4d::Identity()}; // State error covariance
    Eigen::Matrix<double, 2, 4> H_ = Eigen::Matrix<double, 2, 4>::Zero(); // Measurement matrix
    Eigen::Matrix2d R_{Eigen::Matrix2d::Identity()}; // Measurement covariance
    Eigen::Matrix<double, 4, 2> K_;                  // Kalman gain
    Eigen::Matrix2d S_{Eigen::Matrix2d::Identity()}; // Innovation covariance
};

} // namespace SmartTraffic
