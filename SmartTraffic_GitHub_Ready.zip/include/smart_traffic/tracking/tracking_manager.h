#pragma once

#include "smart_traffic/tracking/kalman_filter_2d.h"
#include "smart_traffic/core/vehicle.h"
#include "smart_traffic/simulation/gps_simulator.h"
#include <unordered_map>
#include <vector>
#include <memory>
#include <string>
#include <fstream>

namespace SmartTraffic {

/**
 * @brief Telemetry snapshot record for a vehicle at a specific simulation tick.
 */
struct TrackingRecord {
    double timestamp{0.0};
    uint32_t vehicle_id{0};
    double actual_x{0.0};
    double actual_y{0.0};
    double gps_x{0.0};
    double gps_y{0.0};
    double estimated_x{0.0};
    double estimated_y{0.0};
    double estimated_vx{0.0};
    double estimated_vy{0.0};
    double gps_error{0.0};
    double kalman_error{0.0};
    bool gps_fresh{false};
};

/**
 * @brief Statistical accuracy metrics for tracking evaluation.
 */
struct TrackingMetrics {
    uint64_t comparable_sample_count{0};
    uint64_t total_prediction_ticks{0};
    double gps_rmse_meters{0.0};
    double kalman_rmse_meters{0.0};
    double kalman_all_ticks_rmse_meters{0.0};
    double error_reduction_percentage{0.0};
    double max_gps_error_meters{0.0};
    double max_kalman_error_meters{0.0};
    uint32_t total_vehicles_tracked{0};
};

/**
 * @brief Manages fleet-wide Kalman filters, vehicle lifecycle tracking, and CSV export.
 */
class TrackingManager {
public:
    explicit TrackingManager(double process_noise_stddev = 1.0,
                             double measurement_noise_stddev = 2.5,
                             const std::string& csv_output_path = "data/kalman_tracking.csv");
    ~TrackingManager();

    /**
     * @brief Opens CSV export file and writes header.
     */
    void openExportFile(const std::string& output_path);

    /**
     * @brief Closes CSV export stream and flushes buffers.
     */
    void closeExportFile();

    /**
     * @brief Processes simulation tick: predicts all active filters, applies GPS corrections if fresh.
     */
    void update(double current_time,
                double dt,
                const std::vector<std::shared_ptr<Vehicle>>& active_vehicles,
                const std::vector<GpsMeasurement>& fresh_gps_measurements,
                bool is_gps_tick);

    /**
     * @brief Explicitly handles vehicle departure / removal.
     */
    void handleVehicleDeparted(uint32_t vehicle_id);

    /**
     * @brief Retrieves active Kalman filter for a specific vehicle ID.
     */
    const KalmanFilter2D* getFilter(uint32_t vehicle_id) const;

    /**
     * @brief Computes tracking metrics across all vehicles on comparable GPS timestamps.
     */
    TrackingMetrics computeMetrics() const noexcept;

    size_t getActiveFilterCount() const noexcept { return filters_.size(); }
    uint32_t getTotalVehiclesTracked() const noexcept { return total_vehicles_tracked_; }

    void reset();

private:
    double process_noise_stddev_{1.0};
    double measurement_noise_stddev_{2.5};
    std::string csv_output_path_;

    std::unordered_map<uint32_t, KalmanFilter2D> filters_;
    std::ofstream csv_stream_;
    bool is_csv_open_{false};

    // Metric accumulators (Comparable timestamps: ticks where fresh GPS was available)
    uint64_t comparable_sample_count_{0};
    double sum_squared_gps_error_{0.0};
    double sum_squared_kalman_error_comparable_{0.0};
    double max_gps_error_{0.0};

    // Metric accumulators (All ticks: including pure prediction ticks)
    uint64_t total_ticks_count_{0};
    double sum_squared_kalman_error_all_{0.0};
    double max_kalman_error_{0.0};

    uint32_t total_vehicles_tracked_{0};
};

} // namespace SmartTraffic
