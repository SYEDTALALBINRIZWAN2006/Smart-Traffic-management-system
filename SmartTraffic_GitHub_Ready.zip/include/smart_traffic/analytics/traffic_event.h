#pragma once

#include <cstdint>
#include <string>
#include <sstream>
#include <iomanip>

namespace SmartTraffic {

/**
 * @brief Heuristic congestion classification for road corridors.
 * Note: These are rule-based operational heuristic levels, not calibrated macroscopic real-world models.
 */
enum class CongestionLevel {
    LOW = 0,
    MODERATE = 1,
    HIGH = 2
};

inline const char* congestionLevelToString(CongestionLevel level) noexcept {
    switch (level) {
        case CongestionLevel::LOW: return "LOW";
        case CongestionLevel::MODERATE: return "MODERATE";
        case CongestionLevel::HIGH: return "HIGH";
        default: return "UNKNOWN";
    }
}

inline CongestionLevel stringToCongestionLevel(const std::string& str) noexcept {
    if (str == "HIGH") return CongestionLevel::HIGH;
    if (str == "MODERATE") return CongestionLevel::MODERATE;
    return CongestionLevel::LOW;
}

/**
 * @brief Classification of actionable traffic alerts.
 */
enum class AlertType {
    SPEED_VIOLATION = 0,
    HEAVY_CONGESTION = 1,
    STOPPED_VEHICLE = 2
};

inline const char* alertTypeToString(AlertType type) noexcept {
    switch (type) {
        case AlertType::SPEED_VIOLATION: return "SPEED_VIOLATION";
        case AlertType::HEAVY_CONGESTION: return "HEAVY_CONGESTION";
        case AlertType::STOPPED_VEHICLE: return "STOPPED_VEHICLE";
        default: return "UNKNOWN";
    }
}

/**
 * @brief Lifecycle status of an alert event.
 */
enum class AlertStatus {
    ACTIVE = 0,
    RESOLVED = 1
};

inline const char* alertStatusToString(AlertStatus status) noexcept {
    switch (status) {
        case AlertStatus::ACTIVE: return "ACTIVE";
        case AlertStatus::RESOLVED: return "RESOLVED";
        default: return "UNKNOWN";
    }
}

/**
 * @brief Severity level for speed limit violations.
 */
enum class ViolationSeverity {
    LOW = 0,      // < 15% over limit
    MEDIUM = 1,   // 15% - 30% over limit
    HIGH = 2      // > 30% over limit
};

inline const char* violationSeverityToString(ViolationSeverity severity) noexcept {
    switch (severity) {
        case ViolationSeverity::LOW: return "LOW";
        case ViolationSeverity::MEDIUM: return "MEDIUM";
        case ViolationSeverity::HIGH: return "HIGH";
        default: return "UNKNOWN";
    }
}

/**
 * @brief Structured representation of an operational traffic event or alert.
 */
struct TrafficEvent {
    uint64_t event_id{0};
    double timestamp{0.0};              // Simulation time when event was triggered (seconds)
    double resolved_timestamp{0.0};     // Simulation time when event was resolved (0.0 if active)
    AlertType type{AlertType::SPEED_VIOLATION};
    AlertStatus status{AlertStatus::ACTIVE};
    uint32_t vehicle_id{0};             // Associated vehicle ID (0 if network/road-level)
    uint32_t road_id{0};                // Road or Lane ID
    double actual_speed_mps{0.0};       // Observed vehicle or average road speed (m/s)
    double speed_limit_mps{0.0};        // Prescribed speed limit (m/s)
    ViolationSeverity severity{ViolationSeverity::LOW};
    std::string message;

    std::string toCsvRow() const {
        std::ostringstream ss;
        ss << std::fixed << std::setprecision(4);
        ss << event_id << ","
           << timestamp << ","
           << resolved_timestamp << ","
           << alertTypeToString(type) << ","
           << alertStatusToString(status) << ","
           << vehicle_id << ","
           << road_id << ","
           << actual_speed_mps << ","
           << speed_limit_mps << ","
           << violationSeverityToString(severity) << ",\""
           << message << "\"";
        return ss.str();
    }
};

} // namespace SmartTraffic
