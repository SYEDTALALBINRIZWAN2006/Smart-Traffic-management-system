#pragma once

#include "smart_traffic/analytics/traffic_event.h"
#include "smart_traffic/core/vehicle.h"
#include "smart_traffic/road/road_network.h"
#include <memory>
#include <vector>
#include <unordered_map>
#include <string>
#include <fstream>

namespace SmartTraffic {

/**
 * @brief Detailed traffic metrics for an individual road corridor or lane.
 * Internal calculations are strictly in SI units (meters, m/s).
 */
struct RoadMetrics {
    uint32_t road_id{0};
    std::string road_name;
    size_t vehicle_count{0};
    double average_speed_mps{0.0};           // m/s
    double average_speed_kmh{0.0};           // km/h (average_speed_mps * 3.6)
    double speed_limit_mps{0.0};             // m/s
    double road_length_meters{0.0};          // meters
    double total_vehicle_length_meters{0.0}; // meters
    double occupancy{0.0};                   // Ratio in [0.0, 1.0]
    double density_vehicles_per_km{0.0};     // vehicles / km
    size_t stopped_vehicle_count{0};
    CongestionLevel congestion_level{CongestionLevel::LOW};
};

/**
 * @brief System-wide macroscopic traffic metrics at a simulation snapshot.
 */
struct NetworkMetrics {
    double timestamp{0.0};
    size_t total_active_vehicles{0};
    size_t completed_journeys{0};
    size_t total_stopped_vehicles{0};
    double average_network_speed_mps{0.0};   // m/s
    double average_network_speed_kmh{0.0};   // km/h
    double average_occupancy{0.0};           // Ratio in [0.0, 1.0]
    double average_density_vehicles_per_km{0.0}; // vehicles / km
    CongestionLevel network_congestion_level{CongestionLevel::LOW};
    std::unordered_map<uint32_t, RoadMetrics> road_metrics; // Keyed by road/lane ID
    std::unordered_map<uint32_t, size_t> vehicle_count_per_lane; // Keyed by lane ID
};

/**
 * @brief Aggregated historical summary produced at the end of the simulation.
 */
struct TrafficAnalyticsSummary {
    double total_analyzed_time_sec{0.0};
    uint64_t total_snapshots{0};
    size_t peak_active_vehicles{0};
    size_t total_completed_journeys{0};
    double overall_mean_speed_mps{0.0};
    double overall_mean_speed_kmh{0.0};
    double peak_density_vehicles_per_km{0.0};
    double peak_occupancy{0.0};
    uint64_t total_high_congestion_snapshots{0};
    uint64_t total_moderate_congestion_snapshots{0};
    uint64_t total_low_congestion_snapshots{0};
};

/**
 * @brief Configurable threshold parameters for heuristic congestion detection.
 */
struct CongestionThresholds {
    double low_occupancy_max{0.25};          // Occupancy < 0.25 is typically LOW
    double moderate_occupancy_max{0.50};     // Occupancy in [0.25, 0.50) is MODERATE
    double speed_ratio_moderate{0.60};       // Speed < 60% of limit triggers MODERATE
    double speed_ratio_severe{0.30};         // Speed < 30% of limit triggers HIGH
    double stopped_ratio_severe{0.60};       // >= 60% stopped with >= 3 vehicles triggers HIGH
    double stopped_speed_threshold_mps{0.5}; // Vehicles below 0.5 m/s (~1.8 km/h) are stopped
};

/**
 * @brief Core traffic analytics engine computing authoritative real-time macroscopic and lane metrics.
 */
class TrafficAnalyzer {
public:
    explicit TrafficAnalyzer(const std::string& csv_output_path = "",
                             const CongestionThresholds& thresholds = CongestionThresholds{});
    ~TrafficAnalyzer();

    void openExportFile(const std::string& csv_output_path);
    void closeExportFile();

    /**
     * @brief Computes authoritative traffic metrics for the current simulation tick.
     * @param current_time Current simulation timestamp in seconds.
     * @param dt Time delta since previous tick in seconds.
     * @param active_vehicles Authoritative list of active vehicles.
     * @param road_network Road network topology reference.
     * @param completed_journeys Cumulative completed vehicle journeys.
     */
    void update(double current_time,
                double dt,
                const std::vector<std::shared_ptr<Vehicle>>& active_vehicles,
                const RoadNetwork& road_network,
                size_t completed_journeys);

    const NetworkMetrics& getLatestMetrics() const noexcept { return latest_metrics_; }
    const TrafficAnalyticsSummary& getSummary() const noexcept { return summary_; }

    void setCongestionThresholds(const CongestionThresholds& thresholds) noexcept {
        thresholds_ = thresholds;
    }
    const CongestionThresholds& getCongestionThresholds() const noexcept {
        return thresholds_;
    }

    void reset();

    // Direct accessors for latest snapshot queries
    size_t getTotalActiveVehicles() const noexcept { return latest_metrics_.total_active_vehicles; }
    size_t getCompletedJourneys() const noexcept { return latest_metrics_.completed_journeys; }
    size_t getTotalStoppedVehicles() const noexcept { return latest_metrics_.total_stopped_vehicles; }
    double getAverageNetworkSpeedMps() const noexcept { return latest_metrics_.average_network_speed_mps; }
    double getAverageNetworkSpeedKmh() const noexcept { return latest_metrics_.average_network_speed_kmh; }
    CongestionLevel getNetworkCongestionLevel() const noexcept { return latest_metrics_.network_congestion_level; }

    const RoadMetrics* getRoadMetrics(uint32_t road_id) const noexcept;
    size_t getVehicleCountOnLane(uint32_t lane_id) const noexcept;

    /**
     * @brief Evaluates the heuristic congestion level for a given occupancy and speed ratio.
     */
    CongestionLevel evaluateCongestion(double occupancy,
                                       double avg_speed_mps,
                                       double speed_limit_mps,
                                       size_t vehicle_count,
                                       size_t stopped_count) const noexcept;

private:
    std::string csv_output_path_;
    std::ofstream csv_stream_;
    bool is_csv_open_{false};

    CongestionThresholds thresholds_;
    NetworkMetrics latest_metrics_;
    TrafficAnalyticsSummary summary_;

    // Accumulators for overall summary metrics
    double sum_speed_samples_{0.0};
    uint64_t total_vehicle_samples_{0};
};

} // namespace SmartTraffic
