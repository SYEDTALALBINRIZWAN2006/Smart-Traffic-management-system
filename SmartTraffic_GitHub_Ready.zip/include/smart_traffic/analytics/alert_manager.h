#pragma once

#include "smart_traffic/analytics/traffic_event.h"
#include "smart_traffic/analytics/traffic_analyzer.h"
#include "smart_traffic/core/vehicle.h"
#include "smart_traffic/road/road_network.h"
#include <memory>
#include <vector>
#include <unordered_map>
#include <string>
#include <fstream>

namespace SmartTraffic {

/**
 * @brief Configurable threshold parameters for the Traffic Alert Engine.
 */
struct AlertThresholds {
    double speed_violation_tolerance_mps{0.5}; // Threshold above limit to trigger violation (~1.8 km/h tolerance)
    double stopped_duration_threshold_sec{3.0}; // Duration in seconds stationary before triggering alert
    double stopped_speed_threshold_mps{0.5};   // Speed below which vehicle is stationary
};

/**
 * @brief Summary statistics of alerts generated during simulation.
 */
struct AlertSummary {
    uint64_t total_alerts_created{0};
    uint64_t total_alerts_resolved{0};
    uint64_t speed_violations_count{0};
    uint64_t heavy_congestion_count{0};
    uint64_t stopped_vehicle_count{0};
    size_t active_alerts_at_end{0};
};

/**
 * @brief Centralized traffic event and alert engine managing alert lifecycles, deduplication, and resolution.
 */
class AlertManager {
public:
    explicit AlertManager(const std::string& csv_output_path = "",
                          const AlertThresholds& thresholds = AlertThresholds{});
    ~AlertManager();

    void openExportFile(const std::string& csv_output_path);
    void closeExportFile();

    /**
     * @brief Evaluates simulation state to detect new alerts, maintain active alerts, and resolve ended conditions.
     * @param current_time Current simulation time in seconds.
     * @param active_vehicles Authoritative list of active vehicles.
     * @param analyzer TrafficAnalyzer providing road and macroscopic metrics.
     * @param road_network Road network topology reference.
     */
    void processAlerts(double current_time,
                       const std::vector<std::shared_ptr<Vehicle>>& active_vehicles,
                       const TrafficAnalyzer& analyzer,
                       const RoadNetwork& road_network);

    /**
     * @brief Explicitly handles vehicle departure, resolving any active vehicle-specific alerts.
     */
    void handleVehicleDeparted(uint32_t vehicle_id, double current_time);

    // Queries
    std::vector<TrafficEvent> getActiveAlerts() const;
    const std::vector<TrafficEvent>& getHistoricalAlerts() const noexcept { return historical_alerts_; }
    std::vector<TrafficEvent> getAllAlerts() const;

    size_t getActiveAlertCount() const noexcept { return active_alerts_.size(); }
    size_t getHistoricalAlertCount() const noexcept { return historical_alerts_.size(); }
    uint64_t getTotalAlertCount() const noexcept { return next_event_id_ - 1; }
    const AlertSummary& getSummary() const noexcept { return summary_; }

    void setAlertThresholds(const AlertThresholds& thresholds) noexcept { thresholds_ = thresholds; }
    const AlertThresholds& getAlertThresholds() const noexcept { return thresholds_; }

    void reset();

private:
    void checkSpeedViolations(double current_time,
                              const std::vector<std::shared_ptr<Vehicle>>& active_vehicles,
                              const RoadNetwork& road_network);

    void checkStoppedVehicles(double current_time,
                              const std::vector<std::shared_ptr<Vehicle>>& active_vehicles);

    void checkHeavyCongestion(double current_time,
                              const TrafficAnalyzer& analyzer);

    void resolveAlert(const std::string& alert_key, double resolved_time);
    void writeAlertRow(const TrafficEvent& event);

    std::string csv_output_path_;
    std::ofstream csv_stream_;
    bool is_csv_open_{false};

    AlertThresholds thresholds_;
    uint64_t next_event_id_{1};
    AlertSummary summary_;

    // Active alerts indexed by a unique deduplication key:
    // e.g. "SPEED_<vehicle_id>", "STOPPED_<vehicle_id>", "CONGESTION_<road_id>"
    std::unordered_map<std::string, TrafficEvent> active_alerts_;

    // Historical log of resolved alerts
    std::vector<TrafficEvent> historical_alerts_;

    // Stationary duration tracking for stopped vehicles: vehicle_id -> timestamp when vehicle became stopped
    std::unordered_map<uint32_t, double> vehicle_stopped_start_time_;
};

} // namespace SmartTraffic
