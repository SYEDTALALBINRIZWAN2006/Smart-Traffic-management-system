Set-Location $PSScriptRoot

function Test-CsvFile([string]$path, [int]$expectedCols, [string]$name) {
    if (-not (Test-Path $path)) {
        Write-Error "$name file does not exist: $path"
        return $false
    }
    $lines = Get-Content $path
    Write-Host "$name Header: $($lines[0])"
    Write-Host "$name Total Lines: $($lines.Count) (Header + $($lines.Count - 1) data records)"

    $nanCount = ($lines | Select-String -Pattern "nan|inf" -CaseSensitive:$false).Count
    Write-Host "$name NaN/Inf records: $nanCount"

    $formatErrors = 0
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ([string]::IsNullOrWhiteSpace($lines[$i])) { continue }
        # Custom CSV split that accounts for quoted strings like message
        $cols = $lines[$i] -split '(?!\B"[^"]*),(?![^"]*"\B)'
        if ($cols.Count -ne $expectedCols) {
            $formatErrors++
            if ($formatErrors -le 3) {
                Write-Host "$name Line $i column mismatch: expected $expectedCols, got $($cols.Count): $($lines[$i])"
            }
        }
    }
    Write-Host "$name Column format errors: $formatErrors"

    if ($formatErrors -eq 0 -and $nanCount -eq 0) {
        Write-Host "$name validation PASSED." -ForegroundColor Green
        return $true
    } else {
        Write-Host "$name validation FAILED." -ForegroundColor Red
        return $false
    }
}

Write-Host "========================================================"
Write-Host "     SMARTTRAFFIC PHASE 4 ALL-CSV VALIDATION SUITE      "
Write-Host "========================================================"

$p1 = Test-CsvFile "data/traffic_simulation.csv" 6  "1. Raw GPS Telemetry"
Write-Host "--------------------------------------------------------"
$p2 = Test-CsvFile "data/kalman_tracking.csv"   11 "2. Kalman Tracking Telemetry"
Write-Host "--------------------------------------------------------"
$p3 = Test-CsvFile "data/traffic_analytics.csv" 9  "3. Traffic Analytics"
Write-Host "--------------------------------------------------------"
$p4 = Test-CsvFile "data/traffic_alerts.csv"    11 "4. Traffic Alerts & Incidents"
Write-Host "--------------------------------------------------------"
$p5 = Test-CsvFile "data/kalman_benchmarks.csv" 12 "5. Win32 Multiprocessing Benchmarks"
Write-Host "--------------------------------------------------------"
$p6 = Test-CsvFile "data/windows_os_metrics.csv" 10 "6. Windows OS & Memory Metrics"
Write-Host "========================================================"

if ($p1 -and $p2 -and $p3 -and $p4 -and $p5 -and $p6) {
    Write-Host "ALL 6 CSV FILES VALIDATED SUCCESSFULLY WITH ZERO ERRORS!" -ForegroundColor Green
} else {
    Write-Error "ONE OR MORE CSV VALIDATIONS FAILED!"
    exit 1
}
