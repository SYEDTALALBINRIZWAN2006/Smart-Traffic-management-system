$ErrorActionPreference = "Stop"
$cxx = "C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64\bin\g++.exe"
Set-Location "C:\Users\Talal\Desktop\SmartTraffic"

$coreSources = @(
    "src/core/position.cpp",
    "src/core/velocity.cpp",
    "src/core/vehicle.cpp",
    "src/config/simulation_config.cpp",
    "src/road/lane.cpp",
    "src/road/intersection.cpp",
    "src/road/road_network.cpp",
    "src/simulation/vehicle_manager.cpp",
    "src/simulation/gps_simulator.cpp",
    "src/simulation/traffic_simulator.cpp",
    "src/utils/csv_exporter.cpp",
    "src/utils/logger.cpp",
    "src/tracking/kalman_filter_2d.cpp",
    "src/tracking/tracking_manager.cpp"
)

Write-Host "Compiling BenchmarkGrid.exe..."
& $cxx -std=c++17 -O2 -I include -I third_party/eigen3 -o build/BenchmarkGrid.exe benchmark_grid.cpp $coreSources
if ($LASTEXITCODE -ne 0) {
    Write-Error "Compilation failed"
    exit 1
}

Write-Host "Running BenchmarkGrid.exe..."
& .\build\BenchmarkGrid.exe
