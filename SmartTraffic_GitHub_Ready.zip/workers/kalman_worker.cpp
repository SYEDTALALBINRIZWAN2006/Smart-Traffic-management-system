#include "smart_traffic/windows/shared_memory_ipc.h"
#include "smart_traffic/tracking/kalman_filter_2d.h"
#include <iostream>
#include <unordered_map>
#include <string>

using namespace SmartTraffic;
using namespace SmartTraffic::Windows;

int main(int argc, char* argv[]) {
    std::string session_id = "default";
    uint32_t channel_id = 0;
    double process_noise = 1.0;
    double measurement_noise = 2.5;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--session" && i + 1 < argc) {
            session_id = argv[++i];
        } else if (arg == "--channel" && i + 1 < argc) {
            channel_id = static_cast<uint32_t>(std::stoul(argv[++i]));
        } else if (arg == "--process-noise" && i + 1 < argc) {
            process_noise = std::stod(argv[++i]);
        } else if (arg == "--meas-noise" && i + 1 < argc) {
            measurement_noise = std::stod(argv[++i]);
        }
    }

    SharedMemoryIPC ipc;
    if (!ipc.openChannel(session_id, channel_id)) {
        return 101; // Failed to open IPC channel
    }

    std::unordered_map<uint32_t, KalmanFilter2D> filters;
    bool running = true;

    while (running) {
        IpcCommand cmd = ipc.workerWaitForTask(30000); // 30 second timeout per batch

        if (cmd == IPC_CMD_SHUTDOWN) {
            running = false;
            break;
        }

        if (cmd == IPC_CMD_PROCESS_BATCH) {
            auto* shm = ipc.getChannel();
            if (!shm) {
                break;
            }

            const uint32_t task_count = shm->task_count;
            uint32_t result_count = 0;

            for (uint32_t i = 0; i < task_count && i < MAX_IPC_VEHICLES; ++i) {
                const auto& task = shm->tasks[i];

                if (task.is_departed) {
                    filters.erase(task.vehicle_id);
                    continue;
                }

                auto it = filters.find(task.vehicle_id);
                if (it == filters.end()) {
                    if (task.has_fresh_gps) {
                        auto& kf = filters[task.vehicle_id];
                        kf.setProcessNoiseStdDev(process_noise);
                        kf.setMeasurementNoiseStdDev(measurement_noise);
                        kf.initialize(task.gps_x, task.gps_y, task.timestamp);
                        it = filters.find(task.vehicle_id);
                    } else {
                        continue;
                    }
                } else {
                    it->second.predict(task.dt);
                    if (task.has_fresh_gps) {
                        it->second.correct(task.gps_x, task.gps_y, task.timestamp);
                    }
                }

                // Write result into shared result buffer
                auto& res = shm->results[result_count++];
                res.vehicle_id = task.vehicle_id;
                res.status = 0;
                res.estimated_x = it->second.getEstimatedX();
                res.estimated_y = it->second.getEstimatedY();
                res.estimated_vx = it->second.getEstimatedVx();
                res.estimated_vy = it->second.getEstimatedVy();
            }

            shm->result_count = result_count;
            ipc.workerSignalResultReady();
        }
    }

    ipc.close();
    return 0;
}
