#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
cmake -S . -B build-dashboard -DCMAKE_BUILD_TYPE=Release
cmake --build build-dashboard -j 4
ctest --test-dir build-dashboard --output-on-failure
./build-dashboard/SmartTraffic
printf '\nOpen http://127.0.0.1:8080 in your browser\n'
./build-dashboard/SmartTrafficApi --db data/smarttraffic.db --data data --import --web web --port 8080
