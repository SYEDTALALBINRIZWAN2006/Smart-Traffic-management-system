#include "smart_traffic/simulation/traffic_simulator.h"
#include "smart_traffic/config/simulation_config.h"
#include <iostream>
#include <iomanip>
#include <vector>

int main() {
    std::cout << "=========================================================================================================\n";
    std::cout << "               SMARTTRAFFIC PHASE 2: 9-GRID ACCURACY & STABILITY BENCHMARK EVALUATION                     \n";
    std::cout << "=========================================================================================================\n";

    const std::vector<uint64_t> seeds = { 42, 1001, 7777 };
    const std::vector<double> noise_levels = { 1.5, 2.5, 4.0 };

    std::cout << std::left 
              << std::setw(8)  << "Seed"
              << std::setw(12) << "Noise (m)"
              << std::setw(16) << "GPS RMSE (m)"
              << std::setw(18) << "Kalman RMSE (m)"
              << std::setw(20) << "All-Tick RMSE (m)"
              << std::setw(16) << "Reduction (%)"
              << std::setw(14) << "Samples"
              << "\n";
    std::cout << std::string(105, '-') << "\n";

    for (uint64_t seed : seeds) {
        for (double noise_std : noise_levels) {
            SmartTraffic::SimulationConfig config = SmartTraffic::SimulationConfig::createDefault();
            config.vehicle_count = 30;
            config.total_simulation_time = 60.0;
            config.random_seed = seed;
            config.gps_noise_stddev = noise_std;
            config.kalman_measurement_noise_stddev = noise_std;
            config.kalman_process_noise_stddev = 1.0;
            config.enable_console_progress = false;
            config.output_csv_path = "";
            config.tracking_csv_path = "";

            SmartTraffic::TrafficSimulator sim(config);
            const auto summary = sim.run();
            const auto& tm = summary.tracking_metrics;

            std::cout << std::left
                      << std::setw(8)  << seed
                      << std::fixed << std::setprecision(1) << std::setw(12) << noise_std
                      << std::fixed << std::setprecision(4) << std::setw(16) << tm.gps_rmse_meters
                      << std::fixed << std::setprecision(4) << std::setw(18) << tm.kalman_rmse_meters
                      << std::fixed << std::setprecision(4) << std::setw(20) << tm.kalman_all_ticks_rmse_meters
                      << std::fixed << std::setprecision(2) << std::setw(16) << tm.error_reduction_percentage
                      << std::setw(14) << tm.comparable_sample_count
                      << "\n";
        }
    }
    std::cout << "=========================================================================================================\n";
    return 0;
}
