Set-Location "C:\Users\Talal\Desktop\SmartTraffic"
$files = Get-ChildItem "tests\*.cpp"
foreach ($f in $files) {
    $content = Get-Content $f.FullName
    for ($i = 0; $i -lt $content.Count; $i++) {
        if ($content[$i] -match "TrafficSimulator") {
            Write-Host "$($f.Name):$($i+1) -> $($content[$i])"
            # Look backwards up to 20 lines to see the config definition
            $start = [Math]::Max(0, $i - 15)
            for ($j = $start; $j -le $i; $j++) {
                if ($content[$j] -match "output_csv_path") {
                    Write-Host "   $($content[$j])"
                }
            }
        }
    }
}
