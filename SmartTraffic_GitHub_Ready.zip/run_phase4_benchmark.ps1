$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "==================================================================="
Write-Host "         SMARTTRAFFIC PHASE 4: FULL RE-VERIFICATION SUITE          "
Write-Host "==================================================================="

Write-Host "`n[STEP 1/4] Running 60-second 30-vehicle traffic simulation..."
& .\build-msvc\SmartTraffic.exe
if ($LASTEXITCODE -ne 0) {
    Write-Error "Traffic simulation failed!"
    exit 1
}

Write-Host "`n[STEP 2/4] Running Win32 Multiprocessing Kalman Benchmarks (30, 100, 500, 1000 vehicles)..."
& .\build-msvc\SmartTraffic.exe --benchmark
if ($LASTEXITCODE -ne 0) {
    Write-Error "Multiprocessing benchmark failed!"
    exit 1
}

Write-Host "`n[STEP 3/4] Running Automated Unit & Integration Tests (Phases 1-4)..."
& .\build-msvc\SmartTrafficTests.exe
if ($LASTEXITCODE -ne 0) {
    Write-Error "Test suite failed!"
    exit 1
}

Write-Host "`n[STEP 4/4] Verifying all 6 output CSV files..."
& powershell -ExecutionPolicy Bypass -File .\verify_csv.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Error "CSV verification failed!"
    exit 1
}

Write-Host "`n==================================================================="
Write-Host "    ALL PHASE 4 PIPELINES, BENCHMARKS, AND TESTS PASSED 100%!     "
Write-Host "==================================================================="
