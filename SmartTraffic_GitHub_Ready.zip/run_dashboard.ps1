$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
Write-Host 'Configuring SmartTraffic...' -ForegroundColor Cyan
cmake -S . -B build-dashboard -DCMAKE_BUILD_TYPE=Release
if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed. Install a C++17 compiler and CMake.' }
cmake --build build-dashboard --config Release
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
ctest --test-dir build-dashboard -C Release --output-on-failure
if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
$bin = Join-Path $root 'build-dashboard/Release'
if (-not (Test-Path (Join-Path $bin 'SmartTraffic.exe'))) { $bin = Join-Path $root 'build-dashboard' }
$sim = Join-Path $bin 'SmartTraffic.exe'
$api = Join-Path $bin 'SmartTrafficApi.exe'
if (-not (Test-Path $sim) -or -not (Test-Path $api)) { throw 'Executables not found' }
Write-Host 'Running simulation...' -ForegroundColor Cyan
& $sim
if ($LASTEXITCODE -ne 0) { throw 'Simulation failed' }
Write-Host 'Starting dashboard at http://127.0.0.1:8080' -ForegroundColor Green
Start-Process 'http://127.0.0.1:8080'
& $api --db 'data/smarttraffic.db' --data 'data' --import --web 'web' --port 8080
