cmake_minimum_required(VERSION 3.15)
project(SmartTraffic VERSION 2.0.0 LANGUAGES CXX)

# Enforce strict C++17 Standard
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Native Windows MSVC configuration
if (MSVC)
    add_compile_options(
        /W4
        /permissive-
        /EHsc
        /utf-8
        /Zc:__cplusplus
    )
    add_definitions(
        -D_CRT_SECURE_NO_WARNINGS
        -DWIN32_LEAN_AND_MEAN
        -DNOMINMAX
    )
else()
    add_compile_options(-Wall -Wextra -Wpedantic)
endif()

# ==============================================================================
# Eigen Integration Setup (Windows-compatible, Offline & System-friendly)
# ==============================================================================
find_package(Eigen3 3.3 QUIET CONFIG)
if (TARGET Eigen3::Eigen)
    message(STATUS "Found installed Eigen3 target: Eigen3::Eigen")
    set(EIGEN_INCLUDE_DIR "")
    set(EIGEN_TARGET Eigen3::Eigen)
else()
    message(STATUS "Using self-contained Eigen3 headers from third_party/eigen3")
    add_library(Eigen3 INTERFACE)
    add_library(Eigen3::Eigen ALIAS Eigen3)
    target_include_directories(Eigen3 INTERFACE "${CMAKE_CURRENT_SOURCE_DIR}/third_party/eigen3")
    set(EIGEN_TARGET Eigen3::Eigen)
endif()

# ==============================================================================
# Core Static Library: smart_traffic_core
# ==============================================================================
set(SMART_TRAFFIC_CORE_SOURCES
    # Phase 1 Core Models & Road Network
    src/core/position.cpp
    src/core/velocity.cpp
    src/core/vehicle.cpp
    src/config/simulation_config.cpp
    src/road/lane.cpp
    src/road/intersection.cpp
    src/road/road_network.cpp
    src/simulation/vehicle_manager.cpp
    src/simulation/gps_simulator.cpp
    src/simulation/traffic_simulator.cpp
    src/utils/csv_exporter.cpp
    src/utils/logger.cpp

    # Phase 2 2D Kalman Filter & Vehicle Tracking
    src/tracking/kalman_filter_2d.cpp
    src/tracking/tracking_manager.cpp

    # Phase 3 Traffic Intelligence & Analytics Engine
    src/analytics/traffic_analyzer.cpp
    src/analytics/alert_manager.cpp

)

if (WIN32)
    list(APPEND SMART_TRAFFIC_CORE_SOURCES
        src/windows/windows_file_io.cpp
        src/windows/windows_memory_manager.cpp
        src/windows/windows_process_manager.cpp
        src/windows/shared_memory_ipc.cpp
        src/windows/kalman_benchmark_runner.cpp
    )
endif()
add_library(smart_traffic_core STATIC ${SMART_TRAFFIC_CORE_SOURCES})

target_include_directories(smart_traffic_core PUBLIC
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/eigen3
)

target_link_libraries(smart_traffic_core PUBLIC
    ${EIGEN_TARGET}
)
if (WIN32)
    target_link_libraries(smart_traffic_core PUBLIC psapi)
endif()

# ==============================================================================
# Executable: SmartTraffic
# ==============================================================================
add_executable(SmartTraffic src/main.cpp)
target_link_libraries(SmartTraffic PRIVATE smart_traffic_core)
target_include_directories(SmartTraffic PRIVATE 
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/eigen3
)

# ==============================================================================
# Executable: kalman_worker (Phase 4 Multiprocessing Worker Process)
# ==============================================================================
if (WIN32)
add_executable(kalman_worker workers/kalman_worker.cpp)
target_link_libraries(kalman_worker PRIVATE smart_traffic_core)
target_include_directories(kalman_worker PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/eigen3
)

endif()

# Ensure runtime data and log directories exist at build time
file(MAKE_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/data)
file(MAKE_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/logs)

# Copy configuration and set up runtime environment post-build
add_custom_command(TARGET SmartTraffic POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E make_directory $<TARGET_FILE_DIR:SmartTraffic>/config
    COMMAND ${CMAKE_COMMAND} -E make_directory $<TARGET_FILE_DIR:SmartTraffic>/data
    COMMAND ${CMAKE_COMMAND} -E make_directory $<TARGET_FILE_DIR:SmartTraffic>/logs
    COMMAND ${CMAKE_COMMAND} -E copy_if_different
            "${CMAKE_CURRENT_SOURCE_DIR}/config/simulation_config.json"
            "$<TARGET_FILE_DIR:SmartTraffic>/config/simulation_config.json"
    COMMENT "Copying configuration and preparing runtime data directories"
)

# ==============================================================================
# Automated Unit and Integration Tests: SmartTrafficTests
# ==============================================================================
enable_testing()

set(TEST_SOURCES
    tests/test_main.cpp
    # Phase 1 Test Suites
    tests/test_simulation_determinism.cpp
    tests/test_vehicle_count.cpp
    tests/test_movement_constraints.cpp
    # Phase 2 Test Suites
    tests/test_kalman_filter.cpp
    tests/test_tracking_integration.cpp
    # Phase 3 Test Suites
    tests/test_traffic_analytics.cpp
)

if (WIN32)
    list(APPEND TEST_SOURCES tests/test_windows_os.cpp)
endif()
add_executable(SmartTrafficTests ${TEST_SOURCES})
target_include_directories(SmartTrafficTests PRIVATE 
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/tests
    ${CMAKE_CURRENT_SOURCE_DIR}/third_party/eigen3
)
target_link_libraries(SmartTrafficTests PRIVATE smart_traffic_core)
if (WIN32)
    add_dependencies(SmartTrafficTests kalman_worker)
    target_compile_definitions(SmartTrafficTests PRIVATE
        SMARTTRAFFIC_WORKER_EXE="$<TARGET_FILE:kalman_worker>")
endif()

add_custom_command(TARGET SmartTrafficTests POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E make_directory $<TARGET_FILE_DIR:SmartTrafficTests>/data
    COMMAND ${CMAKE_COMMAND} -E make_directory $<TARGET_FILE_DIR:SmartTrafficTests>/logs
    COMMENT "Preparing test runtime data directories"
)

# Register test suite with CTest
add_test(NAME SmartTrafficTestSuite COMMAND SmartTrafficTests)
set_tests_properties(SmartTrafficTestSuite PROPERTIES
    WORKING_DIRECTORY "$<TARGET_FILE_DIR:SmartTrafficTests>")

# Phase 5: SQLite persistence and localhost REST API
find_package(SQLite3 REQUIRED)
add_library(smart_traffic_database STATIC src/database/traffic_database.cpp)
target_include_directories(smart_traffic_database PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(smart_traffic_database PUBLIC SQLite::SQLite3)
add_executable(SmartTrafficApi src/api/api_server.cpp)
target_link_libraries(SmartTrafficApi PRIVATE smart_traffic_database)
if(WIN32)
    target_link_libraries(SmartTrafficApi PRIVATE ws2_32)
endif()
add_executable(SmartTrafficDatabaseTests tests/test_database.cpp)
target_link_libraries(SmartTrafficDatabaseTests PRIVATE smart_traffic_database)
add_test(NAME SmartTrafficDatabaseSuite COMMAND SmartTrafficDatabaseTests)
