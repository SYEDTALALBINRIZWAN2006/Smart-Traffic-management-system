Set-Location "C:\Users\Talal\Desktop\SmartTraffic"
& .\build\SmartTraffic.exe | Out-Null
$s1 = (Get-Item "data\traffic_simulation.csv").Length
Write-Host "After SmartTraffic.exe: $s1 bytes"

& .\build\SmartTraffic.exe --benchmark | Out-Null
$s2 = (Get-Item "data\traffic_simulation.csv").Length
Write-Host "After benchmark: $s2 bytes"

& .\build\SmartTrafficTests.exe | Out-Null
$s3 = (Get-Item "data\traffic_simulation.csv").Length
Write-Host "After SmartTrafficTests.exe: $s3 bytes"
